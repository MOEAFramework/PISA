#!/bin/sh
./semo semo_param.txt ../PISA_ 0.1
