package selSibea;

import selSibea.internal.StateMachine;

public class Launcher {
	private static StateMachine state;
	
	public static void main( String[] args ) {	
		ParameterSet.setParameters(args);
		state = StateMachine.getInstance( ParameterSet.getCommFilePath() + "sta" );
		state.run();
	}	
}