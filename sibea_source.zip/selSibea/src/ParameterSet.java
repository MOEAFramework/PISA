package selSibea;

import java.util.StringTokenizer;


public class ParameterSet {
	private static int pollingInterval;
	private static String commFilePath = new String();;
	private static String parameterFileName = new String();
	
	private static long seed;
	private static double bound;
	private static int alpha, mu, lambda, dim;	
		
	ParameterSet() {
	}

	public static long getSeed() {
		return seed;
	}
	
	public static int getPollingInterval() {
		return pollingInterval;
	}

	public static String getCommFilePath() {
		return commFilePath;
	}

	public static String getParameterFileName() {
		return parameterFileName;
	}
	
	public static void setParameters(String[] args ) {
		if( args.length != 3 ) {
			displayHelpText(args);
			System.exit(0);
		}
		else {
			ParameterSet.parameterFileName = args[0];
			ParameterSet.commFilePath = args[1];
			ParameterSet.pollingInterval = (int)Math.round(1000*Double.parseDouble(args[2]));
		}		
	}
	
	private static void displayHelpText(String[] args) {
		System.err.println("Wrong number of arguments.");
		System.err.println("Usage: PARAMFILE FILENAMEBASE POLL."); 
		System.err.println("You provided " + args.length + " arguments:"); 
		for( String s : args )
			System.err.println( s );
		 
	}

	public static boolean setOption(String key, StringTokenizer val){
		
		try {
			if (key.equals("seed")){
				ParameterSet.seed =  Long.parseLong(val.nextToken());				
			}
			else if (key.equals("bound")){
				ParameterSet.bound = Double.parseDouble(val.nextToken());				
			}
			else 
				throw new IllegalArgumentException("Unknown parameter " + key );
		}
		catch (Exception ex) {
			System.err.println("Error parsing the parameter " + key + " with value " + 
					val.toString());
			ex.printStackTrace();
			System.exit(0);
		}	
		return false;
	}
	
	public static int getAlpha() {
		return alpha;
	}
	
	public static int getMu() {
		return mu;
	}


	public static int getLambda() {
		return lambda;
	}
	
	public static int getDim() {
		return dim;
	}


	public static void setParameter(String key, String value) {
		
		if (key.equals("alpha") == true) 
			alpha = Integer.parseInt(value);
		else if(key.equals("mu") == true)
			mu = Integer.parseInt(value);
		else if (key.equals("lambda") == true)
			lambda = Integer.parseInt(value);
		else if (key.equals("dim") == true) {
			dim = Integer.parseInt(value);
		}
		else
			throw new RuntimeException("Unknown parameter " + key + "\n");
	}

	public static boolean allSet() {
		return (alpha > 0 ) && (mu > 0) && (lambda > 0 ) && (dim > 0 );
	}
	
	public static double getBound() {
		return bound;
	}
}
