package selSibea.selector;


import java.util.ArrayList;
import java.util.Comparator;

import selSibea.ParameterSet;
import selSibea.internal.ObjectiveMatrix;
import selSibea.population.FrontPart;
import selSibea.population.Individual;
import selSibea.population.Population;

public class Selector {

	public void environmentalSelection(Population pop) {
		FrontPart frontPart = new FrontPart();
		frontPart.partition(pop);
		
		
		int worstFrontIndex = -1;

		/* Front wise reduction */
		for (int front = frontPart.getNrOfFronts() - 1; front >= 0; front--) {
			if (frontPart.getTotalSize() - frontPart.getFrontSize(front) >= ParameterSet
					.getAlpha()) {
				frontPart.removeFront(front);
			} else {
				worstFrontIndex = front;
				break;
			}
		}	
		
		int newSize = frontPart.getFrontSize(worstFrontIndex) - (frontPart.getTotalSize() - ParameterSet.getAlpha());
		
		/* Remove individuals from the worst front */
		if( (frontPart.getTotalSize() > ParameterSet.getAlpha()) ) {
			ObjectiveMatrix points = new ObjectiveMatrix();
			Individual[] inds = frontPart.getFront(worstFrontIndex);
			for( int i = 0; i < frontPart.getFrontSize(worstFrontIndex); i++) {
				points.addVector( inds[i].getObjectiveVector(), i);
			}
			
			ArrayList<Integer> newIndices;
			if( ParameterSet.getDim() == 2 )
				newIndices =
					ReductionByDynamicProgramming.reduce( points, newSize, ParameterSet.getBound() );
			else
				newIndices = 
					ReductionByGreedyProcedure.reduce( points, newSize, ParameterSet.getBound() );

			for( int i = frontPart.getFrontSize(worstFrontIndex)-1; i >= 0; i-- ) {
				boolean exists = false;
				for( int j = 0; j < newIndices.size(); j++) {
					if( newIndices.get(j) == i ) {
						exists = true;
						break;
					}
				}
				if( exists == false )
					frontPart.removeIndividual(worstFrontIndex, i );
			}
		}
		
		if( frontPart.getTotalSize() != ParameterSet.getAlpha() ) {
			System.err.println("The population is of size " + frontPart.getTotalSize() + " instead of " + ParameterSet.getAlpha());
			System.exit(-1);
		}

		pop.cleanUp(frontPart);
	}

	class ObjVecComparator implements Comparator<double[]>
	{
		int col = -1;
		public ObjVecComparator(int col ) {
			this.col = col;
		}
		@Override
		public int compare(double[] o1, double[] o2) {
			if( o1[col] > o2[col] )
				return 1;
			else if( o1[col] < o2[col] )
				return -1;
			else 
				return 0;
		} 
	}

	public Population matingSelection(Population popAll) {
		if( popAll.getSize() < ParameterSet.getMu() ) {
			System.err.println("The population has size " + popAll.getSize() + " but " + 
					" in the current implementation it should be at least mu = " + ParameterSet.getMu() );
			System.exit(1);
		}
		Population popNew = new Population();
		for (int i = 0; i < ParameterSet.getMu(); i++) {
			popNew.addIndividual(popAll.getIndividual(i));
		}
		return popNew;
	}

	
}
