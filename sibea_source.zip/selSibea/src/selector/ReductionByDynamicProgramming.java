package selSibea.selector;

import java.util.ArrayList;
import java.util.Comparator;

import selSibea.internal.ObjectiveMatrix;
import selSibea.population.Individual;

public class ReductionByDynamicProgramming {

	public static ArrayList<Integer> reduce( ObjectiveMatrix points, int newSize, double bounds ) {
		int nop = points.nrOfPoints();
		double maxValue;
		int maxIndex = -1;
		double[] currentFitness = new double[ nop  ];

		if( nop < newSize ) {
			System.err.println("The new size is bigger than the current size.");
			System.exit(1);
		}				

		points.sort(0);
		ArrayList<ArrayList<Integer>> subsets = new ArrayList<ArrayList<Integer>>(nop);
		for( int i = 0; i < nop; i++ ) 
			subsets.add(i, new ArrayList<Integer>() ); 

		/* Get contributions fitness */
		for( int i = 0; i < nop; i++ ) {
			(subsets.get(i)).add(i);
			currentFitness[i] = (bounds - points.getVector(i)[0])*(bounds - points.getVector(i)[1]);
		}

		for( int subsetSize = 2; subsetSize <= newSize; subsetSize++ )
		{
			for( int cIndex = newSize-subsetSize; cIndex < nop-subsetSize+1; cIndex++ ) {
				maxValue = -1;
				double tmp;

				for( int pIndex = cIndex+1; pIndex < nop-subsetSize+2; pIndex++ ) {
					tmp = currentFitness[pIndex] + areaDominatedToPartner( points, bounds, cIndex, pIndex );
					if( tmp > maxValue ) {
						maxValue = tmp;
						maxIndex = pIndex;
					}
				}	
				currentFitness[cIndex] = maxValue;
				(subsets.get(cIndex)).clear();
				(subsets.get(cIndex)).add(cIndex);
				(subsets.get(cIndex)).addAll( subsets.get(maxIndex) );				
			}
		}

		maxValue = -1;
		for( int i = 0; i < nop-newSize+1; i++ ) {
			if( currentFitness[i] > maxValue ) {
				maxValue = currentFitness[i];
				maxIndex = i;
			}
		}		
		ArrayList<Integer> subsetIndices = new ArrayList<Integer>();
		for( int i = 0; i < subsets.get(maxIndex).size(); i++)
			subsetIndices.add( points.getIndex( subsets.get(maxIndex).get(i) ) );
		
		return subsetIndices;
	}

	private static double areaDominatedToPartner(ObjectiveMatrix points, double bounds, int c, int p) {
		double height, width;

		height = bounds - points.getVector(c)[1];				
		width = points.getVector(p)[0] - points.getVector(c)[0];

		return width*height;		
	}

	class compareFirstObjective implements Comparator<Individual> {
		@Override
		public int compare(Individual a, Individual b) {
			double fa = ( a.getObjectiveVector() )[0];
			double fb = ( b.getObjectiveVector() )[0];

			return ( fa < fb ? -1 : (fa == fb ? 0 : 1 ));
		}
	}
}
