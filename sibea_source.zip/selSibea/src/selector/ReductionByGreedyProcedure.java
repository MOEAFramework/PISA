package selSibea.selector;

import java.util.ArrayList;
import selSibea.internal.ObjectiveMatrix;
import selSibea.selector.HV;

public class ReductionByGreedyProcedure {
	
	public static ArrayList<Integer> reduce( ObjectiveMatrix points, int newSize, double bounds ) {
		while( points.nrOfPoints() > newSize ) {
			double[] fitness = HV.hvFitness(points, bounds);
			double minValue = Double.MAX_VALUE;
			int minIndex = -1;
			for( int i = 0; i < fitness.length; i++ ) {
				if( fitness[i] < minValue ) {
					minValue = fitness[i];
					minIndex = i;
				}
			}
			points.remove(minIndex);
		}	
		ArrayList<Integer> subsetIndices = new ArrayList<Integer>();
		for( int i = 0; i < points.nrOfPoints(); i++)
			subsetIndices.add( points.getIndex(i) );
		
		return subsetIndices;
	}
}
