package selSibea.selector;

import selSibea.internal.ObjectiveMatrix;


public class HV {
	
	public static double hvIndicator( ObjectiveMatrix points, double bounds ) {
		
		return unaryHypervolumeIndicator(points, bounds);
	}
	
	public static double[] hvFitness(  ObjectiveMatrix points, double bounds ) {
		return hypeFitness( points, bounds, 1);
	}
	
	public static double[] hypeFitnessNew( ObjectiveMatrix points, double bounds, int k ) {
		int nop = points.nrOfPoints();
		int dim = points.nrOfObjectives();

		double[] val = new double[nop];
		double[] alpha = new double[k+1];
		/** Set alpha */
		alpha[0] = -1;
		for( int i = 1; i <= k; i++ )
		{
			alpha[i] = 1.0 / (double) (i*i);
			
			for( int j = 1; j <= i-1; j++ )
				alpha[i] *= (double)(k - j ) / (double)( nop - j );
			
			if( i > 1 )
			alpha[i] = alpha[i]*(-1);
		}
		for( int i = 0; i < nop; i++ )
			val[i] = 0.0;

		int indices[] = new int[nop];
		for( int i = 0; i < nop; i++)
			indices[i] = i;

		double[] p = new double[nop*dim];

		int i = 0;
		for( int j = 0; j < nop; j++ ) {
			double[] tmp = points.getVector(j);
			for( int l = 0; l < dim; l++ ) {
				p[i++] = tmp[l];
			}
		}

		hypeRecursive( p, nop, dim, nop, dim-1, bounds, indices, val, alpha, k);

		return val;
	}
	
	public static double[] hypeFitness( ObjectiveMatrix points, double bounds, int k ) {
		int nop = points.nrOfPoints();
		int dim = points.nrOfObjectives();

		double[] val = new double[nop];
		double[] alpha = new double[k+1];
		/** Set alpha */
		alpha[0] = -1;
		for( int i = 1; i <= k; i++ )
		{
			alpha[i] = 1.0 / (double) (i);
			
			for( int j = 1; j <= i-1; j++ )
				alpha[i] *= (double)(k - j ) / (double)( nop - j );
		}
		for( int i = 0; i < nop; i++ )
			val[i] = 0.0;

		int indices[] = new int[nop];
		for( int i = 0; i < nop; i++)
			indices[i] = i;

		double[] p = new double[nop*dim];

		int i = 0;
		for( int j = 0; j < nop; j++ ) {
			double[] tmp = points.getVector(j);
			for( int l = 0; l < dim; l++ ) {
				p[i++] = tmp[l];
			}
		}

		hypeRecursive( p, nop, dim, nop, dim-1, bounds, indices, val, alpha, k);

		return val;
	}
	
	

	private static void hypeRecursive( double[] points, int pnts, int dim, int nop, int actDim,
			double bounds, int[] input_pvec, double[] fitness, double[] alpha, int k )
	{
		double extrusion;
		int[] pvec = new int[pnts];

		for( int i = 0; i < pnts; i++ ) {
			fitness[i] = 0;
			pvec[i] = input_pvec[i];
		}	
		double[] p = new double[pnts*dim];
		for( int j = 0; j < pnts*dim; j++ ) {
			p[j] = points[j];
		}

		rearrangeIndicesByColumn( p, nop, dim, actDim, pvec );

		for( int i = 0; i < nop; i++ )
		{
			if( i < nop - 1 )
				extrusion = p[ (pvec[i+1])*dim + actDim ] - p[ pvec[i]*dim + actDim ];
			else
				extrusion = bounds - p[ pvec[i]*dim + actDim ];

			if( actDim == 0 ) {
				if( i+1 <= k )
					for( int j = 0; j <= i; j++ ) {
						fitness[ pvec[j] ] = fitness[ pvec[j] ]
						                              + extrusion*alpha[ i+1 ];
					}
			}
			else if( extrusion > 0 ) {
				double[] tmpfit = new double[ pnts ];
				hypeRecursive( p, pnts, dim, i+1, actDim-1, bounds, pvec,
						tmpfit, alpha, k );
				for( int j = 0; j < pnts; j++ )
					fitness[j] += extrusion*tmpfit[j];
			}
		}
	}

	private static void rearrangeIndicesByColumn(double[] mat, int rows, int columns,
			int col, int[] ind) {
		final int MAX_LEVELS = 300;
		int[]  beg = new int[MAX_LEVELS];
		int[]  end = new int[MAX_LEVELS];
		int i = 0; int L; int R; int swap;
		double pref;
		int pind;
		double[] ref = new double[rows];

		for( i = 0; i < rows; i++ ) {
			ref[i] = mat[ col + ind[i]*columns ];
		}
		i = 0;

		beg[0] = 0; end[0] = rows;
		while ( i >= 0 ) {
			L = beg[i]; R = end[i]-1;
			if( L < R ) {
				pref = ref[ L ];
				pind = ind[ L ];
				while( L < R ) {
					while( ref[ R ] >= pref && L < R )
						R--;
					if( L < R ) {
						ref[ L ] = ref[ R ];
						ind[ L++] = ind[R];
					}
					while( ref[L] <= pref && L < R )
						L++;
					if( L < R) {
						ref[ R ] = ref[ L ];
						ind[ R--] = ind[L];
					}
				}
				ref[ L ] = pref; ind[L] = pind;
				beg[i+1] = L+1; end[i+1] = end[i];
				end[i++] = L;
				if( end[i] - beg[i] > end[i-1] - beg[i-1] ) {
					swap = beg[i]; beg[i] = beg[i-1]; beg[i-1] = swap;
					swap = end[i]; end[i] = end[i-1]; end[i-1] = swap;
				}
			}
			else {
				i--;
			}
		}
	}
	
	public static double unaryHypervolumeIndicator(ObjectiveMatrix points, double bound )
	{
		int sizea = points.nrOfPoints();
		int dim = points.nrOfObjectives();
		double pointArray[] = new double[ sizea*dim ];
		double refPoints[] = new double[ dim*2 ];
		int i, k;
		for (i = 0; i < sizea; i++) {
			double[] fitness = points.getVector(i);
			for (k = 0; k < dim; k++)
				pointArray[i * dim + k] = bound - fitness[k];					
		}
		return calc_hypervolume_cubewise(pointArray, refPoints, sizea, dim, dim, bound );
	}

	private static double  calc_hypervolume_cubewise(double[] front, double[] refs,
			int  no_points, int  no_objectives, int dim, double bound)
	{
		int     n;
		double  volume, distance;

		volume = 0;
		distance = 0;
		n = no_points;
		refs[no_objectives - 1] = 0.0;
		while (n > 0)
		{
			int     no_nondominated_points;
			double  temp_vol, temp_dist;

			if (no_objectives > 1)
				no_nondominated_points = filter_nondominated_set(front, dim, n,
						no_objectives - 1);
			else
				no_nondominated_points = filter_nondominated_set(front, dim, n,
						no_objectives);

			assert(no_nondominated_points <= n);
			assert(no_nondominated_points > 0);

			temp_dist = surface_unchanged_to(front, dim, n, no_objectives - 1);
			refs[dim + no_objectives - 1] = temp_dist;

			temp_vol = 0;
			if (no_objectives < 3)
			{
				assert(no_nondominated_points > 0);
				refs[0] = 0.0;
				refs[dim] = front[0];
				temp_vol = calc_hypercube_integral(refs, bound, dim);			
			}
			else
				temp_vol = calc_hypervolume_cubewise(front, refs, no_nondominated_points,
						no_objectives - 1, dim, bound);
			volume += temp_vol;

			refs[no_objectives - 1] = temp_dist;
			distance = temp_dist;
			n = reduce_nondominated_set(front, dim, n, no_objectives - 1, distance);		
		}

		return volume;
	}
	
	private static int reduce_nondominated_set(double[] front, int dim, int  no_points, int objective,
			double  threshold)
	/* remove all points which have a value <= 'threshold' regarding the
dimension 'objective'; the points [0..no_points-1] in 'front' are
considered; 'front' is resorted, such that points [0..n-1] represent
the remaining points; 'n' is returned
	 */
	{
		int  n;
		int  i;

		n = no_points;
		for (i = 0; i < n; i++)
			if (front[i * dim + objective] <= threshold)
			{
				n--;
				swap(front, dim, i, n);
			}

		return n;
	}
	
	private static double calc_hypercube_integral(double[] refs, double bound, int dim )
	{
		double volume=0;


		/*original hypervolume*/
		int  i;
		volume = 1.0;
		for (i = 0; i < dim; i ++)
		{
			volume *= refs[dim + i] - refs[i];
		}

		return volume;
	}



	private static int filter_nondominated_set(double[] front, int dim, int  no_points, int  no_objectives)
	/* all nondominated points regarding the first 'no_objectives' dimensions
are collected; the points 0..no_points-1 in 'front' are
considered; the points in 'front' are resorted, such that points
[0..n-1] represent the nondominated points; n is returned
	 */
	{
		int  i, j;
		int  n;

		n = no_points;
		i = 0;
		while (i < n)
		{
			j = i + 1;
			while (j < n)
			{
				if (dominates( front, i * dim, j * dim,no_objectives) )
				{
					/* remove point 'j' */
					n--;
					swap(front, dim, j, n);
				}
				else if (dominates(front, j * dim, i * dim, no_objectives))
				{
					/* remove point 'i'; ensure that the point copied to index 'i'
  is considered in the next outer loop (thus, decrement i) */
					n--;
					swap(front, dim, i, n);
					i--;
					break;
				}
				else
					j++;
			}
			i++;
		}
		return n;
	}

	private static boolean dominates(double[] points, int ind1, int ind2, int  no_objectives)
	/* returns true if 'point1' dominates 'point2' with respect
	   to the first transformed! 'no_objectives' objectives

	   point1 and point2 don't represent the objective values and are to be 
	   maximized rather than minimized    
	 */
	{
		int  i;
		boolean  better_in_any_objective, worse_in_any_objective;

		better_in_any_objective = false;
		worse_in_any_objective = false;
		for (i = 0; i < no_objectives && !worse_in_any_objective; i++)
			if (points[i+ind1] > points[i+ind2])
				better_in_any_objective = true;
			else if (points[i+ind1] < points[i+ind2])
				worse_in_any_objective = true;
		return (!worse_in_any_objective && better_in_any_objective);
	}


	private static double surface_unchanged_to(double[] front, int dim, int  no_points, int  objective)
	/* calculate next value regarding dimension 'objective'; consider
	points 0..no_points-1 in 'front'
	 */
	{
		int     i;
		double  min, value;

		assert(no_points > 0);
		min = front[objective];
		for (i = 1; i < no_points; i++)
		{
			value = front[i * dim + objective];
			if (value < min)  min = value;
		}

		return min;
	}

	private static void swap(double[] front, int dim, int  i, int  j)
	{
		int  k;
		double  temp;

		for (k = 0; k < dim; k++)
		{
			temp = front[i * dim + k];
			front[i * dim + k] = front[j * dim + k];
			front[j * dim + k] = temp;
		}
	}
}
