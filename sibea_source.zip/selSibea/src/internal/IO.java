package selSibea.internal;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.StringTokenizer;

import selSibea.ParameterSet;
import selSibea.population.Population;

public class IO {

	private String varFile, selFile, cfgFile, iniFile, arcFile;

	public boolean checkArc() {
		return checkFile(arcFile);
	}

	private boolean checkFile(String filename) {
		int controlElement = 1;
		String line;
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			line = br.readLine();
			br.close();
		} catch (Exception ex) {
			return true;
		}
		controlElement = Integer.parseInt(line);
		if (controlElement == 0)
			return false;
		else
			return true;
	}

	public boolean checkSel() {
		return checkFile(selFile);
	}

	public void clearVar() {
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(varFile,
					false));
			br.write("0");
			br.close();
		} catch (Exception ex) {
			System.err.println("Could not clean variator file >" + varFile
					+ "<");
			ex.printStackTrace();
		}
	}

	public void initialize(String paramFile, String filenameBase) {
		String key;
				
		try {
			setFileNames();
			readCfgFile();
			
			FileReader fr = new FileReader(paramFile);
			BufferedReader br = new BufferedReader(fr);
			String inString1 = br.readLine();
			while (inString1 != null) {
				StringTokenizer st1 = new StringTokenizer(inString1);
				while (st1.hasMoreTokens()) {
					key = st1.nextToken();
					ParameterSet.setOption(key, st1 );
				}
				inString1 = br.readLine();
			}
			br.close();
			StateMachine.initializeSeed(ParameterSet.getSeed());
		} catch (Exception ex) {
			System.err.println("Error initializing from >" + paramFile + "<\n");
			ex.printStackTrace();
			System.exit(1);
		}	
	}
	
	private void readCfgFile() throws Exception {
		String key, value;
		BufferedReader br = new BufferedReader(new FileReader(cfgFile));
		
		String input = br.readLine();
		while( ParameterSet.allSet() == false ) {			
			StringTokenizer st = new StringTokenizer(input);
			key = st.nextToken();
			value = st.nextToken();
			ParameterSet.setParameter( key, value );				
			input = br.readLine();
		}
		br.close();
	}

	public int readFlag(String filename) {
		int flag = -1;
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			flag = Integer.parseInt(br.readLine());
			br.close();
		} catch (Exception ex) {
			return -1;
		}
		return flag;
	}

	public boolean readIni(Population pop, int dim, int size) {
		return readPop(iniFile, pop, dim, size);
	}

	private boolean readPop(String filename, Population pop, int dim, int size) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String input = br.readLine();
			long entries = Long.parseLong(input);
			if (entries != size * (dim + 1))
				throw new RuntimeException("Entries (" + entries
						+ ") not equal to size*(dim +1) (" + size + "(" + dim
						+ " + 1)\n");
			for (int j = 0; j < size; j++) {
				input = br.readLine();
				StringTokenizer st = new StringTokenizer(input);
				int index = pop.createIndividual(Integer.parseInt(st
						.nextToken()));

				for (int i = 0; i < dim; i++) {
					pop
							.setFitness(index, Double.parseDouble(st
									.nextToken()), i);
				}
			}
			input = br.readLine();
			if (input.startsWith("END") == false)
				throw new RuntimeException("END tag missing or ill placed in "
						+ filename + "\n");
			br.close();
			return false;
		} catch (Exception ex) {
			System.err.println("Error reading individual from >" + filename
					+ "<\n");
			ex.printStackTrace();
			return true;
		}
	}

	public boolean readVar(Population pop, int dim, int size) {
		return readPop(varFile, pop, dim, size);
	}

	private void setFileNames() {
		cfgFile = ParameterSet.getCommFilePath() + "cfg";
		varFile = ParameterSet.getCommFilePath() + "var";
		selFile = ParameterSet.getCommFilePath() + "sel";
		iniFile = ParameterSet.getCommFilePath() + "ini";
		arcFile = ParameterSet.getCommFilePath() + "arc";
	}

	public void writeArc(Population pop) {
		try {
			if (pop.getSize() != ParameterSet.getAlpha())
				throw new RuntimeException("popAll has size " + pop.getSize()
						+ " instead of " + ParameterSet.getAlpha());
			writePop(arcFile, pop);
		} catch (Exception ex) {
			System.err.println("Could not write archive");
			ex.printStackTrace();
			System.exit(1);
		}
	}

	public void writeFlag(String filename, int state) {
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(filename,
					false));
			br.write("" + state);
			br.close();
		} catch (Exception ex) {
			System.err.println("Error writing the state to >" + filename
					+ "<\n");
			System.err.println(ex.getStackTrace());
			System.exit(1);
		}
	}

	private void writePop(String filename, Population pop) throws Exception {
		BufferedWriter br = new BufferedWriter(new FileWriter(filename, false));
		br.write(pop.getSize() + "\n");
		for (int i = 0; i < pop.getSize(); i++)
			br.write((pop.getIndividual(i)).getIndex() + "\n");
		br.write("END");
		br.close();
	}

	public void writeSel(Population pop) {
		try {
			if (pop.getSize() != ParameterSet.getMu())
				throw new RuntimeException("popSel has size " + pop.getSize()
						+ " instead of " + ParameterSet.getMu());
			writePop(selFile, pop);
		} catch (Exception ex) {
			System.err.println("Could not write archive");
			ex.printStackTrace();
			System.exit(1);
		}
	}

}
