package selSibea.internal;

import java.util.Random;

import selSibea.ParameterSet;
import selSibea.population.Population;
import selSibea.selector.Selector;

public class StateMachine {
	private static StateMachine instance;
	private static IO io;
	private static Population popAll, popSel, popNew;
	private static Random random;
	private static int state = -1;
	private static String stateFile;

	public static StateMachine getInstance(String stateFile) {
		if (StateMachine.instance == null) {
			StateMachine.instance = new StateMachine(stateFile);
		}
		return instance;
	}

	public static Random getRandom() {
		if (random == null) {
			System.err.println("Random number generator not initialized\n");
			System.exit(1);
		}
		return random;
	}

	public static void initializeSeed(long seed) {
		random = new Random(seed);
	}

	private StateMachine() {
	}

	private StateMachine(String stateFile) {
		StateMachine.stateFile = stateFile;
		io = new IO();
	}

	private void iteration() {
		Selector selector = new Selector();
		popAll.addPopulation(popNew);
		selector.environmentalSelection(popAll);
		popSel = selector.matingSelection(popAll);

		io.writeArc(popAll);
		io.writeSel(popSel);
	}
	
	public void run() {
		io.initialize(ParameterSet.getParameterFileName(), ParameterSet
				.getCommFilePath());
		
		popAll = new Population();
		popNew = new Population();

			
		while (state != 6) /*
							 * stop state for selector Caution: if reading of
							 * the statefile fails (e.g. no permission) this is
							 * an infinite loop
							 */

		{
			state = io.readFlag(stateFile);
			if (state == 1) /* inital selection */
			{
				popNew.empty();
				if (io.readIni(popNew, ParameterSet.getDim(), ParameterSet
						.getAlpha()) == false) {
					iteration();
					state = 2;
					io.writeFlag(stateFile, state);
				} /* else don't do anything and wait again */
			} else if (state == 3) {
				popNew.empty();
				if (io.checkArc() == false && io.checkSel() == false) {
					if (io.readVar(popNew, ParameterSet.getDim(), ParameterSet
							.getLambda()) == false) {
						iteration();
						io.clearVar();
						state = 2;
						io.writeFlag(stateFile, state);
					} /* else don't do anything and wait again */
				}
			} else if (state == 5) {
				state = 6;
				io.writeFlag(stateFile, state);
			} else if (state == 9) {
				state = 10;
				io.writeFlag(stateFile, state);
			} else if (state == 10) {
				state = 11;
				io.writeFlag(stateFile, state);
			} else {
				try {
					Thread.sleep(ParameterSet.getPollingInterval());
				} catch (Exception ex) {
					System.err.println("Unable to sleep\n");
					ex.printStackTrace();
				}
			}			
		}
		state = 7;
		io.writeFlag(stateFile, state);
	}
}
