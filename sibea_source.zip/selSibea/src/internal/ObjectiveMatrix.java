package selSibea.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ObjectiveMatrix {
	ArrayList<ObjectiveVector> objVectors = new ArrayList<ObjectiveVector>();
	
	public void addVector(double[] vec, int index) {
		objVectors.add(new ObjectiveVector(vec, index));
	}

	public void remove(int index) {
		objVectors.remove(index);
	}

	public int nrOfPoints() {
		return objVectors.size();
	}

	public int nrOfObjectives() {
		return objVectors.get(0).getDimension();
	}

	public double[] getVector(int index) {
		return objVectors.get(index).getVector();
	}

	public int getIndex(int index) {
		return objVectors.get(index).getIndex();
	}

	public void sort(int col) {
		Collections.sort(objVectors, new ObjVecComparator(col));
	}

	class ObjVecComparator implements Comparator<ObjectiveVector> {
		int col = -1;

		public ObjVecComparator(int col) {
			this.col = col;
		}

		@Override
		public int compare(ObjectiveVector o1, ObjectiveVector o2) {
			if (o1.getVector()[col] > o2.getVector()[col])
				return 1;
			else if (o1.getVector()[col] < o2.getVector()[col])
				return -1;
			else
				return 0;
		}
	}

	class ObjectiveVector {
		private int index;
		private double[] vector;

		@SuppressWarnings("unused")
		private ObjectiveVector() {
		}

		public int getDimension() {
			return vector.length;
		}
		
		public int getIndex() {
			return index;
		}

		public double[] getVector() {
			return vector;
		}

		public ObjectiveVector(double[] vector, int index) {
			this.index = index;
			this.vector = vector;
		}
	}

}
