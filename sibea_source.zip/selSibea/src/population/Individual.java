package selSibea.population;

public class Individual {
	private long index;
	private double[] objectiveVector;
	private double fitness;

	@SuppressWarnings("unused")
	private Individual() {
	}

	public Individual(long index, int dim) {
		this.index = index;
		objectiveVector = new double[dim];
	}

	public boolean dominatedBy(Individual contendor) { /*
														 * Does the contendor
														 * dominate this
														 * individual
														 */
		boolean equal = true;
		boolean abetter = false;

		for (int i = 0; i < objectiveVector.length && !abetter; i++) {
			abetter = this.objectiveVector[i] < contendor.objectiveVector[i];
			equal = (this.objectiveVector[i] == contendor.objectiveVector[i])
					&& equal;
		}
		return (!equal && !abetter);
	}

	public long getIndex() {
		return index;
	}

	public double[] getObjectiveVector() {
		return objectiveVector;
	}

	public void print() {
		System.out.print("Ind. " + index + ", objectives: ( ");
		for (double val : objectiveVector)
			System.out.print(val + " ");
		System.out.println(") -> fitness " + fitness);
	}

	public void setObjectiveValue(double value, int obj) {
		objectiveVector[obj] = value;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	public double getFitness() {
		return fitness;
	}

	public void printObjectivesMatlabFriendly() {
		for (double val : objectiveVector)
			System.out.print(val + " ");
		System.out.println("");
		
	}
}
