package selSibea.population;

import java.util.ArrayList;

public class FrontPart {

	private ArrayList<ArrayList<Integer>> frontArray;
	private Population pop;
	private int totalSize = 0;

	public FrontPart() {
	}

	public void clearAll() {
		if( frontArray != null )
			frontArray.clear();	
		totalSize = 0;
		pop = null;
	}
	
	public int getFrontSize(int i) {
		return (frontArray.get(i)).size();
	}

	public int getIndex(int front, int member) {
		return (frontArray.get(front)).get(member);
	}

	public Individual getIndividual(int front, int member) {
		return pop.getIndividual(getIndex(front, member));
	}

	public int getNrOfFronts() {
		return frontArray.size();
	}

	public int getTotalSize() {
		return totalSize;
	}

	private void insertInPart(int nr, int index) {

		while (frontArray.size() < nr + 1) {
			ArrayList<Integer> members = new ArrayList<Integer>();
			frontArray.add(members);
		}

		(frontArray.get(nr)).add(new Integer(index));
		totalSize++;
	}

	public void partition(Population pop) {
		clearAll();
		this.pop = pop;
		frontArray = new ArrayList<ArrayList<Integer>>();

		boolean checked[] = new boolean[pop.getSize()];
		boolean actChecked[] = new boolean[pop.getSize()];
		boolean notDominated;

		int added = 0;
		int actFront = 0;

		while (added < pop.getSize()) {
			for (int i = 0; i < pop.getSize(); i++) {
				if (checked[i] == true)
					continue;
				actChecked[i] = false;
				notDominated = true;
				int j = 0;
				while (notDominated == true && j < pop.getSize()) {
					if (i != j && checked[j] == false && pop.dominatedBy(i, j))
						notDominated = false;
					j++;
				}
				if (notDominated) {
					actChecked[i] = true;
					insertInPart(actFront, i);
					added++;
				}
			}
			for (int j = 0; j < pop.getSize(); j++)
				if (actChecked[j] == true)
					checked[j] = true;
			actFront++;
		}
	}
	
	public void print() {
		System.out.println("Front Partition " + this.toString());
		for (int front = 0; front < getNrOfFronts(); front++) {
			System.out.println("Front " + front);
			for (int member = 0; member < getFrontSize(front); member++) {
				Individual ind = getIndividual(front, member);
				System.out.print("\t");
				ind.print();
			}
		}
	}

	public void removeFront(int i) {
		totalSize -= (frontArray.get(i)).size();
		frontArray.remove(i);
	}

	public void removeIndividual(int front, int index) {
		totalSize--;
		(frontArray.get(front)).remove(index);
	}

	public double[][] convertFrontToArray(int front) {
		double [][] p = new double[getFrontSize(front)][];
		for( int member = 0; member < getFrontSize(front); member++ ) {
			p[member] = ( getIndividual(front, member) ).getObjectiveVector();
		}
		return p;
	}

	public void printFrontMatlabFriendly(int front) {
		System.out.print("F = [ ");
		for( int member = 0; member < getFrontSize(front); member++ ) {
			( getIndividual(front, member) ).printObjectivesMatlabFriendly();
		}
		System.out.println("]");
	}

	public void removeWorstIndividualFromFront(int front ) {
		try {
			double minimum = getIndividual(front, 0).getFitness();
			int index = 0;
			for( int i = 1; i < getFrontSize(front); i++ ) {
				if( getIndividual(front, i).getFitness() < minimum ) {
					minimum = getIndividual(front, i).getFitness();;
					index = i;
				}
			}
			removeIndividual(front, index);			
		} catch( Exception ex ) {
			ex.printStackTrace();
		}
	}

	public Individual[] getFront(int front) {
		Individual[] inds = new Individual[ getFrontSize(front) ];
		for( int member = 0; member < getFrontSize(front); member++ ) {
			inds[member] = getIndividual(front, member);
		}		
		return inds;
	}
}
