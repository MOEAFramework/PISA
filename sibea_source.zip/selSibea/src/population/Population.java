package selSibea.population;

import java.util.ArrayList;

import selSibea.ParameterSet;

public class Population {

	ArrayList<Individual> population;

	public Population() {
		population = new ArrayList<Individual>();
	}

	public int addIndividual(Individual ind) {
		population.add(ind);
		return population.size() - 1;
	}

	public void addPopulation(Population popNew) {
		for (int i = 0; i < popNew.getSize(); i++) {
			(this.population).add(popNew.getIndividual(i));
		}
	}

	public void cleanUp(FrontPart frontPart) {
		ArrayList<Individual> newPop = new ArrayList<Individual>();
		for (int i = 0; i < frontPart.getNrOfFronts(); i++) {
			for (int j = 0; j < frontPart.getFrontSize(i); j++) {
				newPop.add(population.get(frontPart.getIndex(i, j)));
			}
		}
		population = newPop;
	}

	public int createIndividual(int index) {
		population.add(new Individual(index, ParameterSet.getDim()));
		return population.size() - 1;
	}

	public boolean dominatedBy(int a, int b) {
		Individual inda = population.get(a);
		Individual indb = population.get(b);

		return inda.dominatedBy(indb);
	}

	public void empty() {
		population.clear();
	}

	public Individual getIndividual(int index) {
		return population.get(index);
	}

	public int getSize() {
		return population.size();
	}

	public void print() {
		System.out.println("Printing Population " + this.toString());
		System.out.println("Size = " + this.getSize());
		System.out.println("Individuals:");
		for (int i = 0; i < this.getSize(); i++) {
			Individual ind = this.getIndividual(i);
			System.out.print("\t " + i + ": ");
			ind.print();
		}
	}

	public void setFitness(int index, double val, int obj) {
		(population.get(index)).setObjectiveValue(val, obj);
	}
}
