#!/bin/sh
./femo femo_param.txt ../PISA_ 0.1
