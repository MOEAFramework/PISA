#!/bin/sh
./ecea ecea_param.txt ../PISA_ 0.1
