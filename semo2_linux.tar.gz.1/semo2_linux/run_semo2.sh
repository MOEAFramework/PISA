#!/bin/sh
./semo2 semo2_param.txt ../PISA_ 0.1
