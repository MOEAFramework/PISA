package expo.plot;

/**
 * <p>Title: Design Space Exploration Tool for Network Processors</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Simon Kuenzli
 * @version 1.0
 */

// This class is SPS specific. It is not generic and should be rewritten.
import sps.*;

import java.io.*;
import expo.*;
import org.apache.batik.dom.svg.SVGDOMImplementation;
import org.apache.batik.dom.svg.SVGOMDocument;
import org.apache.batik.swing.gvt.GVTTreeRendererAdapter;
import org.apache.batik.swing.gvt.GVTTreeRendererEvent;
import org.apache.batik.dom.*;
import org.w3c.dom.*;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import javax.swing.*;
import java.awt.*;
import java.text.*;
import javax.swing.event.*;
import java.awt.event.*;
import org.apache.batik.svggen.SVGGraphics2D;
import org.w3c.dom.svg.SVGDocument;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.transcoder.image.PNGTranscoder;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.xalan.serialize.SerializerToXML;


import curve2.UpperCurve;
import org.apache.batik.swing.*;


public class SVGPlotter extends JFrame{



  protected int implID;
  JButton[] scenarioButton = new JButton[((SPSSpecification)EXPO.specification).Scenarios.length];
  JButton buttonSaveJpg = new JButton("Save JPG");
  JButton buttonClose = new JButton("close");
  JButton buttonSavePNG = new JButton("Save PNG");
  JButton buttonSaveSVG = new JButton("Save SVG");
  JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
  JPanel panel = new JPanel(new BorderLayout());
  JScrollPane jScrollPane1 = new JScrollPane();
  JSVGCanvas svgCan = new JSVGCanvas();
  JPanel contentPane;

  public SVGPlotter() {
   try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }


    class ScenarioListener
        implements java.awt.event.ActionListener {

      SVGPlotter adaptee;
      int id;

      ScenarioListener(SVGPlotter adaptee, int id) {
        this.adaptee = adaptee;
        this.id=id;
      }

      public void actionPerformed(ActionEvent e) {
        adaptee.scenarioSelected_actionPerformed(e,id);
      }
    }


  class SVGSaveListener
      implements java.awt.event.ActionListener {

    SVGPlotter adaptee;

    SVGSaveListener(SVGPlotter adaptee) {
      this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
      adaptee.saveSVG_actionPerformed(e);
    }
  }

  class PNGSaveListener
      implements java.awt.event.ActionListener {

    SVGPlotter adaptee;

    PNGSaveListener(SVGPlotter adaptee) {
      this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
      adaptee.savePNG_actionPerformed(e);
    }
  }

  class CloseListener
      implements java.awt.event.ActionListener {

    SVGPlotter adaptee;

    CloseListener(SVGPlotter adaptee) {
      this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
      adaptee.setVisible(false);
      adaptee.dispose();
    }
  }


  class JPGSaveListener
      implements java.awt.event.ActionListener {

    SVGPlotter adaptee;

    JPGSaveListener(SVGPlotter adaptee) {
      this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
      adaptee.saveJPG_actionPerformed(e);
    }
  }


  public void scenarioSelected_actionPerformed(ActionEvent e, int id){
    drawImplementation( this.implID, id);
  }

  public void savePNG_actionPerformed(ActionEvent e){
    JFileChooser fc = new JFileChooser();
    fc.showSaveDialog(this);
    PNGTranscoder pngTrans = new PNGTranscoder();
    try{
      FileOutputStream fos = new FileOutputStream(fc.getSelectedFile());
      TranscoderInput input = new TranscoderInput(svgCan.getSVGDocument());
      TranscoderOutput output = new TranscoderOutput(fos);
      pngTrans.transcode(input,
                         output);
      fos.flush();
      fos.close();
      System.out.println("PNG written to file.");
    }
    catch (Exception ee){
      System.err.println("Transcoding failed...");
    }

  }

  public void saveJPG_actionPerformed(ActionEvent e){
    JFileChooser fc = new JFileChooser();
    fc.showSaveDialog(this);
    JPEGTranscoder jpgTrans = new JPEGTranscoder();
    jpgTrans.addTranscodingHint(JPEGTranscoder.KEY_QUALITY,
                             new Float(.8));

    try{
      FileOutputStream fos = new FileOutputStream(fc.getSelectedFile());
      TranscoderInput input = new TranscoderInput(svgCan.getSVGDocument());
      TranscoderOutput output = new TranscoderOutput(fos);
      jpgTrans.transcode(input,
                         output);
      fos.flush();
      fos.close();
      System.out.println("JPEG written to file.");
    }
    catch (Exception ee){
      System.err.println("Transcoding failed...");
    }
  }

  public void saveSVG_actionPerformed(ActionEvent e){
    // uses xalan
    JFileChooser fc = new JFileChooser();
    fc.showSaveDialog(this);
    SVGDocument doc = svgCan.getSVGDocument();

    File file = fc.getSelectedFile();
    try{
    FileWriter fw = new FileWriter(file);
    SerializerToXML ser = new SerializerToXML();
    ser.setWriter(fw);
    ser.serialize(doc);
    fw.flush();
    fw.close();
    System.out.println("SVG written to File.");
  }
    catch (Exception ee){
      System.err.println("Save as SVG failed...");
    }
  }


  public boolean drawImplementation(int id, int scenarioID) {

    this.implID = id;
    this.setTitle("Implementation Nr. " + id +"  (EXPO, Institute TIK, ETH Zurich)");
    // get the gene to be plotted & evaluate it.
    SPSGene myGene = (SPSGene) EXPO.population.getGene(id);
    SPSImplementation myImpl = new SPSImplementation();
    String tmp_strg = "";
    myImpl.initSize();
    for (int i = 0; i < myGene.numberOfScenarios; i++) {
      for (int j = 0; j < myGene.numberOfTasks; j++) {
        myImpl.STBinding[i][j] = ((SPSSpecification)EXPO.specification).Resources[myGene.STBinding[i][j]];
      }
      for (int j = 0; j < myGene.numberOfFlows; j++) {
        myImpl.SFPriority[i][j] = ((SPSSpecification)EXPO.specification).Flows[myGene.SFPriority[i][j]];
      }
    }
    for (int i = 0; i < myGene.numberOfResources; i++) {
      myImpl.RAllocation[i] = myGene.RAllocation[i];
    }
    myImpl.computeTotalCost();
    myImpl.computeDelayMemory();


    // write implementation to SVG
    DOMImplementation impl = SVGDOMImplementation.getDOMImplementation();
    String svgNS = SVGDOMImplementation.SVG_NAMESPACE_URI;
    Document doc = impl.createDocument(svgNS, "svg", null);

    // get the root element (the svg element)
    Element svgRoot = doc.getDocumentElement();

    // add scaling factors for individual scenarios
    int textOffset = 23;
    Element scenarioName = doc.createElementNS(svgNS, "text");
    DecimalFormat formatter = new DecimalFormat("###0.000");
    Node sNameContent = doc.createTextNode( "Scenario: "+( (SPSSpecification) EXPO.specification).SName[scenarioID]);
    scenarioName.appendChild(sNameContent);
    scenarioName.setAttributeNS(null, "x", "20");
    scenarioName.setAttributeNS(null, "y", Integer.toString(textOffset));
    scenarioName.setAttributeNS(null,"style","fill:red");
    svgRoot.appendChild(scenarioName);

    scenarioName = doc.createElementNS(svgNS, "text");
    sNameContent = doc.createTextNode("Optimal Scaling Factor: "+formatter.format(myImpl.SScale[scenarioID]));
    scenarioName.appendChild(sNameContent);
    scenarioName.setAttributeNS(null, "x", "20");
    scenarioName.setAttributeNS(null, "y", Integer.toString(textOffset+20));
    svgRoot.appendChild(scenarioName);


    scenarioName = doc.createElementNS(svgNS, "text");
    sNameContent = doc.createTextNode("Total Memory: "+formatter.format(myImpl.STotalMemory[scenarioID]));
    scenarioName.appendChild(sNameContent);
    scenarioName.setAttributeNS(null, "x", "20");
    scenarioName.setAttributeNS(null, "y", Integer.toString(textOffset+40));
    svgRoot.appendChild(scenarioName);

    // create for each resource allocated rectangle
    int positionCounter = 0;
    int scenarioOffset = 255;
    int rectangleOffset = 80;
    /// put all allocated resources
    for (int i = 0; i< myGene.RAllocation.length; i++){
      if (myGene.RAllocation[i] >0){
        positionCounter++;
        Element rectangle = doc.createElementNS(svgNS, "rect");
        rectangle.setAttributeNS(null, "x",
                                 Integer.toString(positionCounter * 110));
        rectangle.setAttributeNS(null, "y", Integer.toString(rectangleOffset));
        rectangle.setAttributeNS(null, "width", "100");
        rectangle.setAttributeNS(null, "height", "70");
        rectangle.setAttributeNS(null, "style", "fill:lightblue");
        svgRoot.appendChild(rectangle);
        Element text = doc.createElementNS(svgNS, "text");
        text.setAttributeNS(null, "x",
                            Integer.toString(positionCounter * 110 + 5));
        Node content = doc.createTextNode( ( (SPSSpecification) EXPO.
                                            specification).RName[i]);
        text.appendChild(content);
        text.setAttributeNS(null, "y", Integer.toString(rectangleOffset+15));
        svgRoot.appendChild(text);
        text = doc.createElementNS(svgNS, "text");
        text.setAttributeNS(null, "x",
                            Integer.toString(positionCounter * 110 + 5));
        text.setAttributeNS(null, "y", Integer.toString(rectangleOffset+45));
        content = doc.createTextNode("Utilization: " +
                                     Long.toString(myImpl.RUtilization[
            scenarioID][i]) +
                                     "%");
        text.appendChild(content);
        svgRoot.appendChild(text);

        Element connector = doc.createElementNS(svgNS, "line");
        connector.setAttributeNS(null, "x1",
                                 Integer.toString(positionCounter * 110 + 50));
        connector.setAttributeNS(null, "y1", Integer.toString(rectangleOffset+70));
        connector.setAttributeNS(null, "x2",
                                 Integer.toString(positionCounter * 110 + 50));
        connector.setAttributeNS(null, "y2", Integer.toString(rectangleOffset+90));
        connector.setAttributeNS(null, "stroke", "#000000");
        connector.setAttributeNS(null, "stroke-width", "3");
        svgRoot.appendChild(connector);
      }
      }

    /// add Bus
    Element busRect = doc.createElementNS(svgNS, "path");
    int rightX = positionCounter*110+30;
    busRect.setAttributeNS(null, "d" ,"m 90 "+Integer.toString(rectangleOffset+90)+" h "+Integer.toString(rightX)+" v -10 l 50 30 l -50 30 v -10 h -"+Integer.toString(rightX)+" v 10 l -50 -30 l 50 -30 v 10   ");
    busRect.setAttributeNS(null, "fill", "none");
    busRect.setAttributeNS(null, "stroke", "#000000");
    busRect.setAttributeNS(null, "stroke-width", "3");
    svgRoot.appendChild(busRect);

    int[] flowOffset = new int[myGene.numberOfFlows+1];
    flowOffset[0]=10;
    Element text;
    Node content;

    for (int j = 0; j < myGene.numberOfFlows; j++) {
      if (flowPresent(j,scenarioID)){
      positionCounter = 0;
      int internalTaskPosition = 20;
      text = doc.createElementNS(svgNS, "text");
      text.setAttributeNS(null, "x", Integer.toString(20));
      text.setAttributeNS(null, "y", Integer.toString(scenarioOffset+flowOffset[j]));
      content = doc.createTextNode("Flow: "+((SPSSpecification)EXPO.specification).FName[j]);
      text.appendChild(content);
      text.setAttributeNS(null,"style","fill:red");
      svgRoot.appendChild(text);

      text = doc.createElementNS(svgNS, "text");
      text.setAttributeNS(null, "x", Integer.toString(170));
      text.setAttributeNS(null, "y", Integer.toString(scenarioOffset+flowOffset[j]));
      // adjust priority to be >=1
      int prio = myGene.SFPriority[scenarioID][j]+1;
      content = doc.createTextNode("Priority: "+prio);
      text.appendChild(content);
      text.setAttributeNS(null,"style","fill:red");
      svgRoot.appendChild(text);

      text = doc.createElementNS(svgNS, "text");
      text.setAttributeNS(null, "x", Integer.toString(320));
      text.setAttributeNS(null, "y", Integer.toString(scenarioOffset+flowOffset[j]));
      content = doc.createTextNode("Acc. Waiting Time in Queue: "+formatter.format(myImpl.SFAccumulatedDelay[scenarioID][j]));
      text.appendChild(content);
      text.setAttributeNS(null,"style","fill:red");
      svgRoot.appendChild(text);

      for (int i = 0; i < myGene.numberOfResources; i++) {
        if (myGene.RAllocation[i] > 0) {
          internalTaskPosition = 20;
          positionCounter++;
          for (int k = 0; k < myGene.numberOfTasks; k++) {
            if (myGene.STBinding[scenarioID][k] == i) {
              for (int m = 0;m <( (SPSSpecification) EXPO.specification).FTasks[j].length; m++) {
                if ( ( (SPSSpecification) EXPO.specification).FTasks[j][m].id ==k) {
                  text = doc.createElementNS(svgNS, "text");
                  text.setAttributeNS(null, "x",Integer.toString(positionCounter * 110 +5));
                  text.setAttributeNS(null, "y",Integer.toString(internalTaskPosition +scenarioOffset + flowOffset[j]));
                  internalTaskPosition = internalTaskPosition + 13;
                  content = doc.createTextNode( ( (SPSSpecification) EXPO.specification).TName[k]);
                  text.appendChild(content);
                  svgRoot.appendChild(text);
                }
              }
              flowOffset[j+1] = Math.max(flowOffset[j+1], flowOffset[j] + internalTaskPosition+10);
            }
          }

        }
      }

    }
          flowOffset[j+1] = Math.max(flowOffset[j+1], flowOffset[j]);
    }
    ///sk
    svgRoot.setAttributeNS(null, "height", Integer.toString(scenarioOffset+flowOffset[myGene.numberOfFlows]));
    svgRoot.setAttributeNS(null, "width", Integer.toString(Math.max(positionCounter*110+250, 550)));
    /// write to canvas
    try {
      svgCan.setSVGDocument((SVGOMDocument)doc);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    svgCan.setSize(new Dimension(1000, scenarioOffset+flowOffset[myGene.numberOfFlows]));
    return true;
  }


  public JComponent getSVGCanvas(){
    return (JComponent) svgCan;
  }

  public boolean flowPresent(int j, int scenarioID) {
    UpperCurve uc = ( (SPSSpecification) EXPO.specification).SFUpperArrival[
        scenarioID][j];
    if ( (uc.getS() == 0) &&
        (uc.getR() == 0) &&
        (uc.getQ() == 0)) {
      return false;
    }
    return true;
  }


  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    svgCan = new JSVGCanvas();
    buttonSaveJpg.addActionListener(new JPGSaveListener(this));
    buttonClose.addActionListener(new CloseListener(this));
    buttonSavePNG.addActionListener(new PNGSaveListener(this));
    buttonSaveSVG.addActionListener(new SVGSaveListener(this));

    for (int i = 0;
         i < ( (SPSSpecification) EXPO.specification).Scenarios.length; i++) {
      scenarioButton[i] = new JButton( ( (SPSSpecification) EXPO.specification).
                                      SName[i]);
      scenarioButton[i].addActionListener(new ScenarioListener(this, i));
    }

    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    //jScrollPane1.setAutoscrolls(true);
    p.add(buttonSaveSVG);
    p.add(buttonSaveJpg);
    p.add(buttonSavePNG);
    p.add(buttonClose);
    p.add(new JLabel("Scenarios: "));
    for (int i = 0;
         i < ( (SPSSpecification) EXPO.specification).Scenarios.length; i++) {
      p.add(scenarioButton[i]);
    }
    jScrollPane1.getViewport().add(svgCan,null);
    panel.add(jScrollPane1, BorderLayout.CENTER);
    panel.add(p, BorderLayout.NORTH);
    contentPane.add(panel);
    this.setSize(1000,600);
    this.show();
    svgCan.addGVTTreeRendererListener(new GVTTreeRendererAdapter() {
            public void gvtRenderingPrepare(GVTTreeRendererEvent e) {
              /// do nothing
            }
            public void gvtRenderingCompleted(GVTTreeRendererEvent e) {
                svgCan.revalidate();
            }
        });
  }
  }
