package expo.plot;

import ptolemy.plot.Plot;
import ptolemy.plot.EditablePlot;
import javax.swing.JFrame;
import java.awt.event.*;
import java.awt.Dimension;
import java.lang.NoSuchMethodException;

/**
 * Title:        EXPO
 * Description:  Design Space Exploration for Packet Processors
 * Copyright:    Copyright (c) 2001
 * Company:      ETH Zurich<p><p>
 *
 * The class PopulationPlot shows a new frame with a Ptolemy plot
 * when initialized. Its purpose is to show points which
 * represent the current population.
 *
 * @author Lothar Thiele
 * @version 1.0
 */

public class PopulationPlot
    extends JFrame {

  /**
   * A new Ptolemy plot.
   */
  public Plot pt = new Plot();

  protected int[] _geneID;
  protected double[] _x;
  protected double[] _y;
  /**
   * Initializes the frame and a default Ptolemy plot.
   * @param xLoc x-coordinate of the plot on the screen. May be multiple of 400.
   * @param yLoc y-coordinate of the plot on the screen. May be multiple of 300.
   */
  public PopulationPlot(int xLoc, int yLoc) {
    this();
    pt.setSize(400, 300);
    pt.setButtons(true);
    pt.setTitle("current population");
    pt.setXLabel("x axis");
    pt.setYLabel("y axis");
    pt.setMarksStyle("none");
    pt.setConnected(true);
    pt.setMarksStyle("dots");

    pt.addMouseListener(new MyListener());

    setSize(400, 300);
    setLocation(xLoc, yLoc);
    getContentPane().add(pt);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    show();
  }

  /**
   * Plots points.
   * @param x x-coordinates of the points.
   * @param y y-coordinates of the points.
   */
  public void drawPoints(double[] x, double[] y, int[] geneID) {

    _geneID = new int[geneID.length];
    _x = new double[x.length];
    _y = new double[y.length];

    for (int i = 0; i < x.length; i++) {
      _geneID[i] = geneID[i];
      _x[i] = x[i];
      _y[i] = y[i];
      pt.addPoint(0, x[i], y[i], false);
    }
    pt.fillPlot();
  }

  public PopulationPlot() {
    this.setTitle("EXPO, Institute TIK, ETH Zurich");
  }


  /**
   * This class is used as a MouseListener. We make use
   * of the mouseClicked-method only.
   */
  public class MyListener implements MouseListener {

    /**
     * This method is used to check, whether a mouse click event
     * occured inside the plotting area of the population plot
     * window. If so, the ID corresponding to the clicked point
     * is written to a dialog.
     */
    public void mouseClicked(MouseEvent event) {

      int id = -1;
      int _lry = pt.getLRY();
      int _lrx = pt.getLRX();
      int _ulx = pt.getULX();
      int _uly = pt.getULY();
      double _padding = pt.getPadding();

      int graphX = event.getX();
      int graphY = event.getY();

      // check whether click happened inside the plot window.
      double[] xAxis = pt.getXRange();
      double[] yAxis = pt.getYRange();
      if ( (graphX > _ulx) && (graphX < _lrx)
          && (graphY > _uly) && (graphY < _lry)) {
        double scaledX = (double) (graphX - _ulx) / (_lrx - _ulx);
        double scaledY = (double) (graphY - _lry) / (_uly - _lry);
        xAxis[0] = xAxis[0] - (xAxis[1] - xAxis[0]) * _padding;
        xAxis[1] = xAxis[1] + (xAxis[1] - xAxis[0]) * _padding;
        yAxis[0] = yAxis[0] - (yAxis[1] - yAxis[0]) * _padding;
        yAxis[1] = yAxis[1] + (yAxis[1] - yAxis[0]) * _padding;
        double xEpsilon = Math.abs(0.02 * (xAxis[1] - xAxis[0]));
        double yEpsilon = Math.abs(0.02 * (yAxis[1] - yAxis[0]));
        double actualX = scaledX * (xAxis[1] - xAxis[0]) + xAxis[0];
        double actualY = scaledY * (yAxis[1] - yAxis[0]) + yAxis[0];
        try {
          for (int i = 0; i < _geneID.length; i++) {
            if ( (Math.abs(_x[i] - actualX) < xEpsilon) &&
                (Math.abs(_y[i] - actualY) < yEpsilon)) {
              id = _geneID[i];
            }
          }
          if (id > -1) {
            try{
              if (event.getButton() == MouseEvent.BUTTON1) {
                // left button clicked
                javax.swing.JOptionPane.showMessageDialog(pt,
                    new String("Gene number: " + id),
                    "Population Plot",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE);
              }
              else if (event.getButton() == MouseEvent.BUTTON3) {
                // right button clicked
                String tempString = expo.EXPO.population.getGene(id).
                    getShortDescription();
                SVGPlotter svgPlot = new SVGPlotter();
                svgPlot.drawImplementation(id, 0);
              }
            }
            catch (NoSuchMethodError ee){
              javax.swing.JOptionPane.showMessageDialog(pt,
                    new String("Gene number: " + id),
                    "Population Plot",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE);
            }
          }
        }
        catch (Exception e) {
          // just go ahead.
          // e.printStackTrace();
        }
      }
      else {
        //System.out.println("Point outside plotting area");
      }
    }

    /**
     * not implemented
     */
    public void mouseMoved(MouseEvent event) {
    }

    /**
     * not implemented
     */
    public void mouseExited(MouseEvent event) {
    }

    /**
     * not implemented
     */
    public void mouseEntered(MouseEvent event) {
    }

    /**
     * not implemented
     */
    public void mousePressed(MouseEvent event) {
    }

    /**
     * not implemented
     */
    public void mouseReleased(MouseEvent event) {
    }
  }



}