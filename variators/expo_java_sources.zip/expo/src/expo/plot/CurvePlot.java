package expo.plot;

import ptolemy.plot.*;
import curve2.*;
import javax.swing.JFrame;

/**
 * Title:        EXPO
 * Description:  Design Space Exploration for Packet Processors
 * Copyright:    Copyright (c) 2001
 * Company:      ETH Zurich<p><p>
 *
 * The class CurvePlot shows a new frame with a Ptolemy plot
 * when initialized. Its purpose is to represent lower and
 * upper curves.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class CurvePlot extends JFrame {

/**
 * A new Ptolemy plot.
 */
  public Plot pt = new Plot();

/**
 * The maximal x-coordinate.
 */
  double maxX;

/**
 * Counts the curves which are plotted.
 */
  static int count = 0;

/**
 * Initializes the frame and a default Ptolemy plot.
 * @param maxX The plot is drawn for [0,maxX].
 * @param xLoc x-coordinate of the plot on the screen. May be multiple of 400.
 * @param yLoc y-coordinate of the plot on the screen. May be multiple of 300.
 */
  public CurvePlot(double maxX, int xLoc, int yLoc) {

    this.maxX = maxX;

    pt.setSize(400,300);
    pt.setButtons(true);
    pt.setTitle("arrival and service curves");
    pt.setXLabel("time interval");
    pt.setYLabel("events");
    pt.setMarksStyle("none");
    pt.setConnected(true);
    pt.setMarksStyle("dots");

    setSize(400, 300);
    setLocation(xLoc, yLoc);
    getContentPane().add(pt);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    show();
  }

/**
 * Adds a new curve to the plot and sets the new ranges.
 * @param name The name of the new curve.
 * @param curve The curve to be plotted.
 */
  public void addCurve(String name, Curve curve) {
    pt.setXRange(0, maxX);
    pt.addLegend(count, name);
    pt.addPoint(count, 0.0, 0.0, false);
    if (curve.getP() < maxX) {
      pt.addPoint(count, curve.getP(), curve.getR() * curve.getP(), true);
      pt.addPoint(count, maxX, curve.getQ() + maxX * curve.getS(), true);
    } else {
      pt.addPoint(count, maxX, curve.getR() * maxX, true);
    }
    pt.setXRange(0, maxX);
    count = count + 1;
    pt.fillPlot();
  }
}