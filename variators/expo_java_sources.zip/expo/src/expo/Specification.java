/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package expo;

import java.io.File;

 /**
 * This interface has to be implemented by all classes which figure as problem
 * specification descriptions in the context of this design space exporation tool.
 * There are only two methods which can be called by classes which are not part
 * of a specific problem. The main method tells the Specification to read
 * the description of a problem from a file.
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
public interface Specification {

  /**
   * <code>simpleFileInput</code> reads all specification data given in the
   * file at fileHandle.
   * @param fileHandle File of specification file
   * @return String which contains error message
   */
  public String simpleFileInput(File fileHandle);

  /**
   * This method has to return the number of objectives the full problem deals
   * with. This method will be called by the EXPO class to be able to plot the
   * population.
   * @return int value with number of problem objectives.
   */
  public int getProblemDimension();

  /**
   * This method has to return the probability with which an individual has to
   * be mutated. This probability has to be a double between 0.0 and 1.0,
   * whereas 1.0 means that all the genes will have to be mutated.
   */
  public double getMutationProbability();


  /**
   * This method has to return the probability with which two individuals
   * have to be crossed. This probability has to be a double between
   * 0.0 and 1.0, whereas 1.0 means that all the genes will have to be crossed.
   */
  public double getCrossoverProbability();


}