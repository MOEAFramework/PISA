package expo;

/**
 * <p>Title: Design Space Exploration Tool for Network Processors</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Simon Kuenzli
 * @version 1.0
 */

import java.util.*;

public class Archive {

  protected ArrayList archivedItems = new ArrayList();

  public Archive() {
  }


  public void add(ArrayList itemToAdd){
    ArrayList removeList = new ArrayList();
    for (Iterator iter = archivedItems.iterator(); iter.hasNext();){
      ArrayList compareItem = (ArrayList) iter.next();
      if (dominates(compareItem,itemToAdd)){
        return;
      }
      if (dominates(itemToAdd, compareItem)){
        removeList.add(compareItem);
      }
    }
    for (Iterator iter = removeList.iterator();iter.hasNext();){
      archivedItems.remove(iter.next());
    }
    archivedItems.add(itemToAdd);
  }


  protected boolean dominates(ArrayList first, ArrayList second){
    boolean dominates = true;
    Iterator iter2 = second.iterator();
    for (Iterator iter = first.iterator(); iter.hasNext();){
      double one = ((Double) iter.next()).doubleValue();
      double two = ((Double) iter2.next()).doubleValue();
      if ((one <= two) && dominates) {
        dominates = true;
      }
      else {
        dominates = false;
      }
    }
    return dominates;
  }

  public String getString(){
    String temp ="";
    for (Iterator iter = archivedItems.iterator();iter.hasNext();){
      ArrayList element = (ArrayList) iter.next();
      for (Iterator iter2 = element.iterator();iter2.hasNext();){
        temp += " "+(iter2.next());
      }
      temp+=" \r\n";
    }
    return temp;
  }
}