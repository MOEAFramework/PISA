/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */
package expo;

import java.util.ArrayList;

/**
 * This interface has to be implemented by all classes which should be able
     * to analyze a gene. The main purpose of such a class is to calculate different
 * fitness values for a gene. Additionally a class implementing this interface
 * has to provide methods to draw and to write reports about the analysis of
 * the gene.
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
public interface Analyzer {

  /**
   * This method of the Analyzer interface analyzes a gene which is given by parameter
   * gene and returns an ArrayList with all the fitness values of the gene as doubles.
   * The larger a fitness value is, the weaker the gene.
       * @param gene Object which implements the Gene interface and describes a gene of
   * the population.
   * @return ArrayList which contains all fitness values of gene
   */
  public ArrayList analyze(Gene gene);

  /**
   * This method returns a report in a textual form. In the string, all facts of the gene, such as
   * allocated resources etc. are written.
       * @param gene Object which implements the Gene interface and describes a gene of
   * the population.
   * @return String containing the report
   */
  public String getReport(Gene gene);

  /**
   *  This method has in some sense to graphically show all the parameters of a specific gene.
   *  @param gene Object which implements the Gene interface and describes a gene of
   * the population.
   * @return String which contains error message.
   */
  public String drawReport(Gene gene);
}