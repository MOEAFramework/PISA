/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package expo.gui;

import expo.*;
import javax.swing.UIManager;
import java.awt.*;

/**
 * @author Lothar Thiele
 * @version 1.0
 */

public class UserInterface {
  boolean packFrame = false;
  Frame2 frame;

  /**Construct the application*/
  public UserInterface() {
    frame = new Frame2();
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

/**
 * Add text to status text window.
 */
  public void addToStatusText(String text) {
    frame.statusText.append(text);
  }

/**
 * Get text from xWeight - text-field
 */
  public String getXWeight() {
    return frame.xWeight.getText();
  }

  public void resetStatusText(){
    frame.statusText.setText("");
  }

/**
 * Get text from yWeight - text-field
 */
  public String getYWeight() {
    return frame.yWeight.getText();
  }

/**
 * Get text from Index - text-field
 */
  public String getIndex() {
    return frame.geneID.getText();
  }

/**
 * Get maxX value from text-field
 */
  public String getMaxX() {
    return frame.maxX.getText();
  }

  /**
   * Helper method to set the button indicating the running
   * state of the application to a value specified.
   */
  public void setRunningButton(boolean value){
    frame.runButton.setSelected(value);
  }


  public void resetMaxGenerations(){
    frame.stopAfterGeneration.setText(Integer.toString(ParameterSet.maximumGenerations));
  }

}