/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package expo.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import expo.*;

import java.io.*;
import java.beans.*;
import expo.plot.SVGPlotter;

/**
 * @author Lothar Thiele
 * @version 1.0
 */

public class Frame2 extends JFrame {
  JPanel contentPane;
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenuItem jMenuFileExit = new JMenuItem();
  JMenu jMenuHelp = new JMenu();
  JMenuItem jMenuHelpAbout = new JMenuItem();
  JTabbedPane jTabbedPane2 = new JTabbedPane();
  JPanel startStopPanel = new JPanel();
  JPanel implementationPanel = new JPanel();
  JPanel populationPanel = new JPanel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JScrollPane jScrollPane2 = new JScrollPane();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField xWeight = new JTextField();
  JTextField yWeight = new JTextField();
  JButton drawPop = new JButton();
  JButton writePop = new JButton();
  JLabel jLabel3 = new JLabel();
  JTextField geneID = new JTextField();
  JButton writeGene = new JButton();
  JButton drawGene = new JButton();
  JPanel jPanel1 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  TitledBorder titledBorder3;
  JLabel jLabel4 = new JLabel();
  JTextField maxX = new JTextField();
  JRadioButton update = new JRadioButton();
  JTextArea statusText = new JTextArea();
  JToggleButton runButton = new JToggleButton();
  JButton resetButton = new JButton();
  JTextField stopAfterGeneration = new JTextField();
  JLabel generationCounterLabel = new JLabel();
  JButton showImplementationButton = new JButton();
  JLabel jLabel5 = new JLabel();

  /**Construct the frame*/
  public Frame2() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(477, 433));
    this.setTitle(ParameterSet.mainWindowTitle);
    jMenuFile.setText("File");
    jMenuFileExit.setText("Exit");
    jMenuFileExit.addActionListener(new Frame2_jMenuFileExit_ActionAdapter(this));
    jMenuHelp.setText("Help");
    jMenuHelpAbout.setText("About");
    jMenuHelpAbout.addActionListener(new Frame2_jMenuHelpAbout_ActionAdapter(this));
    startStopPanel.setLayout(null);
    implementationPanel.setLayout(null);
    contentPane.setFont(new java.awt.Font("Dialog", 0, 11));
    contentPane.setPreferredSize(new Dimension(200, 500));
    populationPanel.setLayout(null);
    jScrollPane2.setBounds(new Rectangle(6, 48, 444, 291));
    jScrollPane2.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane2.setAutoscrolls(true);
    jLabel1.setToolTipText("");
    jLabel1.setText("weight vector for x-axis (cost throughput0 throughput1 ...)");
    jLabel1.setBounds(new Rectangle(8, 8, 327, 31));
    jLabel2.setToolTipText("");
    jLabel2.setText("weight vector for y-axis (cost throughput0 throughput1 ...)");
    jLabel2.setBounds(new Rectangle(7, 67, 329, 26));
    xWeight.setText("1.0 0.0 0.0 0.0");
    xWeight.setBounds(new Rectangle(7, 35, 443, 25));
    yWeight.setToolTipText("");
    yWeight.setText("0.0 1.0 1.0 1.0");
    yWeight.setBounds(new Rectangle(7, 95, 445, 24));
    drawPop.setToolTipText("");
    drawPop.setText("plot population");
    drawPop.setBounds(new Rectangle(259, 143, 192, 31));
    drawPop.addActionListener(new Frame2_drawPop_actionAdapter(this));
    writePop.setToolTipText("");
    writePop.setText("text population");
    writePop.setBounds(new Rectangle(9, 144, 191, 31));
    writePop.addActionListener(new Frame2_writePop_actionAdapter(this));
    jLabel3.setBounds(new Rectangle(6, 55, 222, 31));
    jLabel3.setText("maximal x-coordinate in plot");
    jLabel3.setToolTipText("");
    geneID.setText("0");
    geneID.setBounds(new Rectangle(6, 32, 445, 24));
    writeGene.setBounds(new Rectangle(262, 129, 188, 28));
    writeGene.addActionListener(new Frame2_writeGene_actionAdapter(this));
    writeGene.setText("text implementation");
    writeGene.setToolTipText("");
    drawGene.setToolTipText("");
    drawGene.setText("draw arrival/service curves");
    drawGene.setBounds(new Rectangle(7, 129, 198, 28));
    drawGene.addActionListener(new Frame2_drawGene_actionAdapter(this));
    jPanel1.setLayout(gridLayout1);
    jPanel1.setBounds(new Rectangle(4, 4, 462, 372));
    startStopPanel.setBorder(BorderFactory.createLoweredBevelBorder());
    populationPanel.setBorder(BorderFactory.createLoweredBevelBorder());
    implementationPanel.setBorder(BorderFactory.createLoweredBevelBorder());
    jLabel4.setToolTipText("");
    jLabel4.setText("id of the selected implementation");
    jLabel4.setBounds(new Rectangle(7, 6, 222, 31));
    maxX.setBounds(new Rectangle(5, 80, 445, 24));
    maxX.setToolTipText("");
    maxX.setText("20.0");
    update.setToolTipText("");
    update.setActionCommand("update");
    update.setFont(new java.awt.Font("SansSerif", 0, 12));
    update.setBorder(null);
    update.addActionListener(new Frame2_update_actionAdapter(this));
    update.setBounds(new Rectangle(259, 180, 192, 29));
    update.setText("update plot");
    statusText.setEditable(false);
    statusText.setToolTipText("");
    statusText.setRequestFocusEnabled(false);
    runButton.setText("Run/Pause");
    runButton.setBounds(new Rectangle(6, 6, 100, 36));
    runButton.addActionListener(new Frame2_runButton_actionAdapter(this));
    resetButton.setBounds(new Rectangle(108, 6, 76, 36));
    resetButton.setActionCommand("Reset");
    resetButton.setText("Reset");
    resetButton.addActionListener(new Frame2_resetButton_actionAdapter(this));
    stopAfterGeneration.setText(Integer.toString(ParameterSet.maximumGenerations));
    stopAfterGeneration.setHorizontalAlignment(SwingConstants.RIGHT);
    stopAfterGeneration.setBounds(new Rectangle(357, 5, 89, 34));
    stopAfterGeneration.addActionListener(new Frame2_stopAfterGeneration_actionAdapter(this));
    generationCounterLabel.setText("stop after generation:");
    generationCounterLabel.setBounds(new Rectangle(209, 1, 143, 28));
    showImplementationButton.setBounds(new Rectangle(7, 161, 199, 29));
    showImplementationButton.setActionCommand("show implementation");
    showImplementationButton.setText("show implementation");
    showImplementationButton.addActionListener(new Frame2_showImplementationButton_actionAdapter(this));
    jLabel5.setText("(press ENTER to confirm)");
    jLabel5.setBounds(new Rectangle(209, 19, 146, 25));
    startStopPanel.add(jScrollPane2, null);
    startStopPanel.add(runButton, null);
    startStopPanel.add(stopAfterGeneration, null);
    startStopPanel.add(resetButton, null);
    startStopPanel.add(generationCounterLabel, null);
    startStopPanel.add(jLabel5, null);
    jTabbedPane2.add(startStopPanel,    "control", 0);
    jTabbedPane2.add(populationPanel, "population",1);
    jScrollPane2.getViewport().add(statusText, null);
    populationPanel.add(xWeight, null);
    populationPanel.add(jLabel2, null);
    populationPanel.add(yWeight, null);
    populationPanel.add(jLabel1, null);
    populationPanel.add(drawPop, null);
    populationPanel.add(writePop, null);
    populationPanel.add(update, null);
    jTabbedPane2.add(implementationPanel, "implementation",2);
    implementationPanel.add(jLabel4, null);
    implementationPanel.add(geneID, null);
    implementationPanel.add(maxX, null);
    implementationPanel.add(jLabel3, null);
    implementationPanel.add(drawGene, null);
    implementationPanel.add(showImplementationButton, null);
    implementationPanel.add(writeGene, null);

    jMenuFile.add(jMenuFileExit);
    jMenuHelp.add(jMenuHelpAbout);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuHelp);
    contentPane.add(jPanel1, null);
    jPanel1.add(jTabbedPane2, null);
    this.setJMenuBar(jMenuBar1);
  }
  /**File | Exit action performed*/
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    //System.exit(0);
    try{
      FileWriter writer = new FileWriter(ParameterSet.touchFile);
      writer.write("4");
      writer.flush();
      writer.close();
      if (!WatchFileChange.keepRunning){
        WatchFileChange.keepRunning = true;
      }
    }
    catch (Exception ee){
      ee.printStackTrace();
      System.exit(0);
    }
  }
  /**Help | About action performed*/
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    Frame2_AboutBox dlg = new Frame2_AboutBox(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }

  void startStop_actionPerformed(ActionEvent e) {
    WatchFileChange.keepRunning = !WatchFileChange.keepRunning;
  }

  void drawPop_actionPerformed(ActionEvent e) {
    EXPO.drawPopulation(false);
  }

  void writePop_actionPerformed(ActionEvent e) {
    EXPO.writeSimplePopulation();
  }

  void drawGene_actionPerformed(ActionEvent e) {
    EXPO.drawGene();
  }

  void writeGene_actionPerformed(ActionEvent e) {
    EXPO.writeGene();
  }

  void update_actionPerformed(ActionEvent e) {
    WatchFileChange.keepPlotUpdate = !WatchFileChange.keepPlotUpdate;
  }

  void startSPEA_actionPerformed(ActionEvent e) {
    //EXPO.startSPEA();
  }

  void jMenuPopLoad_actionPerformed(ActionEvent e) {
    DiskIO.loadPopulationObject(this);
  }

  void jMenuIPopSave_actionPerformed(ActionEvent e) {
    DiskIO.savePopulationObject(this);
  }

  void resetButton_actionPerformed(ActionEvent e) {
    try{
      FileWriter fw = new FileWriter(ParameterSet.touchFile);
      fw.write("8");
      fw.flush();
      fw.close();
      WatchFileChange.keepRunning = true;
    }
    catch (Exception ee){
      System.err.println("A problem occured while looking for touch file.");
    }
  }

  void runButton_actionPerformed(ActionEvent e) {
    WatchFileChange.keepRunning = !WatchFileChange.keepRunning;
  }

  void stopAfterGeneration_actionPerformed(ActionEvent e) {

    //stop processing if running
    boolean changed = false;
    if (EXPO.wfc.keepRunning){
      EXPO.wfc.keepRunning = false;
      changed = true;
    }

    int tempNumber = Integer.parseInt(stopAfterGeneration.getText());
    if (tempNumber <= EXPO.wfc.getGenerationCount()){
      if (tempNumber == 0){
        EXPO.debugPrint("Changed to infinite mode");
        ParameterSet.maximumGenerations = 0;
      }
      else{
        JOptionPane.showMessageDialog(this,
                                      "Value specified should be larger than " +
                                      EXPO.wfc.getGenerationCount());
        stopAfterGeneration.setText(Integer.toString(ParameterSet.
            maximumGenerations));
      }
    }
    else{
      ParameterSet.maximumGenerations = tempNumber;
      EXPO.debugPrint("Number of Generations set to "+tempNumber);
    }

    //restart process if stopped before.
    if (changed){
      EXPO.wfc.keepRunning = true;
    }
  }

  void showImplementationButton_actionPerformed(ActionEvent e) {
    SVGPlotter svgPlot = new SVGPlotter();
    svgPlot.drawImplementation(Integer.parseInt( this.geneID.getText()),0);
  }

}

class Frame2_jMenuFileExit_ActionAdapter implements ActionListener {
  Frame2 adaptee;

  Frame2_jMenuFileExit_ActionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuFileExit_actionPerformed(e);
  }
}

class Frame2_jMenuHelpAbout_ActionAdapter implements ActionListener {
  Frame2 adaptee;

  Frame2_jMenuHelpAbout_ActionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuHelpAbout_actionPerformed(e);
  }
}

class Frame2_drawPop_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_drawPop_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.drawPop_actionPerformed(e);
  }
}

class Frame2_writePop_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_writePop_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.writePop_actionPerformed(e);
  }
}

class Frame2_drawGene_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_drawGene_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.drawGene_actionPerformed(e);
  }
}

class Frame2_writeGene_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_writeGene_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.writeGene_actionPerformed(e);
  }
}

class Frame2_update_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_update_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.update_actionPerformed(e);
  }
}

class Frame2_resetButton_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_resetButton_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.resetButton_actionPerformed(e);
  }
}

class Frame2_runButton_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_runButton_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.runButton_actionPerformed(e);
  }
}

class Frame2_stopAfterGeneration_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_stopAfterGeneration_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.stopAfterGeneration_actionPerformed(e);
  }
}

class Frame2_showImplementationButton_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_showImplementationButton_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.showImplementationButton_actionPerformed(e);
  }
}

