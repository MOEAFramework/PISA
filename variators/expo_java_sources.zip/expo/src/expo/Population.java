/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */
package expo;

import java.util.*;
import java.io.*;

/**
 * This class represents a population of <code>Gene</code>s.
 *
 * @author Lothar Thiele, Simon Kuenzli
 * @version 1.0
 */

public class Population
    implements Serializable {

  /**
   * The genes of a population are stored in the HashMap <code>genes</code>.
       * The keys are <code></code> objects whose value corresponds to the ID of the
   * corresponding gene. The objects are instances of class <code>Gene</code>.
   * This implementation is not particularly efficient (but simple ...).
   */
  public HashMap genes = new HashMap();

  /**
   * The current maximal ID of generated genes. This number is not! the
   * number of genes in the population, i.e. <code>genes.size()</code>genes,
   * as some genes may have been deleted during the cleaning process.
   */
  public int currentID = 0;

  /**
   * The constructor does virtually nothing.
   */
  public Population() {
  }

  /**
   * The method <code>addGene</code> adds a new gene to the population.
   * If the sizes of the internal arrays are not large enough, the method
   * performs an allocation.
   * @param gene gene is the gene that is added to the population.
   */
  public void addGene(Gene gene) {
    genes.put(new Integer(currentID), gene);
    currentID = currentID + 1;
  }

  /**
   * The method <code>getGene</code> gets the gene via its id.
   * @param geneID geneID is the id of the gene that is retrieved.
   */
  public Gene getGene(int geneID) {
    return (Gene) genes.get(new Integer(geneID));
  }

  /**
   * The method <code>size()</code> returns the number of genes stored
   * in the population.
   */
  public int size() {
    return genes.size();
  }

  /**
   * The method <code>clean</code> removes all genes from the population
   * which are not longer needed. In particular, it removes all genes with
   * indices that are not in the given <code>geneIDArray</code>.
   * @param geneIDArray geneIDArray contains all the id's of the genes that should stay
   * in the population.
   */
  public void clean(int[] geneIDArray) {

    Object[] keys = new Object[genes.keySet().size()];
    int count = 0;
    int test;

    Arrays.sort(geneIDArray);
    keys = genes.keySet().toArray();
    Arrays.sort(keys);
    for (int i = 0; i < keys.length; i++) {
      test = ( (Integer) keys[i]).intValue();
      if (geneIDArray.length == 0) {
        genes.remove(keys[i]);
      }
      else if (test == geneIDArray[count]) {
        count = Math.min(count + 1, geneIDArray.length - 1);
      }
      else {
        genes.remove(keys[i]);
      }
    }
  }

  /**
   * The method writes the population to a file.
   * @param filename The name of the file to which the population is written.
   *
   */
  // maybe add  to deprecated methods...
  /// NOT USED
  public void printPopulation(String filename) {
    FileWriter writer = null;
    Integer count;
    Gene gene;
    String tmp_strg = "";

    try {
      writer = new FileWriter(filename, true);
      writer.write("\r\n\r\n// ***********************\r\n// CURRENT POPULATION \r\n// ***********************\r\n");
      for (Iterator i = genes.keySet().iterator(); i.hasNext(); ) {
        count = (Integer) i.next();
        gene = (Gene) genes.get(count);
        tmp_strg = gene.getFullDescription();
        writer.write("\r\n//------------------------\r\n// 'gene index'\r\n" +
                     count.intValue() + "\r\n");
        writer.write(tmp_strg);
      }
      writer.flush();
      writer.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }
    EXPO.debugPrint("Population details written to file.");
  }
}
