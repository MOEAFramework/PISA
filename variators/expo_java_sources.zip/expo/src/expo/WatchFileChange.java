/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */
package expo;

import java.util.*;
import java.io.*;

/**
 * The class watches continuously for changes in files. In case of
 * changes it reads them, performs mutation or crossover, cleans
 * the population and writes the corresponding output files.
 *
 * 11.02.2003: added generation counter (sk)
 * 12.02.2003: adapted to PISA interface (sk)
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class WatchFileChange{
    //extends Thread {

  /**
   * If true, then the thread is active (the files are scanned
   * for changes); otherwise, the thread does nothing.
   */
  public static boolean keepRunning = false;

  /**
   * If true, then the current population plot is
   * updated continuously.
   */
  public static boolean keepPlotUpdate = false;

  /**
   * Counting the generations.
   */
  private int generationCount = 1;

  /**
   * The constructor starts the thread.
   */
  public WatchFileChange() {
    //setDaemon(true);
    //start();
    EXPO.wfc=this;
    run();
  }

  /**
   * The run method of the thread continuously watches the communication
   * file whose name is in <code>Specification.touch</code>.
   * If there is a relevant state in this file, it reads
   * the files <code>Specification.mutInFile</code>,
   * <code>Specification.crossInFile</code> and
   * <code>Specification.archiveFile</code> and executes the methods
   * <code>performMutation</code>, <code>performCrossover</code>
   * and <code>performClean</code>, respectively.<p>
   * The coding of states is as follows:
   * <table border="1"><tr><td>
   * 0 </td><td> do nothing </td></tr><tr><td>
   * 1 </td><td> SPEA must read initialPopFile and generate mutInFile and populationFile.</td></tr><tr><td>
   * 2 </td><td> EXPO must read crossInFile, populationFile and generate crossOutFile (crossover).</td></tr><tr><td>
   * 3 </td><td> SPEA must read crossOutFile and generate mutInFile.</td></tr><tr><td>
   * 4 </td><td> EXPO must read mutInFile and generate mutOutFile (mutation).</td></tr><tr><td>
   * 5 </td><td> SPEA must read mutOutFile and generate mutInFile and populationFile.</td></tr></table>
   * <p>
   * The state diagram looks as follows:<p>
   * 0 -EXPO-> 1 -SPEA-> 2 -EXPO-> 3 -SPEA-> 4 -EXPO-> 5 -SPEA-> 2 ... <p>
   *
   */
  public void run() {
    FileWriter writer;
    FileReader reader;
    StreamTokenizer token;
    int state;

    try {
      writer = new FileWriter(ParameterSet.touchFile);
      writer.write("0");
      writer.flush();
      writer.close();
      keepRunning = true;
    }
    catch (IOException e) {
      System.err.println("Problem with 'state' file");
      System.err.println(e);
    }

    while (true) {
      if (keepRunning) {
        try {
          reader = new FileReader(ParameterSet.touchFile);
          token = new StreamTokenizer(reader);
          state = -1;
          if (token.nextToken()!=StreamTokenizer.TT_EOF){
            state = (int) token.nval;
          }
          reader.close();
          if ( (state == 2) && varFileRead() && ((generationCount < ParameterSet.maximumGenerations+1) || (ParameterSet.maximumGenerations == 0))) {
            EXPO.debugPrint("****** Generation " + generationCount + " *******");
            generationCount += 1;
            performClean();
            EXPO.debugPrint("Clean of population finished.");
            EXPO.writePopFile();

            // update population plot, if needed.
            if (ParameterSet.gui){
              if (WatchFileChange.keepPlotUpdate) {
                try {
                  EXPO.drawPopulation(true);
                }
                catch (NullPointerException e) {
                  System.err.println(e);
                }
              }
            }
            performVariation();
            EXPO.debugPrint("Variation finished.");
            writer = new FileWriter(ParameterSet.touchFile);
            writer.write("3");
            writer.close();
          }
          else if (state == 4) {
            // terminate program
            EXPO.debugPrint("Preparing to terminate.");
            writer = new FileWriter(ParameterSet.touchFile);
            writer.write("5");
            writer.flush();
            writer.close();
            System.exit(0);
          }
          else if (state == 0) {
            EXPO.debugPrint("Initialisation sequence started.");
            String commFilePath = ParameterSet.commFilePath;
            int polling = ParameterSet.pollingInterval;
            Launcher.determineOptions(ParameterSet.parameterFileName);
            EXPO.readSpec();
            EXPO.random = new Random(ParameterSet.seed);
            ParameterSet.commFilePath = commFilePath;
            ParameterSet.pollingInterval = polling;

            EXPO.constructIniPop();
            EXPO.writeIniPop();
            EXPO.writePopFile();
            setGenerationCount(1);
            EXPO.debugPrint("Generation counter set to 1.");
            if (ParameterSet.gui){
              EXPO.ui.resetMaxGenerations();
            }
            writer = new FileWriter(ParameterSet.touchFile);
            writer.write("1");
            writer.flush();
            writer.close();
            if (ParameterSet.gui){
              keepRunning = false;
              EXPO.ui.setRunningButton(false);
            }
            else{
              keepRunning = true;
            }
          }
          else if (state == 8){
            // perform reset
            if (ParameterSet.gui){
              EXPO.ui.resetStatusText();
            }
            EXPO.debugPrint("Reset state found.");
            writer = new FileWriter(ParameterSet.touchFile);
            writer.write("9");
            writer.flush();
            writer.close();
            keepRunning = true;
          }
          else if (state == 11){
            // selector reset done...
            EXPO.debugPrint("Selector reset performed.");
            writer = new FileWriter(ParameterSet.touchFile);
            writer.write("0");
            writer.flush();
            writer.close();
            keepRunning = true;
          }
          else if ((!ParameterSet.gui) && (state == 2 )&&(generationCount == ParameterSet.maximumGenerations+1)){
           EXPO.debugPrint("Maximum Generations reached. Preparing to terminate.");
           writer = new FileWriter(ParameterSet.touchFile);
           writer.write("4");
           writer.flush();
           writer.close();
          }
        }
        catch (IOException e) {
          System.err.println(e);
        }
      }
      try {
        Thread.sleep(ParameterSet.pollingInterval);
      }
      catch (InterruptedException e) {}
    }
  }

  /**
   * The method reads the active genes from file
   * <code>Specification.populationFile</code>. It deletes all
   * genes not in these files from the population.
   */
  public void performClean() {

    FileReader reader = null;
    StreamTokenizer tokenStream = null;
    int numberOfGenes = 0;
    HashSet active = new HashSet();
    int[] geneID;

    // Read the integers of population
    try {
      reader = new FileReader(new File(ParameterSet.archiveFile));
      tokenStream = new StreamTokenizer(reader);
      tokenStream.slashSlashComments(true);
      tokenStream.slashStarComments(true);

      tokenStream.nextToken();
      numberOfGenes = (int) tokenStream.nval;
      for (int i = 0; i < numberOfGenes; i++) {
        tokenStream.nextToken();
        active.add(new Integer( (int) tokenStream.nval));
      }
      // check whether END tag is found
      String temp = "";
      if (tokenStream.nextToken() == StreamTokenizer.TT_WORD) {
        temp = tokenStream.sval;
      }
      if (temp.equals("END")) {

      }
      else {
        System.err.println("END tag not found!");
        return;
      }
      reader.close();
      FileWriter fw = new FileWriter(ParameterSet.archiveFile);
      fw.write("0");
      fw.flush();
      fw.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }
    EXPO.debugPrint("All active gene IDs read.");

    // construct array of integers containing the active ids.
    geneID = new int[active.size()];
    for (int i = 0; i < active.size(); i++) {
      geneID[i] = ( (Integer) active.toArray()[i]).intValue();
    }

    // clean the population
    EXPO.debugPrint("Population before cleaning: " +
                    Integer.toString(EXPO.population.size()) + " elements.");
    EXPO.population.clean(geneID);
    EXPO.debugPrint("Population after cleaning: " +
                    Integer.toString(EXPO.population.size()) + " elements.");
  }

  /**
   * Helper method to set the generation counter to some value specified.
   */
  public void setGenerationCount(int generationCounter) {
    this.generationCount = generationCounter;
  }


  public int getGenerationCount(){
    return this.generationCount;
  }

  /**
   * This method is used to perform the variation. It reads the File specified
   * in <code>ParameterSet.selInFile</code>. All of the elements given in
   * this file, are pairwise crossed with a probability of
   * <code>specification.getCrossoverProbability</code> and then mutated with
   * a probability of <code>specification.getMutationProbability</code>. After
   * doing so, the newly created genes are added to the actual population and
   * written to the file <code>ParameterSet.varOutFile</code> annotated with
   * the fitness values.
   */
  public void performVariation() {

    String tmp_strg = "";
    try {
      FileReader reader = new FileReader(new File(ParameterSet.selInFile));
      StreamTokenizer tokenStream = new StreamTokenizer(reader);
      tokenStream.slashSlashComments(true);
      tokenStream.slashStarComments(true);
      tokenStream.nextToken();
      int numberOfGenes = (int) tokenStream.nval;
      int[] cross = new int[numberOfGenes + 1];
      // now perform crossover
      for (int i = 0; i < numberOfGenes; i++) {
        tokenStream.nextToken();
        cross[i] = (int) tokenStream.nval;
      }
      // make number of genes even...
      if (numberOfGenes % 2 > 0) {
        cross[numberOfGenes] = (int) tokenStream.nval;
      }
      // check for END token...
      tokenStream.nextToken();
      if (!tokenStream.sval.equals("END")) {
        System.err.println("No END tag found");
      }
      EXPO.debugPrint("Genes for variation read.");
      FileWriter fw = new FileWriter(new File(ParameterSet.selInFile));
      fw.write("0\r\n");
      fw.flush();
      fw.close();

      for (int i = 0; i < numberOfGenes; i = i + 2) {
        Gene[] crossedGenes = new Gene[2];
        Gene[] mutatedGenes = new Gene[2];
        Gene geneToCrossOver1 = EXPO.population.getGene(cross[i]);
        Gene geneToCrossOver2 = EXPO.population.getGene(cross[i + 1]);

        if (EXPO.random.nextDouble() <
            EXPO.specification.getCrossoverProbability()) {
          crossedGenes = geneToCrossOver1.crossOverGene(geneToCrossOver2);

        }
        else {
          crossedGenes[0] = (Gene) geneToCrossOver1.clone();
          crossedGenes[1] = (Gene) geneToCrossOver2.clone();
        }
        // now mutate, if necessary
        for (int j = 0; j < 2; j++) {
          if (EXPO.random.nextDouble() <
              EXPO.specification.getMutationProbability())  {
            mutatedGenes[j] = crossedGenes[j].mutateGene();
          }
          else {
            mutatedGenes[j] = (Gene) crossedGenes[j].clone();
          }
        }
        for (int k = 0; k < 2; k++) {
          if (i + k < numberOfGenes) {
            tmp_strg += Integer.toString(EXPO.population.currentID) + " ";
            tmp_strg += mutatedGenes[k].getFitnessString();
            tmp_strg += "\r\n";
            EXPO.population.addGene(mutatedGenes[k]);

          }
        }
      }
      FileWriter writer = new FileWriter(new File(ParameterSet.varOutFile));
      writer.write(Integer.toString(numberOfGenes *
                                    (EXPO.specification.getProblemDimension() +
                                     1)) + "\r\n");
      writer.write(tmp_strg + "\r\nEND");
      writer.flush();
      writer.close();

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }


  /**
   * This helper method determines whether the <code>ParameterSet.varOutFile
   * </code> was read by the optimizer.
   */
  private boolean varFileRead() {

    boolean value = false;
    try {
      // check whether optimizer is ready.
      FileReader fr = new FileReader(ParameterSet.varOutFile);
      StreamTokenizer st = new StreamTokenizer(fr);
      st.nextToken();
      if ( (int) st.nval != 0) {
        value = false;
      }
      else {
        value = true;
      }
      fr.close();
    }
    catch (FileNotFoundException eee){
      EXPO.debugPrint("Var-File not found.");
    }
    catch (Exception ee) {
      ee.printStackTrace();
    }
    // disable this check
    value = true;
    return value;
  }


}
