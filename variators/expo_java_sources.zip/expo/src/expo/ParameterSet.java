/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */
package expo;

import java.util.ResourceBundle;
import java.util.Locale;
import java.io.IOException;
import java.io.*;
import java.util.StringTokenizer;

/**
 * This class contains all information that is used by the tool, but that
 * is not problem specific. (e.g. Population size, Log-Filename...)
 * NOTE: There are still parameters stored in this class which are
 * REALLY problem specific.
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
public class ParameterSet {

    /**
     * Holds whether a GUI is needed or not.
     */
  public static boolean gui = true;
  /**
   * Holds the population size of the design space exploration.
   */
  public static int populationSize = 100;
  /**
   * Holds the name of the problem specificaiton file.
   */
  public static String specFile = "spec.txt";
  /**
   * Holds the enable signal for debug prints.
   */
  public static int debugPrint = 0;
  /**
   * Holds the name of the file to which the initial population will
   * be written.
   */
  public static String initialPopFile = "iniPop.txt";
  /**
   * Holds the name of the log file.
   */
  public static String logFile = "log.txt";
  /**
   * Holds the interval in which the state of the communication file
   * is checked.
   */
  public static int pollingInterval = 500;
  /**
   * Holds the name of the communication file with EA
   */
  public static String touchFile = "touch.txt";
  /**
   * Holds the name of the mutation-input file (written by EA)
   */
  public static String selInFile = "mutIn.txt";
  /**
   * Holds the name of the mutation-output file (written by EXPO)
   */
  public static String varOutFile = "mutOut.txt";
  /**
   * Holds the config file name.
   */
  public static String configFile = "spea.cfg";
  /**
   * Holds the name of the population file.
   */
  public static String populationFile = "population.txt";
  /**
   * Holds the name of the editor's executable.
   */
  public static String editor = "notepad.exe";
  /**
   * Holds the path and name-parts of the communication files...
   */
  public static String commFilePath = "spea.";
  /**
   * Holds the name of the Analyzer - class.
   */
  public static String analyzer = "sps.SPSAn";
  /**
   * Holds the name of the Gene - class.
   */
  public static String geneName = "sps.SPSGene";
  /**
   * Holds the name of the Specification - class.
   */
  public static String specificationName = "sps.SPSSpecification";
  /**
   * Holds the string to display in the Main Window Title bar.
   */
  public static String mainWindowTitle =
      "EXPO V2.0 - A Tool for Design Space Exploration (TIK, ETHZ)";

  /**
   * Holds the seed used to initialize the random number generator.
   */
  public static long seed = 10;
  /**
   * Hold the int specifying the maximum number of generations.
   */
  public static int maximumGenerations = Integer.MAX_VALUE;
  /**
   * Optimization parameter mu (number of parent genes)
   */
  public static int mu = 0;
  /**
   * Optimization parameter lambda (number of offspring genes)
   */
  public static int lambda = 0;
  /**
   * Optimization parameter dim (number of dimensions, objectives)
   */
  public static int dim = 0;
  /**
   * Holds the name and path to the archive file, which contains the
   * ID's of all active genes.
   */
  public static String archiveFile = "";


  /**
   * Holds the maximum achievable scaling factor for all architectures,
   * this value is used for scaling and reversing of scaling factors. It
   * is problem specific...
   */
  public static double maximumAchievedScalingFactor = 2;

  /**
   * Holds the maximum achievable total cost of resources, this value is used to
   * scale down the cost value. It is problem specific...
   */
  public static double maximumAchievedTotalCost = 225;

  public static double minimalCostForResource = 2;

  public static String parameterFileName = "expo_param.txt";

  public static String propertiesFileName = "expo";
  /**
   * This method is used to read all parameters needed from
   * a file, which follows the requirements of a Java properties file.
   * @param fileName String that contains the name of the properties file to
   * be read.
   */
  public static boolean parameterInput(String fileName) {

    try {
      // get resource bundle
      ResourceBundle rb = ResourceBundle.getBundle(fileName);
      propertiesFileName = fileName;
      // Parameter read in (in properties style file)
      debugPrint = Integer.parseInt(rb.getString("DEBUG_PRINT"));
      configFile = commFilePath + rb.getString("CONFIG_FILE_NAME");
      initialPopFile = commFilePath +
          rb.getString("INITIAL_POPULATION_FILE_NAME");
      touchFile = commFilePath + rb.getString("COMMUNICATION_FILE_NAME");
      selInFile = commFilePath + rb.getString("SELECTOR_INPUT_FILE_NAME");
      varOutFile = commFilePath + rb.getString("VARIATOR_OUTPUT_FILE_NAME");
      populationFile = commFilePath +
          rb.getString("ACTUAL_POPULATION_FILE_NAME");
      archiveFile = commFilePath + rb.getString("ARCHIVE_FILE_NAME");
      editor = rb.getString("EXECUTABLE_EDITOR");
      //geneName = rb.getString("GENE_CLASS_NAME");
      //analyzer = rb.getString("ANALYZER_CLASS_NAME");
      //specificationName = rb.getString("SPECIFICATION_CLASS_NAME");

      // scaling factors...

      maximumAchievedScalingFactor = Double.parseDouble(rb.getString("MAXIMUM_ACHIEVED_SCALING_FACTOR"));
      maximumAchievedTotalCost = Double.parseDouble(rb.getString("MAXIMUM_ACHIEVED_TOTAL_COST"));
      minimalCostForResource = Double.parseDouble(rb.getString("MINIMAL_COST_FOR_RESOURCE"));
      int tempInt = Integer.parseInt(rb.getString("MAX_GENERATIONS"));
      if (tempInt > 0) {
        maximumGenerations = tempInt;
      }
      else {
        maximumGenerations = 0;
      }

      // read the .cfg file and store the parameters...
      try {
        File fileHandle = new File(configFile);
        FileReader file = new FileReader(fileHandle);
        StreamTokenizer tokenStream = new StreamTokenizer(file);
        tokenStream.slashSlashComments(true);
        tokenStream.slashStarComments(true);
        while (tokenStream.nextToken() != StreamTokenizer.TT_EOF) {
          String temp = tokenStream.sval;
          if (temp.equals("alpha")) {
            tokenStream.nextToken();
            populationSize = (int) tokenStream.nval;
          }
          else if (temp.equals("mu")) {
            tokenStream.nextToken();
            mu = (int) tokenStream.nval;
          }
          else if (temp.equals("lambda")) {
            tokenStream.nextToken();
            lambda = (int) tokenStream.nval;
          }
          else if (temp.equals("dim")) {
            tokenStream.nextToken();
            dim = (int) tokenStream.nval;
          }
          else {
            System.err.println("Undefined token found in " + configFile);
          }
        }
      }
      catch (Exception e) {
        e.printStackTrace();
      }

    }
    catch (Exception e) {
      e.printStackTrace();
      System.err.print(getInfo());
    }
    return true;
  }

  /**
   * getInfo() displays a info-text on how to use the ParameterSet class.
   * @return String that contains information about the parameter set.
   */
  public static String getInfo() {

    String returnString =
        "You will have to use a properties file in the form KEY = VALUE \n";
    returnString += "as an input to the ParameterSet-Class.\n\n";
    return returnString;
  }

  public ParameterSet() {
  }
}
