package expo;

/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */

/**
 * This class provides methods to store and restore
 * populations from previous runs of the design space
 * exploration.
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class DiskIO {

  public DiskIO() {
  }

  public static void savePopulationObject(JFrame parentFrame) {
    // file save as dialog...
    System.out.println("save population ...");
    JFileChooser fc = new JFileChooser();
    try {
      fc.showSaveDialog(parentFrame);
      File file = fc.getSelectedFile();
      if (!file.exists()) {
        file.createNewFile();
      }
      FileOutputStream fos = new FileOutputStream(file);
      ObjectOutputStream oos = new ObjectOutputStream(fos);
      // serialize the population Object...
      oos.writeObject(EXPO.population);
      oos.flush();
      oos.close();
    }
    catch (Exception ee) {
      ee.printStackTrace();
    }
    System.out.println("saving done...");
  }

  public static void loadPopulationObject(JFrame parentFrame) {
    // file open dialog
    System.out.println("load population ...");
    JFileChooser fc = new JFileChooser();
    try {
      fc.showOpenDialog(parentFrame);
      File file = fc.getSelectedFile();
      FileInputStream fis = new FileInputStream(file);
      ObjectInputStream ois = new ObjectInputStream(fis);
      // overwrite population...
      EXPO.population = (Population) ois.readObject();
      ois.close();
      fis.close();
    }
    catch (Exception ee) {
      ee.printStackTrace();
    }
    try {
      // write pop to initial population file...
      EXPO.writeIniPop();
    }
    catch (Exception e2) {
      e2.printStackTrace();
    }
    try {
      FileWriter writer = new FileWriter(ParameterSet.touchFile);
      writer.write("1");
      writer.flush();
      writer.close();
    }
    catch (IOException exc) {
      System.err.println(exc);
    }

    System.out.println("loading done... ");
  }

}
