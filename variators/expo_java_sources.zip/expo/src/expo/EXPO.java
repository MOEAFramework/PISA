/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */
package expo;

import java.util.*;
import java.io.*;
import expo.gui.*;
import expo.plot.*;

/**
 * This is the main class of the package. It contains all the coordinating
 * actions. It will be initialized only once, i.e. there are only static
 * fields and methods.
 *
 * Change Log:
 * 11.11.2002: Added command line parameter treatment. (SK)
 * 12.02.2003: Changed to comply the PISA interface (SK)
 * 04.10.2005: Complete redesign (SK)
 * @author Lothar Thiele
 * @version 1.0
 */
public class EXPO {
  /**
   * Holds a reference to the actual population.
   */
  public static Population population;
  /**
   * Holds a reference to the user interface.
   */
  public static UserInterface ui;
  /**
   * Holds a refernce to the plot window in which the actual population
   * is displayed.
   */
  public static PopulationPlot plot;


  public static WatchFileChange wfc;

  /**
   * Holds a reference to the actual specification of the problem
   * to be explored.
   */
  public static Specification specification;

  /**
   * A random number generator
   */
  public static Random random;

  /**
   * Holds the name of the parameter file
   */
  //public static String parameterFileName;

  public static String specificationFileName;
  /**
   * Main method creates a new user interface, reads the specification file,
   * creates an initial population of genes which solve the problem
   * and then starts the communication with the evolutionary algortihm.
   */

  /**
   * Adds line to the status text of the user interface.
   * @param text Text line which is added to status window.
   */
  public static void addToStatusText(String text) {
    if (ui != null) {
      ui.addToStatusText("\r\n" + text);
    }
  }

  /**
   * <code>debugPrint</code> writes the given string to System.out
   * if the parameter <code>ParameterSet.debugPrint</code> is not 0.
   * @param text The text which will be printed to System.out
   */
  public static void debugPrint(String text) {
    if (ParameterSet.debugPrint != 0) {
      System.out.println(text);
    }
    addToStatusText(text);
  }

  public static void readSpec() {

    // Read the problem specification
    File specreader = null;
    specreader = new File(ParameterSet.specFile);
    try {
      specification = (Specification) Class.forName(ParameterSet.
          specificationName).newInstance();
    }
    catch (Exception ee) {
      System.err.println("There seems to be a problem with class " +
                         ParameterSet.specificationName);
    }
    specification.simpleFileInput(specreader);
    debugPrint("Problem specification read.");
  }


  /**
   * <code>constructIniPop</code> constructs the inital population
   * and writes it to files.
   */
  public static void constructIniPop() {

    population = new Population();
    // Construct the initial population
    Gene gene;
    for (int i = 0; i < ParameterSet.populationSize; i++) {
      try {
        gene = (Gene) Class.forName(ParameterSet.geneName).newInstance();
        population.addGene(gene);
      }
      catch (Exception e) {
        System.err.println("There seems to be a problem finding class " +
                           ParameterSet.geneName);
        e.printStackTrace();
      }
    }
    debugPrint("Initial population constructed.");
  }


  public static void writeIniPop() {

    //Write the initial population to a file
    String tmp_strg;
    FileWriter writer = null;
    try {
      writer = new FileWriter(new File(ParameterSet.initialPopFile));
      writer.write(Integer.toString(population.genes.size() *
                                    (1 + specification.getProblemDimension())) +
                   "\r\n");
      for (Iterator iter = population.genes.keySet().iterator(); iter.hasNext(); ) {
        int geneID = ( (Integer) iter.next()).intValue();
        Gene gene = (Gene) population.getGene(geneID);
        tmp_strg = geneID + " ";
        tmp_strg += gene.getFitnessString();
        tmp_strg += "\r\n";
        writer.write(tmp_strg);
      }
      writer.write(" END");
      writer.flush();
      writer.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }
    debugPrint("Initial population written to file.");
  }


  /**
   * Draws the current population using pt Plot
   */
  public static void drawPopulation(boolean update) {

    if (ParameterSet.gui){


      if (!update) {
        plot = new PopulationPlot(0, 0);
      }

      // read data of current population
      FileReader reader = null;
      StreamTokenizer tokenStream = null;
      int numberOfGenes = 0;
      double[][] fitness = new double[specification.getProblemDimension()][];
      double[] xWeight = new double[specification.getProblemDimension()];
      double[] yWeight = new double[specification.getProblemDimension()];
      StringReader stringReader;
      double[] x;
      double[] y;
      int[] geneID;
      ArrayList tempList = new ArrayList();

      try {
        reader = new FileReader(new File(ParameterSet.populationFile));
        tokenStream = new StreamTokenizer(reader);
        tokenStream.slashSlashComments(true);
        tokenStream.slashStarComments(true);

        tokenStream.nextToken();
        numberOfGenes = (int) tokenStream.nval;

        for (int j = 0; j < specification.getProblemDimension(); j++) {
          fitness[j] = new double[numberOfGenes];
        }
        for (int i = 0; i < numberOfGenes; i++) {
          tokenStream.nextToken();
          tempList.add(new Integer( (int) tokenStream.nval));
          tokenStream.nextToken();
          fitness[0][i] = tokenStream.nval;
          for (int j = 1; j < specification.getProblemDimension(); j++) {
            tokenStream.nextToken();
            fitness[j][i] = tokenStream.nval;
          }
        }
        reader.close();
      }
      catch (IOException e) {
        System.err.println(e);
      }

      // make weight vectors from user input
      try {
        stringReader = new StringReader(ui.getXWeight());
        tokenStream = new StreamTokenizer(stringReader);
        for (int i = 0; i < specification.getProblemDimension(); i++) {
          tokenStream.nextToken();
          xWeight[i] = tokenStream.nval;
        }
        stringReader.close();
      }
      catch (IOException e) {
        System.err.println(e);
      }
      try {
        stringReader = new StringReader(ui.getYWeight());
        tokenStream = new StreamTokenizer(stringReader);
        for (int i = 0; i < specification.getProblemDimension(); i++) {
          tokenStream.nextToken();
          yWeight[i] = tokenStream.nval;
        }
        stringReader.close();
      }
      catch (IOException e) {
        System.err.println(e);
      }

      // calculate vectors x and y which contain the coordinates
      // if Weight Values are negative -> invert
      x = new double[numberOfGenes];
      y = new double[numberOfGenes];
      geneID = new int[numberOfGenes];

      for (int i = 0; i < numberOfGenes; i++) {
        x[i] = 0.0;
        y[i] = 0.0;
        geneID[i] = ( (Integer) tempList.get(i)).intValue();
        for (int j = 0; j < specification.getProblemDimension(); j++) {
          if (j > 0) {
            x[i] += xWeight[j] * fitness[j][i]; //SK, 4. 12. 2003, changed from inversion
          }
          else {
            x[i] += xWeight[j] * fitness[j][i];
          }
          if (j > 0) {
            y[i] += yWeight[j] * fitness[j][i]; //SK, 4. 12. 2003, changed from inversion
          }
          else {
            y[i] += yWeight[j] * fitness[j][i];
          }
        }
      }
      if (update) {
        plot.pt.clear(0);
      }
      tempList.clear();
      plot.drawPoints(x, y, geneID);
    }
    else{
      debugPrint("drawPopulation() is not to be used with NoGui option");
    }
  }

  /**
   * Writes current population in <code>ParameterSet.populationFile</code>
   * to <code>ParameterSet.logFile</code> and opens a text editor
   * for viewing.
   */
  public static void writeSimplePopulation() {
    try {
      Runtime.getRuntime().exec(ParameterSet.editor + " " +
                                ParameterSet.populationFile);
    }
    catch (IOException e) {
      System.err.println(e);
    }
  }

  /**
   * Writes current population in <code>ParameterSet.populationFile</code>
   * in detail to <code>ParameterSet.logFile</code> and opens a text editor
   * for viewing. To this end, all parameters are calculated anew.
   */
  public static void writeDetailedPopulation() {
    // read indices of current population
    FileReader reader = null;
    StreamTokenizer tokenStream = null;
    int numberOfGenes = 0;
    int[] geneID;

    try {
      reader = new FileReader(new File(ParameterSet.populationFile));
      tokenStream = new StreamTokenizer(reader);
      tokenStream.slashSlashComments(true);
      tokenStream.slashStarComments(true);

      tokenStream.nextToken();
      numberOfGenes = (int) tokenStream.nval;
      geneID = new int[numberOfGenes];
      for (int i = 0; i < numberOfGenes; i++) {
        tokenStream.nextToken();
        geneID[i] = (int) tokenStream.nval;
        tokenStream.nextToken();
        for (int j = 0; j < specification.getProblemDimension() - 1; j++) {
          tokenStream.nextToken();
        }
      }
      reader.close();
    }
    catch (IOException e) {
      geneID = new int[numberOfGenes];
      System.err.println(e);
    }

    // write population to file ParameterSet.logFile
    FileWriter writer = null;
    Gene gene;
    String tmp_strg = "";

    try {
      writer = new FileWriter(ParameterSet.logFile, false);
      writer.write("\r\n\r\n// ***********************\r\n// CURRENT POPULATION \r\n// ***********************\r\n");
      for (int i = 0; i < numberOfGenes; i++) {
        gene = (Gene) population.genes.get(new Integer(geneID[i]));
        tmp_strg = gene.getFullDescription();
        writer.write("\r\n//------------------------\r\n// 'gene index'\r\n" +
                     geneID[i] + "\r\n");
        writer.write(tmp_strg);
      }
      writer.flush();
      writer.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }

    // open editor to show the contents of the logFile
    try {
      Runtime.getRuntime().exec(ParameterSet.editor + " " +
                                ParameterSet.logFile);
    }
    catch (IOException e) {
      System.err.println(e);
    }
  }

  /**
   * Draws the implementation with gene index provided in the user interface
   */
  public static void drawGene() {
    Gene gene;
    int index = Integer.parseInt(ui.getIndex());

    gene = (Gene) population.genes.get(new Integer(index));
    try {
      Analyzer an = (Analyzer) Class.forName(ParameterSet.analyzer).newInstance();
      debugPrint(an.drawReport(gene));
    }
    catch (Exception e) {
      System.err.println("There seems to be a problem finding " +
                         ParameterSet.analyzer);
    }
  }

  /**
   * Writes the implementation with gene index provided in the user interface
   * to <code>ParameterSet.logFile</code> and opens a text editor
   * for viewing. To this end, all parameters are calculated anew.
   */
  public static void writeGene() {
    int index = Integer.parseInt(ui.getIndex());

    // write gene to file ParameterSet.log
    FileWriter writer = null;
    Gene gene;
    String tmp_strg = "";

    try {
      writer = new FileWriter(ParameterSet.logFile, false);
      writer.write("\r\n\r\n// ***********************\r\n// GENE INDEX " +
                   index + "\r\n// ***********************\r\n");
      gene = (Gene) population.genes.get(new Integer(index));
      try {
        Analyzer an = (Analyzer) Class.forName(ParameterSet.analyzer).
            newInstance();
        tmp_strg = an.getReport(gene);
      }
      catch (Exception e) {
        System.err.println("There seems to be a problem finding class " +
                           ParameterSet.analyzer);
      }
      writer.write(tmp_strg);
      writer.flush();
      writer.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }

    // open editor to show the contents of the logFile
    try {
      Runtime.getRuntime().exec(ParameterSet.editor + " " +
                                ParameterSet.logFile);
    }
    catch (IOException e) {
      System.err.println(e);
    }
  }

  public static void writePopFile() {

    String tmp_strg = "";
    try {
      FileWriter writer = new FileWriter(new File(ParameterSet.populationFile));
      writer.write(Integer.toString(population.genes.size()) + "\r\n");
      for (Iterator iter = population.genes.keySet().iterator(); iter.hasNext(); ) {
        int geneID = ( (Integer) iter.next()).intValue();
        Gene gene = (Gene) population.getGene(geneID);
        tmp_strg = geneID + " ";
        tmp_strg += gene.getFitnessString();
        tmp_strg += "\r\n";
        writer.write(tmp_strg);
      }
      writer.write(" END");
      writer.flush();
      writer.close();
    }
    catch (IOException e) {
      System.err.println(e);
    }
    debugPrint("Population written to file.");
  }


  public static void writePopFile(String filename) {

  String tmp_strg = "";
  try {
    FileWriter writer = new FileWriter(new File(filename));
    writer.write(Integer.toString(population.genes.size()) + "\r\n");
    for (Iterator iter = population.genes.keySet().iterator(); iter.hasNext(); ) {
      int geneID = ( (Integer) iter.next()).intValue();
      Gene gene = (Gene) population.getGene(geneID);
      tmp_strg = geneID + " ";
      tmp_strg += gene.getFitnessString();
      tmp_strg += "\r\n";
      writer.write(tmp_strg);
    }
    writer.write(" END");
    writer.flush();
    writer.close();
  }
  catch (IOException e) {
    System.err.println(e);
  }
  debugPrint("Population written to file.");
}

public static void initializeEXPO(){

   readSpec();
   random = new Random(ParameterSet.seed);
   // mismatch checking
   if (ParameterSet.mu != ParameterSet.lambda) {
     System.err.println("Assumption mu = lambda violated");
     System.exit(0);
   }
   if (ParameterSet.mu > ParameterSet.populationSize) {
     System.err.println("Assumption mu <= alpha violated");
     System.exit(0);
   }
   if (ParameterSet.dim != specification.getProblemDimension()) {
      System.err.println("Number of Objectives in " + ParameterSet.configFile +
                         " doesn't match");
      System.err.println("the number of objectives in " +
                         specificationFileName);
      System.exit(0);
   }

   if (ParameterSet.gui){
      // run interactive mode with GUI
      debugPrint("GUI-Mode called");
      ui = new UserInterface();
      wfc = new WatchFileChange();
    }
    else{
      // run fully automated without GUI
      debugPrint("NOGUI-Mode called");
      wfc = new WatchFileChange();
    }



}



}
