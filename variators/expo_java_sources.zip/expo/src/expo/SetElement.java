/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package expo;

/**
 * This class defines elements of sets such as flows, tasks,
 * resources, and scenarios. It mainly enables the use of sorting
 * procedures on Arrays and ArrayLists. The main field is
 * an integer <code>id</code> which is used as an index in various
 * situations. Another integer field <code>ord</code> can be used
 * to describe a sorting order.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class SetElement {

/**
 * The integer field <code>id</code> is used as an index of the element.
 * It must be unique for all elements in a set.
 */
  public int id;
/**
 * CTOR: creates a new SetElement object and stores id.
 * @param id int value containing id of SetElement
 */
  public SetElement(int id) {
    this.id = id;
  }

  /**
   * overriden toString method.
   * @return String containing the int <code>id</code>.
   */
  public String toString(){
    return new Integer(id).toString();
  }


}