/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */

package expo;

import java.io.*;
import java.util.*;
/**
 * <p>Title: Design Space Exploration Tool for Network Processors</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: </p>
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
public class Launcher {
  public Launcher() {
  }

  public static void main(String[] args) {
    Launcher launcher = new Launcher();

    if (args.length != 3) {
      displayHelpText();
      System.exit(0);
    }
    else {
      System.out.println(
          "EXPO version 2.0 (PISA edition) started, 04. 10. 2005 SK");
      // set some static variables
      ParameterSet.parameterFileName = args[0];
      ParameterSet.commFilePath = args[1];
      ParameterSet.pollingInterval = (int) Math.round(1000 *
          Double.parseDouble(args[2]));

      determineOptions(ParameterSet.parameterFileName);
    }
    EXPO.initializeEXPO();
  }






public static void displayHelpText() {
  System.out.println(
      "Please start the EXPO Tool using the following options:");
  System.out.println("expo parameter filenamebase poll");
  System.out.println("where:");
  System.out.println("\t parameter \t \t the name of the file containing the parameters for the expo tool");
  System.out.println("\t\t\t\t (normally the value 'expo' should be used)");
  System.out.println(
      "\t filenamebase \t \t the communication file name as 'spea.'");
  System.out.println("\t\t\t\t e.g. 'd:\\test\\spea.' or '/home/test/spea.'");
  System.out.println("\t poll \t\t\t the polling interval in [sec]");
}

public static boolean determineOptions(String filename){
  boolean bol=true;

try {
  FileReader fr = new FileReader(filename);
  BufferedReader br = new BufferedReader(fr);
  String key="", value="";
  String inString1 = br.readLine();
  while (inString1 != null) {
    StringTokenizer st1 = new StringTokenizer(inString1);
    while (st1.hasMoreTokens()) {
      key = st1.nextToken();
      value = st1.nextToken();
      bol = bol && setOption(key,value);
    }
    inString1 = br.readLine();
  }
}
catch (Exception ex) {
  System.err.println("Problem reading the parameter file! Terminating!");
}
return bol;
}


public static boolean setOption(String key, String value){
  if (key.equals("seed")){
    try {
      ParameterSet.seed = Long.parseLong(value);
      return true;
    }
    catch (Exception ex) {
      return false;
    }
  }
  else if (key.equals("specification")){
    ParameterSet.specFile = value;
    // specification is here...
    return true;
  }
  else if (key.equals("parameters")){
    return ParameterSet.parameterInput(value);
  }
  else if (key.equals("gui")){
    try {
      int test = Integer.parseInt(value);
      if (test == 1){
        ParameterSet.gui = true;
      }
      else{
        ParameterSet.gui = false;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return true;
  }

  return false;
}

}
