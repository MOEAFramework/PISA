/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package sps;

import java.util.*;
import java.io.*;
import java.util.ResourceBundle;
import expo.*;
import curve2.*;

/**
 * This class contains all the data which specify the problem instance
 * of a design space exploration. All data are specified as class
 * fields and all methods as class methods, as it is not intended to
 * generate instances of <code>Specification</code>. Access methods such as
 * <code>get</code> and <code>set</code> are not provided for
 * simplicity ... . <p><p>
 *
 * The data structures used are simply arrays. Elements of sets are
 * denoted as instances of <code>SetElement</code>. This simple notation
 * is possible, as the size of sets does not change after
 * reading in the problem specification.
 *
 * This class is for use with package <code>curve2</code> only.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class SPSSpecification implements Specification{

/**
 * The array <code>Flows</code> contains the set of flows. The index
 * just reflects some sorting, the contents is an instance of
 * <code>SetElement</code>.
 */
  public static SetElement[] Flows;

/**
 * The array <code>Scenarios</code> contains the set of scenarios. The index
 * just reflects some sorting, the contents is an instance of
 * <code>SetElement</code>.
 */
  public static SetElement[] Scenarios;

/**
 * The array <code>Tasks</code> contains the set of tasks. The index
 * just reflects some sorting, the contents is an instance of
 * <code>SetElement</code>.
 */
  public static SetElement[] Tasks;

/**
 * The array <code>Resources</code> contains the set of resource types. The index
 * just reflects some sorting, the contents is an instance of
 * <code>SetElement</code>.
 */
  public static SetElement[] Resources;

/**
 * <code>FName[flow.id]</code> contains the name of flow with <code>flow.id</code>.
 */
  public static String[] FName;

/**
 * <code>SName[scenario.id]</code> contains the name of a scenario
 * with <code>scenario.id</code>.
 */
  public static String[] SName;

/**
 * <code>TName[task.id]</code> contains the name of task with <code>task.id</code>.
 */
  public static String[] TName;

/**
 * <code>RName[resource]</code> contains the name of resource with
 * <code>resource.id</code>.
 */
  public static String[] RName;

/**
 * <code>FTasks[flow.id]</code> maps a flow to an array of tasks
 * which are executed in it.
 */
  public static SetElement[][] FTasks;

/**
 * <code>TTasks[task.id]</code> maps a task to an array of tasks
 * which are its direct predecessors in the task graph.
 */
  public static SetElement[][] TTasks;

/**
 * <code>SFDelay[scenario.id][flow.id]</code> yields
 * the maximal delay of a flow in a specific scenario.
 */
  public static double[][] SFDelay;

/**
 * <code>SMemory[scenario.id]</code> yields
 * the maximal memory available in a specific scenario.
 */
  public static double[] SMemory;

/**
 * <code>SFLowerArrival[scenario.id][flow.id]</code> yields
 * the lower arrival curve of a flow in a specific scenario.
 */
  public static LowerCurve[][] SFLowerArrival;

/**
 * <code>SFUpperArrival[scenario.id][flow.id]</code> yields
 * the upper arrival curve of a flow in a specific scenario.
 */
  public static UpperCurve[][] SFUpperArrival;

/**
 * <code>SFReal[scenario.id][flow.id]</code> yields <code>true</code>, if
 * a flow in a specific scenario is of constant rate, i.e. the arrival
 * curves are absolute, and yields <code>false</code>, if the flow
 * should be optimized with respect to its rate, i.e. the arrival curves
 * are relative.
 */
  public static boolean[][] SFReal;

/**
 * <code>RCost[resource.id]</code> yields
 * the cost of a resource unit.
 */
  public static double[] RCost;

/**
 * <code>RUnit[resource.id]</code> yields
 * the number of available units of a resource type.
 */
  public static int[] RUnit;

/**
 * <code>TResources[task.id]</code> yields an array of resource types
 * that can implement a task with <code>task.id</code>.
 */
  public static SetElement[][] TResources;

/**
 * <code>TRDemand[task.id][resource.id]</code> yields the computation demand of
 * a task with <code>task.id</code> on a single unit of <code>resource</code>.
 */
  public static double[][] TRDemand;

/**
 * <code>RLowerService[resource.id]</code> yields
 * the lower service curve of one unit of resource type with
 * <code>resource.id</code>.
 */
  public static LowerCurve[] RLowerService;

/**
 * <code>RUpperService[resource.id]</code> yields
 * the upper service curve of one unit of resource type with
 * <code>resource.id</code>.
 */
  public static UpperCurve[] RUpperService;

// These Parameters resided in ParameterSet before, but they acually refer
// to application specific parameters.
/**
 * APPLICATION SPECIFIC
 */
 public static double lowerScale = 0.001;
 /**
  * APPLICATION SPECIFIC
  */
 public static double upperScale = 100.0;
 /**
  * APPLICATION SPECIFIC
  */
 public static double precisionScale = 0.05;
 /**
  * APPLICATION SPECIFIC
  */
public static double probZeroAllocation = 0.5;

/**
 * APPLICATION SPECIFIC
 */
  public static double probMutationAllocation = 0.3;
  /**
   * APPLICATION SPECIFIC
   */
  public static double probMutationBinding = 0.5;
  /**
   * APPLICATION SPECIFIC
   */
  public static double probCrossoverAllocation = 0.3;
  /**
   * APPLICATION SPECIFIC
   */
  public static double probCrossoverBinding = 0.5;

  public static double probMutation = 0.5;

  public static double probCrossover = 0.5;



/**
 * The class initializes the size of the arrays. It must be called before anything
 * else, as all the data structures get initialized here. These sizes should be
 * available from the input specification, i.e. via MOSES.
 * @param numberOfFlows Number of flows.
 * @param numberOfScenarios Number of scenarios.
 * @param numberOfTasks Number of tasks.
 * @param numberOfResources Number of resource types.
 */
  public void initSize(int numberOfFlows, int numberOfScenarios, int numberOfTasks, int numberOfResources) {

    Flows = new SetElement[numberOfFlows];
    Scenarios = new SetElement[numberOfScenarios];
    Tasks = new SetElement[numberOfTasks];
    Resources = new SetElement[numberOfResources];
    for (int i = 0; i < numberOfFlows; i++) Flows[i] = new SetElement(i);
    for (int i = 0; i < numberOfScenarios; i++) Scenarios[i] = new SetElement(i);
    for (int i = 0; i < numberOfTasks; i++) Tasks[i] = new SetElement(i);
    for (int i = 0; i < numberOfResources; i++) Resources[i] = new SetElement(i);

    FName = new String[numberOfFlows];
    SName = new String[numberOfScenarios];
    TName = new String[numberOfTasks];
    RName = new String[numberOfResources];

    FTasks = new SetElement[numberOfFlows][];
    TTasks = new SetElement[numberOfTasks][];
    SFDelay = new double[numberOfScenarios][numberOfFlows];
    SMemory = new double[numberOfScenarios];
    SFLowerArrival = new LowerCurve[numberOfScenarios][numberOfFlows];
    SFUpperArrival = new UpperCurve[numberOfScenarios][numberOfFlows];
    SFReal = new boolean[numberOfScenarios][numberOfFlows];

    RCost = new double[numberOfResources];
    RUnit = new int[numberOfResources];
    TResources = new SetElement[numberOfTasks][];
    TRDemand = new double[numberOfTasks][numberOfResources];
    RLowerService = new LowerCurve[numberOfResources];
    RUpperService = new UpperCurve[numberOfResources];
  }


/**
 * This class reads in the specification data from a file.
 * The data are simply separated by whitespace. Strings
 * must be delimited by ' or ", e.g. "flowname". Comments
 * in C-style are supported. The ordering and number of data is
 * important. A sample file is spec.txt which should be included
 * in the project directory.
 *
 * @param file The FileReader of the file containing the input data.
 */
  public String simpleFileInput(File fileHandle) {


    int numberOfFlows = 0, numberOfTasks = 0;
    int numberOfResources = 0, numberOfScenarios = 0;
    int tmp_nval = 0;
    double tmp_q1 = 0.0,tmp_q2=0.0, tmp_r = 0.0, tmp_s = 0.0;
    FileReader file = null;
    try{
      file = new FileReader(fileHandle);
    }
    catch (Exception e){
      e.printStackTrace();
    }

    StreamTokenizer tokenStream = new StreamTokenizer(file);
    tokenStream.slashSlashComments(true);
    tokenStream.slashStarComments(true);


    try {

        tokenStream.nextToken();
        numberOfFlows = (int) tokenStream.nval;
        tokenStream.nextToken();
        numberOfTasks = (int) tokenStream.nval;
        tokenStream.nextToken();
        numberOfResources = (int) tokenStream.nval;
        tokenStream.nextToken();
        numberOfScenarios = (int) tokenStream.nval;
        initSize(numberOfFlows, numberOfScenarios, numberOfTasks, numberOfResources);

        for (int i = 0; i < numberOfFlows; i++) {
          tokenStream.nextToken();
          FName[i] = tokenStream.sval;
        }
        for (int i = 0; i < numberOfTasks; i++) {
          tokenStream.nextToken();
          TName[i] = tokenStream.sval;
        }
        for (int i = 0; i < numberOfResources; i++) {
          tokenStream.nextToken();
          RName[i] = tokenStream.sval;
        }
        for (int i = 0; i < numberOfScenarios; i++) {
          tokenStream.nextToken();
          SName[i] = tokenStream.sval;
        }

        for (int i = 0; i < numberOfFlows; i++) {
          tokenStream.nextToken();
          tmp_nval = (int) tokenStream.nval;
          FTasks[i] = new SetElement[tmp_nval];
          for (int j = 0; j < tmp_nval; j++) {
            tokenStream.nextToken();
            FTasks[i][j] = Tasks[(int) tokenStream.nval];
          }
        }
        for (int i = 0; i < numberOfTasks; i++) {
          tokenStream.nextToken();
          tmp_nval = (int) tokenStream.nval;
          TTasks[i] = new SetElement[tmp_nval];
          for (int j = 0; j < tmp_nval; j++) {
            tokenStream.nextToken();
            TTasks[i][j] = Tasks[(int) tokenStream.nval];
          }
        }

        for (int i = 0; i < numberOfScenarios; i++) {
          for (int j = 0; j < numberOfFlows; j++) {
            tokenStream.nextToken();
            SFDelay[i][j] = tokenStream.nval;
          }
        }
        for (int i = 0; i < numberOfScenarios; i++) {
          tokenStream.nextToken();
          SMemory[i] = tokenStream.nval;
        }
        for (int i = 0; i < numberOfScenarios; i++) {
          for (int j = 0; j < numberOfFlows; j++) {
            tokenStream.nextToken();
            tmp_q1 = tokenStream.nval;
            tokenStream.nextToken();
            //tmp_q2 = tokenStream.nval;
            //tokenStream.nextToken();
            tmp_r = tokenStream.nval;
            tokenStream.nextToken();
            tmp_s = tokenStream.nval;
            SFLowerArrival[i][j] = new LowerCurve(tmp_q1, tmp_r, tmp_s);
          }
        }
        for (int i = 0; i < numberOfScenarios; i++) {
          for (int j = 0; j < numberOfFlows; j++) {
            tokenStream.nextToken();
            tmp_q1 = tokenStream.nval;
            tokenStream.nextToken();
            //tmp_q2 = tokenStream.nval;
            //tokenStream.nextToken();
            tmp_r = tokenStream.nval;
            tokenStream.nextToken();
            tmp_s = tokenStream.nval;
            SFUpperArrival[i][j] = new UpperCurve(tmp_q1, tmp_r, tmp_s);
          }
        }
        for (int i = 0; i < numberOfScenarios; i++) {
          for (int j = 0; j < numberOfFlows; j++) {
            tokenStream.nextToken();
            if ((int) tokenStream.nval == 0) {
              SFReal[i][j] = false;
            } else {
              SFReal[i][j] = true;
            }
          }
        }

        for (int i = 0; i < numberOfResources; i++) {
          tokenStream.nextToken();
          RCost[i] = tokenStream.nval;
        }
        for (int i = 0; i < numberOfResources; i++) {
          tokenStream.nextToken();
          RUnit[i] = (int) tokenStream.nval;
        }
        for (int i = 0; i < numberOfTasks; i++) {
          tokenStream.nextToken();
          tmp_nval = (int) tokenStream.nval;
          TResources[i] = new SetElement[tmp_nval];
          for (int j = 0; j < tmp_nval; j++) {
            tokenStream.nextToken();
            TResources[i][j] = Resources[(int) tokenStream.nval];
          }
        }
        for (int i = 0; i < numberOfTasks; i++) {
          for (int j = 0; j < numberOfResources; j++) {
            tokenStream.nextToken();
            TRDemand[i][j] = tokenStream.nval;
          }
        }
        for (int i = 0; i < numberOfResources; i++) {
          tokenStream.nextToken();
          tmp_q1 = tokenStream.nval;
          tokenStream.nextToken();
          //tmp_q2 = tokenStream.nval;
          //tokenStream.nextToken();
          tmp_r = tokenStream.nval;
          tokenStream.nextToken();
          tmp_s = tokenStream.nval;
          RLowerService[i] = new LowerCurve(tmp_q1, tmp_r, tmp_s);
        }
        for (int i = 0; i < numberOfResources; i++) {
          tokenStream.nextToken();
          tmp_q1 = tokenStream.nval;
          tokenStream.nextToken();
          //tmp_q2 = tokenStream.nval;
          //tokenStream.nextToken();
          tmp_r = tokenStream.nval;
          tokenStream.nextToken();
          tmp_s = tokenStream.nval;
          RUpperService[i] = new UpperCurve(tmp_q1, tmp_r, tmp_s);
        }

        //System.out.println(EXPO.parameterFileName);
        ResourceBundle rb = ResourceBundle.getBundle(ParameterSet.propertiesFileName);

        lowerScale = Double.parseDouble(rb.getString("LOWER_SCALE"));
        upperScale = Double.parseDouble(rb.getString("UPPER_SCALE"));
        precisionScale = Double.parseDouble(rb.getString("PRECISION_SCALE"));
        probZeroAllocation = Double.parseDouble(rb.getString("PROB_ZERO_ALLOCATION"));
        probMutationAllocation = Double.parseDouble(rb.getString("PROB_MUTATION_ALLOCATION"));
        probMutationBinding = Double.parseDouble(rb.getString("PROB_MUTATION_BINDING"));
        probCrossoverAllocation = Double.parseDouble(rb.getString("PROB_CROSSOVER_ALLOCATION"));
        probCrossoverBinding = Double.parseDouble(rb.getString("PROB_CROSSOVER_BINDING"));
        probCrossover = Double.parseDouble(rb.getString("PROB_CROSSOVER"));
        probMutation = Double.parseDouble(rb.getString("PROB_MUTATION"));

    } catch (IOException e) {
      System.err.println(e);
    } catch (ArrayIndexOutOfBoundsException e) {
      System.err.println(e + ": Probably, there is an error in the file for Specification.initFileInput arround line number " + tokenStream.lineno());
    }
    try{
      file.close();
    }
    catch (Exception e){
      e.printStackTrace();
    }
    return "File input done..";
  }

  public int getProblemDimension(){
    return Scenarios.length +1;
  }

  public double getMutationProbability(){
    return this.probMutation;
  }

  public double getCrossoverProbability(){
    return this.probCrossover;
  }



}
