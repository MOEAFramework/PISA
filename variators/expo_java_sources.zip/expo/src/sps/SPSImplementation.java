/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.
 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.
 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich
 */

package sps;

import java.util.*;
import java.io.*;
import expo.*;
import expo.plot.*;
import curve2.*;

/**
 * This class contains all the data which are the result of th optimization,
 * i.e. it specifies a particular implementation. Access methods such as
 * <code>get</code> and <code>set</code> are not provided for
 * simplicity ... . <p><p>
 *
 * The data structures used are again simply arrays. The flows, tasks,
 * scenarios and all other specification data are stored in the class
 * <code>SPSSpecification</code>.
 *
 * ( 2 piece linear approximation version )
 * @author Lothar Thiele, Simon Kuenzli
 * @version 1.0
 */
public class SPSImplementation {

  /**
   * <code>STBinding[scenario.id][task.id]</code> yields the resource type
   * to which the task with <code>task.id</code> is bound in the
   * scenario with <code>scneario.id</code>. The resource is determined
   * by its <code>SetElement</code>.
   */
  public SetElement[][] STBinding;

  /**
   * <code>allocation[resource.id]</code> yields the number of
   * allocated resource units of resource with <code>resource.id</code>.
   */
  public int[] RAllocation;

  /**
   * <code>SFPriority[scenario.id][ord]</code> yields the flow with the
   * ord-highest priority in the scenario with <code>scneario.id</code>.
   * The flow is determined by its <code>SetElement</code>.
   */
  public SetElement[][] SFPriority;

  /**
   * <code>totalCost</code> is the sum of all allocated resource units.
   */
  public double totalCost;

  /**
   * <code>scale[scenario.id]</code> is the maximal possible scaling factor
   * of the arrival curves (for highest performance).
   */
  public double[] SScale;

  /**
   * <code>SAccumulatedDelay[scenario.id][flow.id]</code> is the maximal delay
   * a packet of flow with <code>flow.id</code> in scenario with
   * <code>scenario.id</code>
   */
  public double SFAccumulatedDelay[][];

  /**
   * <code>SAccumulatedMemory[scenario.id][flow.id]</code> is the maximal
   * number of stored packets of flow with <code>flow.id</code> in scenario
   * with <code>scenario.id</code>.
   */
  public double SFAccumulatedMemory[][];

  /**
   * <code>STotalMemory[scenario.id]</code> is the maximal number of stored
   * packets of all flows in scenario with <code>scenario.id</code>.
   */
  public double[] STotalMemory;

  public long[][] RUtilization;
  /**
   * <code>SSortedTaskFlow</code> is an array containing pairs of task and flow
   * <code>SetElement</code>s, i.e. <code>SSortedTaskFlow[scneario.id][n][0]
   * </code>
   * gives the <code>SetElement</code> of
   * of the task and <code>SSortedTaskFlow[scenario.id][n][1]</code> yields the
   * <code>SetElement</code> of the flow. <code>n</code> determines a sorting
   * order.
   */
  private SetElement[][][] SSortedTaskFlow;

  /**
   * Some constants with obvious meaning
   */
  private int numberOfFlows, numberOfScenarios, numberOfTasks,
      numberOfResources;

  /**
   * These curves describe the final lower and upper service and arrival
   * curves. The service curves correspond to the remaining capability of the
   * resources and the arrival curves describe the processed packets.
   */
  private LowerCurve[][] RCurrentLowerService;
  private UpperCurve[][] RCurrentUpperService;
  private LowerCurve[][] FCurrentLowerArrival;
  private UpperCurve[][] FCurrentUpperArrival;



  /**
   * The constructor does nothing.
   */
  public SPSImplementation() {
  }

  /**
   * The class initializes the size of the main arrays. It must be called before anything
   * else, as all the data structures get initialized here. These sizes are determined
   * from class <code>Specification</code>.
   */
  public void initSize() {
    numberOfFlows = ( (SPSSpecification) EXPO.specification).Flows.length;
    numberOfScenarios = ( (SPSSpecification) EXPO.specification).Scenarios.
        length;
    numberOfTasks = ( (SPSSpecification) EXPO.specification).Tasks.length;
    numberOfResources = ( (SPSSpecification) EXPO.specification).Resources.
        length;

    STBinding = new SetElement[numberOfScenarios][numberOfTasks];
    RAllocation = new int[numberOfResources];
    SFPriority = new SetElement[numberOfScenarios][numberOfFlows];
    SScale = new double[numberOfScenarios];

    RUtilization = new long[numberOfScenarios][numberOfResources];

    SFAccumulatedMemory = new double[numberOfScenarios][numberOfFlows];
    SFAccumulatedDelay = new double[numberOfScenarios][numberOfFlows];
    STotalMemory = new double[numberOfScenarios];

    SSortedTaskFlow = new SetElement[numberOfScenarios][][];

    RCurrentLowerService = new LowerCurve[numberOfScenarios][numberOfResources];
    RCurrentUpperService = new UpperCurve[numberOfScenarios][numberOfResources];
    FCurrentLowerArrival = new LowerCurve[numberOfScenarios][numberOfFlows];
    FCurrentUpperArrival = new UpperCurve[numberOfScenarios][numberOfFlows];
  }

  /**
   * This class reads in the implemenation data from a file.
   * The data are simply separated by whitespace. Strings
   * must be delimited by ' or ", e.g. "flowname". Comments
   * in C-style are supported. The ordering and number of data is
   * important. A sample file is impl.txt which should be included
   * in the project directory. Note that this does work only if
   * the class <code>Specification</code> has been initialized
   * beforehand.
   *
   * @param file The FileReader of the file containing the input data.
   */
  public void simpleFileInput(FileReader file) {

    StreamTokenizer tokenStream = new StreamTokenizer(file);
    tokenStream.slashSlashComments(true);
    tokenStream.slashStarComments(true);

    initSize();

    try {
      for (int i = 0; i < numberOfScenarios; i++) {
        for (int j = 0; j < numberOfTasks; j++) {
          tokenStream.nextToken();
          STBinding[i][j] = ( (SPSSpecification) EXPO.specification).Resources[ (int)
              tokenStream.nval];
        }
      }
      for (int i = 0; i < numberOfResources; i++) {
        tokenStream.nextToken();
        RAllocation[i] = (int) tokenStream.nval;
      }
      for (int i = 0; i < numberOfScenarios; i++) {
        for (int j = 0; j < numberOfFlows; j++) {
          tokenStream.nextToken();
          SFPriority[i][j] = ( (SPSSpecification) EXPO.specification).Flows[ (int)
              tokenStream.nval];
        }
      }
    }
    catch (IOException e) {
      System.err.println(e);
    }
    catch (ArrayIndexOutOfBoundsException e) {
      System.err.println(e + ": Probably, there is an error in the file for Implementation.initFileInput arround line number " +
                         tokenStream.lineno());
    }
  }

  /**
   * The method computes the total cost of the implementation.
   */
  public void computeTotalCost() {

    double tmp_cost = 0;
    for (int i = 0; i < numberOfResources; i++) {
      tmp_cost = tmp_cost +
          RAllocation[i] * ( (SPSSpecification) EXPO.specification).RCost[i];
    }
    totalCost = tmp_cost;
  }

  /**
   * The method computes the delay and memory values for each flow in each scenario.
   * To this end, it maximizes <code>SScale</code> until a delay constraint is
   * violated. The results are the fields <code>SFAccumulatedDelay,
   * SFAccumulatedMemory, STotalMemory</code>.
   */
  public void computeDelayMemory() {

    SetElement scenario;
    sortAllTasks();
    // Now starts the binary search for the optimal scale values; it is
    // done for all scenarios independently.
    for (int i = 0; i < numberOfScenarios; i++) {
      scenario = ( (SPSSpecification) EXPO.specification).Scenarios[i];
      // Here, the scale value and all curves are determined.
      computeScale(scenario);
    }
  }

  /**
   * This method performs a binary search to determine the optimal
   * scale value.
   * @param scenario The scenario for which SScale[scenario.id] is determined.
   */
  private void computeScale(SetElement scenario) {

    int scenarioID = scenario.id;
    int flowID;
    double lScale = ( (SPSSpecification) EXPO.specification).lowerScale;
    double uScale = ( (SPSSpecification) EXPO.specification).upperScale;
    double precision = ( (SPSSpecification) EXPO.specification).precisionScale;
    boolean tooLarge;

    // This is the test, whether lSlack is feasible or not.
    SScale[scenarioID] = lScale;
    computeAllCurves(scenario);
    if (STotalMemory[scenarioID] >
        ( (SPSSpecification) EXPO.specification).SMemory[scenarioID]) {
      return;
    }
    for (int i = 0; i < numberOfFlows; i++) {
      flowID = ( (SPSSpecification) EXPO.specification).Flows[i].id;
      if (SFAccumulatedDelay[scenarioID][flowID] >
          ( (SPSSpecification) EXPO.specification).SFDelay[scenarioID][flowID]) {
        System.err.println("delay already  violated.." +
                           SFAccumulatedDelay[scenarioID][flowID] + "  " +
                           ( (SPSSpecification) EXPO.specification).SFDelay[
                           scenarioID][flowID]);
        return;
      }
    }

    // Now we iterate slack
    while ( (uScale - lScale) / 2.0 > precision) { /// changed
      SScale[scenarioID] = (uScale + lScale) / 2.0;
      computeAllCurves(scenario);
      tooLarge = false;
      if (STotalMemory[scenarioID] >
          ( (SPSSpecification) EXPO.specification).SMemory[scenarioID]) {
        tooLarge = true;
      }
      else {
        for (int i = 0; i < numberOfFlows; i++) {
          flowID = ( (SPSSpecification) EXPO.specification).Flows[i].id;
          if (SFAccumulatedDelay[scenarioID][flowID] >
              ( (SPSSpecification) EXPO.specification).SFDelay[scenarioID][
              flowID]) {
            tooLarge = true;
            continue;
          }
        }
      }
      if (tooLarge) {
        uScale = SScale[scenarioID];
      }
      else {
        lScale = SScale[scenarioID];
      }
    }
    SScale[scenarioID] = lScale;
    computeAllCurves(scenario);
  }

  /**
   * The method computes all arrival and service curves related to
   * the task-flow pairs stored in <code>SSortedTaskFlow</code>. The result
   * is written to the arrays <code>TFLowerArrival</code>,
   * <code>TFUpperArrival</code>, <code>TFLowerService</code>,
   * <code>TFUpperService</code> and <code>FAccumulatedLowerService</code>.
   * In addition, the accumulated Delay and Memory sizes
   * <code>SFAccumulatedDelay, SFAccumulatedMemory, STotalMemory</code> are
   * determined.
   *
   * @param scenario The scenario for which the curves are determined.
   */
  private void computeAllCurves(SetElement scenario) {

    LowerCurve[] FAccumulatedLowerService = new LowerCurve[numberOfFlows]; ;
    LowerCurve lowerCurve;
    UpperCurve upperCurve;
    int taskID, flowID, resourceID, scenarioID, predTaskID;
    double scale = 1.0;

    // determine id of the current scenario;
    scenarioID = scenario.id;
    // initializes the accumulated lower service curve for all flows;
    for (int i = 0; i < numberOfFlows; i++) {
      FAccumulatedLowerService[i] = new LowerCurve(0.0, 1.0E10, 1.0E10); // Dangerous!!
    }
    // initializes the running lower and upper service curves of the
    // resources.
    for (int i = 0; i < numberOfResources; i++) {
      resourceID = ( (SPSSpecification) EXPO.specification).Resources[i].id;
      lowerCurve = ( (SPSSpecification) EXPO.specification).RLowerService[
          resourceID].multiply(RAllocation[resourceID]);
      RCurrentLowerService[scenarioID][i] = new LowerCurve(lowerCurve);
      upperCurve = ( (SPSSpecification) EXPO.specification).RUpperService[
          resourceID].multiply(RAllocation[resourceID]);
      RCurrentUpperService[scenarioID][i] = new UpperCurve(upperCurve);
    }
    // initializes the running lower and upper arrival curves of the
    // flows.
    for (int i = 0; i < numberOfFlows; i++) {
      flowID = ( (SPSSpecification) EXPO.specification).Flows[i].id;
      if ( ( (SPSSpecification) EXPO.specification).SFReal[scenarioID][flowID]) {
        scale = 1.0;
      }
      else {
        scale = SScale[scenarioID];
      }
      lowerCurve = ( (SPSSpecification) EXPO.specification).SFLowerArrival[
          scenarioID][flowID].multiply(scale);
      FCurrentLowerArrival[scenarioID][i] = new LowerCurve(lowerCurve);
      upperCurve = ( (SPSSpecification) EXPO.specification).SFUpperArrival[
          scenarioID][flowID].multiply(scale);
      FCurrentUpperArrival[scenarioID][i] = new UpperCurve(upperCurve);
    }
    // determines the quantities related to each task-flow combination
    // by iterating thorough all of them;
    for (int i = 0; i < SSortedTaskFlow[scenarioID].length; i++) {
      taskID = SSortedTaskFlow[scenarioID][i][0].id;
      flowID = SSortedTaskFlow[scenarioID][i][1].id;
      resourceID = STBinding[scenarioID][taskID].id;
      // the following accumulation only works if we are dealing with task chains!!!
      if ( ( (SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID] != 0.0) {
        // perform MaxPlus convolution between old accumulated lower service and
        // the current lower service of the resource; this works only if
        // the tasks form a chain!
        lowerCurve = RCurrentLowerService[scenarioID][resourceID].multiply(1 / ((SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID]);
        FAccumulatedLowerService[flowID] = CurveTransform.lowerArrival(FAccumulatedLowerService[flowID], lowerCurve);
        // determine current accumulated service and arrival curves;
        lowerCurve = FCurrentLowerArrival[scenarioID][flowID].multiply( ((SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID]);
        upperCurve = FCurrentUpperArrival[scenarioID][flowID].multiply( ((SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID]);
        FCurrentLowerArrival[scenarioID][flowID] = CurveTransform.lowerArrival(lowerCurve, RCurrentLowerService[scenarioID][resourceID]);
        FCurrentUpperArrival[scenarioID][flowID] = CurveTransform.upperArrival(upperCurve, RCurrentLowerService[scenarioID][resourceID],RCurrentUpperService[scenarioID][resourceID]);
        RCurrentLowerService[scenarioID][resourceID] = CurveTransform.lowerService(upperCurve,RCurrentLowerService[scenarioID][resourceID]);
        RCurrentUpperService[scenarioID][resourceID] = CurveTransform.upperService(lowerCurve,RCurrentUpperService[scenarioID][resourceID]);
        // scale back
        FCurrentLowerArrival[scenarioID][flowID] = FCurrentLowerArrival[scenarioID][flowID].multiply(1 /( (SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID]);
        FCurrentUpperArrival[scenarioID][flowID] = FCurrentUpperArrival[scenarioID][flowID].multiply(1 /( (SPSSpecification) EXPO.specification).TRDemand[taskID][resourceID]);
      }
    }

    /**
     * Now, the delay and memory for each flow is determined. To this end,
     * we use the accumulated lower service curve for each flow
     * <code>FAccumulatedLowerService[flow.id]</code>;
     */
    STotalMemory[scenarioID] = 0.0;

    for (int i = 0; i < numberOfFlows; i++) {
      flowID = ( (SPSSpecification) EXPO.specification).Flows[i].id;
      if ( ( (SPSSpecification) EXPO.specification).SFReal[scenarioID][flowID]) {
        scale = 1.0;
      }
      else {
        scale = SScale[scenarioID];
      }
      upperCurve = ( (SPSSpecification) EXPO.specification).SFUpperArrival[scenarioID][flowID].multiply(scale);
      SFAccumulatedDelay[scenarioID][flowID] = CurveTransform.maxDelay(upperCurve, FAccumulatedLowerService[flowID]);
      SFAccumulatedMemory[scenarioID][flowID] = CurveTransform.maxBacklog(upperCurve, FAccumulatedLowerService[flowID]);
      STotalMemory[scenarioID] = STotalMemory[scenarioID] + SFAccumulatedMemory[scenarioID][flowID];
    }
    // utilization

   // for (int j = 0; j < numberOfScenarios; j++) {
   int j= scenarioID;
   for (int i = 0; i < numberOfResources; i++) {
        if ( (RAllocation[i] > 0) && (RCurrentLowerService[j][i] != null)) {
          RUtilization[j][i] = (long) Math.round( ( ( (SPSSpecification) EXPO.
              specification).RLowerService[i].s -
              RCurrentLowerService[j][i].s) *100 /
                                                 ( (SPSSpecification) EXPO.
                                                  specification).RLowerService[
                                                 i].s);

        }
        else {
          RUtilization[j][i] = -10;
        }
      }
    //}

  }

  /**
   * The method <code>printImplementation</code> returns in textual form the
   * implementation.
   * @return String, that contains the implementation in textual form.
   */
  public String printImplementation() {
    String str = "";

    str += "// 'name of resource' 'number of allocated units'\r\n";
    for (int i = 0; i < numberOfResources; i++) {
      str += ( (SPSSpecification) EXPO.specification).RName[i] + " " +
          RAllocation[i] + "\r\n";
    }
    str += "// 'total cost'\r\n";
    str += totalCost + "\r\n";
    str +=
        "// 'name of scenario' 'name of task' 'name of bound resource type'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfTasks; j++) {
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).TName[j] + " " +
            ( (SPSSpecification) EXPO.specification).RName[STBinding[i][j].id] +
            "\r\n";
      }
    }

    str += "// 'name of scenario' 'name of flows in decreasing priority'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      str += ( (SPSSpecification) EXPO.specification).SName[i];
      for (int j = 0; j < numberOfFlows; j++) {
        str += " " +
            ( (SPSSpecification) EXPO.specification).FName[SFPriority[i][j].id];
      }
      str += "\r\n";
    }

    str += "// 'name of scenario' 'optimal scale factor for input flows'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      str += ( (SPSSpecification) EXPO.specification).SName[i] + " " + SScale[i] +
          "\r\n";
    }

    str +=
        "// 'name of scenario' 'name of flow' 'maximal accumulated delay of flow'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfFlows; j++) {
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).FName[j] + " " +
            SFAccumulatedDelay[i][j] + "\r\n";
      }
    }

    str +=
        "// 'name of scenario' 'name of flow' 'maximal accumulated memory of flow'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfFlows; j++) {
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).FName[j] + " " +
            SFAccumulatedMemory[i][j] + "\r\n";
      }
    }

    str += "// 'name of scenario' 'total memory usage'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
          STotalMemory[i] + "\r\n";
    }

    str += "// 'name of scenario' 'name of resource' 'q, r, s of lower service' 'q, r, s of upper service'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfResources; j++) {
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).RName[j] + " " +
            RCurrentLowerService[i][j].q + " " + RCurrentLowerService[i][j].r +
            " " + RCurrentLowerService[i][j].s + " " +
            RCurrentUpperService[i][j].q + " " + RCurrentUpperService[i][j].r +
            " " + RCurrentUpperService[i][j].s + "\r\n";
      }
    }

    str += "// 'name of scenario' 'name of flow' 'q, r, s of lower arrival' 'q, r, s of upper arrival'\r\n";
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfFlows; j++) {
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).FName[j] + " " +
            FCurrentLowerArrival[i][j].q + " " + FCurrentLowerArrival[i][j].r +
            " " + FCurrentLowerArrival[i][j].s + " " +
            FCurrentUpperArrival[i][j].q + " " + FCurrentUpperArrival[i][j].r +
            " " + FCurrentUpperArrival[i][j].s + "\r\n";
      }
    }

    str += "// resource utilization ... \r\n";
    for (int j = 0; j < numberOfResources; j++) {
      for (int i = 0; i < numberOfScenarios; i++) {
        double utilization = ( ( (SPSSpecification) EXPO.specification).
                              RLowerService[j].s - RCurrentLowerService[i][j].s) *
            100 / ( (SPSSpecification) EXPO.specification).RLowerService[j].s;
        long utilong = Math.round(utilization);
        str += ( (SPSSpecification) EXPO.specification).SName[i] + " " +
            ( (SPSSpecification) EXPO.specification).RName[j] + "  " + utilong +
            " %  \r\n";
      }
    }

    return str;
  }

  /**
   * The method <code>plotImplementation</code> plots the inital and resulting
   * arrival and service curves of the current implementation.
   */
  public void plotImplementation() {

    double maxX;
    int numberOfScenarios = ( (SPSSpecification) EXPO.specification).Scenarios.
        length;
    int numberOfFlows = ( (SPSSpecification) EXPO.specification).Flows.length;
    int numberOfResources = ( (SPSSpecification) EXPO.specification).Resources.
        length;
    CurvePlot plotai[][] = new CurvePlot[numberOfScenarios][numberOfFlows];
    CurvePlot plotao[][] = new CurvePlot[numberOfScenarios][numberOfFlows];
    CurvePlot plotsi[] = new CurvePlot[numberOfResources];
    CurvePlot plotso[][] = new CurvePlot[numberOfScenarios][numberOfResources];

    maxX = Double.parseDouble(EXPO.ui.getMaxX());

    for (int i = 0;
         i < ( (SPSSpecification) EXPO.specification).Scenarios.length; i++) {
      for (int j = 0; j < ( (SPSSpecification) EXPO.specification).Flows.length;
           j++) {
        plotai[i][j] = new CurvePlot(maxX, 0, 0);
        plotai[i][j].pt.setTitle("initial arrival, scenario " +
                                 ( (SPSSpecification) EXPO.specification).SName[
                                 i] + ", flow " +
                                 ( (SPSSpecification) EXPO.specification).FName[
                                 j]);
        plotai[i][j].addCurve("upper arrival",
                              ( (SPSSpecification) EXPO.specification).
                              SFUpperArrival[i][j].multiply(1)); //SScale[i]));
        plotai[i][j].addCurve("lower arrival",
                              ( (SPSSpecification) EXPO.specification).
                              SFLowerArrival[i][j].multiply(1)); //SScale[i]));
      }
    }

    for (int j = 0;
         j < ( (SPSSpecification) EXPO.specification).Resources.length; j++) {
      if (RAllocation[j] > 0) {
        plotsi[j] = new CurvePlot(maxX, 400, 0);
        plotsi[j].pt.setTitle("initial service, resource " +
                              ( (SPSSpecification) EXPO.specification).RName[j]);
        plotsi[j].addCurve("upper service",
                           ( (SPSSpecification) EXPO.specification).
                           RUpperService[j]);
        plotsi[j].addCurve("lower service",
                           ( (SPSSpecification) EXPO.specification).
                           RLowerService[j]);
      }
    }
    for (int i = 0;
         i < ( (SPSSpecification) EXPO.specification).Scenarios.length; i++) {
      for (int j = 0;
           j < ( (SPSSpecification) EXPO.specification).Resources.length; j++) {
        if (RAllocation[j] > 0) {
          plotso[i][j] = new CurvePlot(maxX, 400, 300);
          plotso[i][j].pt.setTitle("final service, scenario " +
                                   ( (SPSSpecification) EXPO.specification).
                                   SName[i] + ", resource " +
                                   ( (SPSSpecification) EXPO.specification).
                                   RName[j]);
          plotso[i][j].addCurve("upper service", RCurrentUpperService[i][j]);
          plotso[i][j].addCurve("lower service", RCurrentLowerService[i][j]);
        }
      }
    }
    for (int i = 0;
         i < ( (SPSSpecification) EXPO.specification).Scenarios.length; i++) {
      for (int j = 0; j < ( (SPSSpecification) EXPO.specification).Flows.length;
           j++) {
        plotao[i][j] = new CurvePlot(maxX, 0, 300);
        plotao[i][j].pt.setTitle("final arrival, scenario " +
                                 ( (SPSSpecification) EXPO.specification).SName[
                                 i] + ", flow " +
                                 ( (SPSSpecification) EXPO.specification).FName[
                                 j]);
        plotao[i][j].addCurve("upper arrival", FCurrentUpperArrival[i][j]);
        plotao[i][j].addCurve("lower arrival", FCurrentLowerArrival[i][j]);
      }
    }

  }

  /**
   * This method takes all tasks of the SPSSpecification, which have to be
   * performed for packets of the flow specified in <code>flowID</code>.
   * These tasks are sorted and stored in an ArrayList.
   * This ArrrayList is then returned.
   *
   * @param flowID ID of the flow for which the task chain is wanted
   * @return ArrayList containing all sorted tasks. The first task in the
   * list is the task that has to be performed first.
   */
  private ArrayList taskChain(int flowID) {
    ArrayList al = new ArrayList();
    HashSet hs = new HashSet();
    HashSet ps = new HashSet();

    SetElement[] tasks = ( (SPSSpecification) EXPO.specification).FTasks[flowID];
    for (int i = 0; i < tasks.length; i++) {
      hs.add(tasks[i]);
    }
    ps = (HashSet) hs.clone();
    // look for task with no successor.
    // actually for a task that is never a predecessor..
    SetElement lastNode;
    SetElement[] preds;
    for (int i = 0; i < tasks.length; i++) {
      preds = ( (SPSSpecification) EXPO.specification).TTasks[tasks[i].id];
      for (int j = 0; j < preds.length; j++) {
        if (hs.contains(preds[j])) {
          hs.remove(preds[j]);
        }
      }
    }
    if (hs.size() != 1) {
      System.err.println(
          "There is an error in the Specification. (more than 1 final task for flow)");
    }
    lastNode = (SetElement) hs.iterator().next();
    al.add(lastNode);
    preds = ( (SPSSpecification) EXPO.specification).TTasks[lastNode.id];
    while (preds.length != 0) {
      ArrayList tempList = new ArrayList();
      for (int j = 0; j < preds.length; j++) {
        // check whether it is the last one...
        if (ps.contains(preds[j])){
            tempList.add(preds[j]);
        }
      }
      SetElement mySetElement = whichIsLastNode(tempList, flowID);
      if (ps.contains(mySetElement)) {
          al.add(0, mySetElement);
          lastNode = mySetElement;
          preds = ( (SPSSpecification) EXPO.specification).TTasks[lastNode.id];
      }
    }
    return al;
  }

  /**
   *
   */
  protected SetElement whichIsLastNode(ArrayList al, int flowID){
    //System.out.println("LAST node called");
    if (al.size()>2){
      System.out.println("The list of predecessors of a task for one flow cannot be larger than 2 in a DAG");
    }
    if (al.size() == 1){
      return (SetElement) al.get(0);
    }
    else{
      SetElement start = (SetElement) al.get(0);
      SetElement end = (SetElement) al.get(1);
      if (existsPathFrom(start, end, flowID)){
        return end;
      }
      else{
        return start;
      }
    }
  }

  /**
   *
   */
  protected boolean existsPathFrom(SetElement start, SetElement end, int flowID){
    //System.out.println("Pathfinder called");
    HashSet hs = new HashSet();
    SetElement[] tasks = ( (SPSSpecification) EXPO.specification).FTasks[flowID];
    for (int i = 0; i < tasks.length; i++) {
      hs.add(tasks[i]);
    }

    SetElement[] preds = ((SPSSpecification)EXPO.specification).TTasks[end.id];
    while (preds.length !=0){
      ArrayList p = new ArrayList();
      for (int i=0;i<preds.length;i++){
        if (preds[i].id == start.id){
          return true;
        }
        if (hs.contains(preds[i])){
          p.add(preds[i]);
        }
      }
      if (p.size() ==0){
        return false;
      }
      ArrayList pp = new ArrayList();
      for (int i = 0; i< p.size(); i++){
        SetElement[] pred2 = ((SPSSpecification)EXPO.specification).TTasks[((SetElement)p.get(i)).id];
        for (int j =0; j< pred2.length;j++){
          pp.add(pred2[j]);
        }
      }
      preds = new SetElement[pp.size()];
      for (int i=0;i<pp.size();i++){
        preds[i] = (SetElement) pp.get(i);
      }
    }
    return false;
  }


  /**
   * This method puts all task chains of the different flow into one array,
   * dependent on the priority of the flow in a scenario.
   * The results of this sorting is stored in the variable SSortedTaskFlow[scenarioID].
   * example: if in scenario 0, flow 1 has priority 1 and flow 2 has priority 3
   *          in flow 1 tasks 10 and 12 have to complete
   *          in flow 2 tasks 8 and 9 have to complete
   * SSortedTaskFlow[0][0] = {10 , 1}
   * SSortedTaskFlow[0][1] = {12 , 1}
   * SSortedTaskFlow[0][2] = {8 , 2}
   * SSortedTaskFlow[0][3] = {9 , 2}
   */
  private void sortAllTasks() {
    ArrayList[] completeList = new ArrayList[numberOfFlows];

    ArrayList currentTaskChain = new ArrayList();
    SetElement flow;
    SSortedTaskFlow = new SetElement[numberOfScenarios][][];

    for (int k = 0; k < numberOfScenarios; k++) {
      int taskLength = 0;
      for (int i = 0; i < numberOfFlows; i++) {
        flow = SFPriority[k][numberOfFlows - i - 1];
        completeList[i] = taskChain(flow.id);
        taskLength = taskLength + completeList[i].size();
      }
      SSortedTaskFlow[k] = new SetElement[taskLength][];
      int count = 0;
      for (int i = 0; i < numberOfFlows; i++) {
        flow = SFPriority[k][numberOfFlows - i - 1];
        for (Iterator iter = completeList[i].iterator(); iter.hasNext(); ) {
          SSortedTaskFlow[k][count] = new SetElement[2];
          SSortedTaskFlow[k][count][0] = (SetElement) iter.next();
          SSortedTaskFlow[k][count][1] = flow;
          count++;
        }
      }
    }
  }

}