/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package sps;

import java.util.ArrayList;
import expo.*;

/**
 * This class is used to analyze a gene applying the network calculus approach
 * with static priority scheduling. It implements the Analyzer interface with its
 * methods <code>analyze</code>, <code>drawReport</code>
 * &amp; <code>getReport</code>.
 *
 * @author Simon Kuenzli
 * @version 1.0
 */
public class SPSAn implements Analyzer{

  public SPSAn() {
  }

/**
 * Implementation of method drawReport in interface Analyzer. This method
 * shows the results of the analysis in graphical form.
 * @param gene of which report should be drawn.
 * @return String containing error message.
 */
  public String drawReport(Gene gene){
    SPSGene myGene = (SPSGene) gene;
    ArrayList al = new ArrayList();
    SPSImplementation impl = new SPSImplementation();
    String tmp_strg = "";
    impl.initSize();
    for (int i = 0; i < myGene.numberOfScenarios; i++) {
      for (int j = 0; j < myGene.numberOfTasks; j++) {
        impl.STBinding[i][j] = ((SPSSpecification)EXPO.specification).Resources[myGene.STBinding[i][j]];
      }
      for (int j = 0; j < myGene.numberOfFlows; j++) {
        impl.SFPriority[i][j] = ((SPSSpecification)EXPO.specification).Flows[myGene.SFPriority[i][j]];
      }
    }
    for (int i = 0; i < myGene.numberOfResources; i++) {
      impl.RAllocation[i] = myGene.RAllocation[i];
    }
    impl.computeTotalCost();
    impl.computeDelayMemory();

    impl.plotImplementation();

    return "drawReport implemented";
  }

/**
 * This method returns a string containing all results of an analysis of the gene.
 * @param gene contains gene to write a report about
 * @return String which contains report in textual form
 */
  public String getReport(Gene gene){
    SPSGene myGene = (SPSGene) gene;

    ArrayList al = new ArrayList();
    SPSImplementation impl = new SPSImplementation();
    String tmp_strg = "";

    impl.initSize();
    for (int i = 0; i < myGene.numberOfScenarios; i++) {
      for (int j = 0; j < myGene.numberOfTasks; j++) {
        impl.STBinding[i][j] = ((SPSSpecification)EXPO.specification).Resources[myGene.STBinding[i][j]];
      }
      for (int j = 0; j < myGene.numberOfFlows; j++) {
        impl.SFPriority[i][j] = ((SPSSpecification)EXPO.specification).Flows[myGene.SFPriority[i][j]];
      }
    }
    for (int i = 0; i < myGene.numberOfResources; i++) {
      impl.RAllocation[i] = myGene.RAllocation[i];
    }
    impl.computeTotalCost();
    impl.computeDelayMemory();

    return impl.printImplementation();
  }


/**
 * Implementation of method <code>analyze</code> in interface Analyzer. This method
 * makes use of the class sps.Implementation and analyzes the gene given in
 * gene applying the network calculus approach with static priority scheduling.
 * @param gene which has to be analyzed
 * @return ArrayList containing all fitness valuesas double values.
 */
  public ArrayList analyze(Gene gene){

    SPSGene myGene = (SPSGene) gene;

    ArrayList al = new ArrayList();
    SPSImplementation impl = new SPSImplementation();
    String tmp_strg = "";

    impl.initSize();
    for (int i = 0; i < myGene.numberOfScenarios; i++) {
      for (int j = 0; j < myGene.numberOfTasks; j++) {
        impl.STBinding[i][j] = ((SPSSpecification)EXPO.specification).Resources[myGene.STBinding[i][j]];
      }
      for (int j = 0; j < myGene.numberOfFlows; j++) {
        impl.SFPriority[i][j] = ((SPSSpecification)EXPO.specification).Flows[myGene.SFPriority[i][j]];
      }
    }
    for (int i = 0; i < myGene.numberOfResources; i++) {
      impl.RAllocation[i] = myGene.RAllocation[i];
    }
    impl.computeTotalCost();
    impl.computeDelayMemory();

    myGene.totalCost = impl.totalCost;
    al.add(new Double( (impl.totalCost- expo.ParameterSet.minimalCostForResource) / expo.ParameterSet.maximumAchievedTotalCost));
    for (int i = 0; i < myGene.numberOfScenarios; i++) {
      myGene.SScale[i] = impl.SScale[i];
      al.add(new Double((ParameterSet.maximumAchievedScalingFactor -  impl.SScale[i])/
                        ParameterSet.maximumAchievedScalingFactor));
    }

    return al;
  }


}
