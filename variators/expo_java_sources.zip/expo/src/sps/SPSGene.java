/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package sps;

import java.util.*;
import java.io.*;
import curve2.*;
import expo.*;

/**
 * This class represents genes which code allocation, binding and
 * priority information for each implementation. The binding and
 * priority are given for each scenario separately. The constructor
 * can be used for the initial population.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class SPSGene implements Gene, Serializable {

  private boolean hasFitnessValues = false;
  private ArrayList fitnessValues = new ArrayList();

  /**
   * An array that stores the allocation for each resource, i.e.
   * <code>RAllocation[resource.id]</code> yields the number of
   * allocated units for resource with <code>resource.id</code>;
   */
  public int[] RAllocation;

  /**
   * <code>binding[scenario.id][task.id]</code> yields the resource
   * to which the task with <code>task.id</code> is bound in the
   * scenario with <code>scneario.id</code>. The resource is determined
   * by its <code>resource.id</code>.
   */
  public int[][] STBinding;

/**
 * <code>SFPriority[scenario.id][ord]</code> yields the flow with the
 * ord-highest priority in the scenario with <code>scneario.id</code>.
 * The flow is determined by its <code>flow.id</code>.
 */
  public int[][] SFPriority;

/**
 * <code>totalCost</code> is the sum of all allocated resource units.
 */
  public double totalCost;

/**
 * <code>scale[scenario.id]</code> is the maximal possible scaling factor
 * of the arrival curves (for highest performance).
 */
  public double[] SScale;

/**
 * Some public  fields which are used in several methods.
 */
  public int numberOfFlows = ((SPSSpecification)EXPO.specification).Flows.length;
  public int numberOfScenarios = ((SPSSpecification)EXPO.specification).Scenarios.length;
  public int numberOfTasks = ((SPSSpecification)EXPO.specification).Tasks.length;
  public int numberOfResources = ((SPSSpecification)EXPO.specification).Resources.length;


  /**
   * The constructor generates a new random gene based on the
   * data given in <code>Specification</code>.
   */
  public SPSGene() {
    int resourceID, length, taskID, scenID, flowID;
    SetElement[][] TAllocated;
    ArrayList permute = new ArrayList(numberOfFlows);

    // initialize the allocation.
    double tmp_double;
    RAllocation = new int[numberOfResources];
    for (int i = 0; i < numberOfResources; i++) {
      resourceID = ((SPSSpecification)EXPO.specification).Resources[i].id;
      if (EXPO.random.nextDouble() <= ((SPSSpecification)EXPO.specification).probZeroAllocation) {
        RAllocation[resourceID] = 0;
      } else {
        RAllocation[resourceID] = EXPO.random.nextInt(((SPSSpecification)EXPO.specification).RUnit[resourceID]) + 1;
      }
    }

    // repair the allocation and return array of possible resources
    TAllocated = repairAlloc();

    // initialize the binding
    STBinding = new int[numberOfScenarios][numberOfTasks];
    for (int i = 0; i < numberOfTasks; i++) {
      taskID = ((SPSSpecification)EXPO.specification).Tasks[i].id;
      length = TAllocated[taskID].length;
      for (int j = 0; j < numberOfScenarios; j++) {
        scenID = ((SPSSpecification)EXPO.specification).Scenarios[j].id;
        STBinding[scenID][taskID] = TAllocated[taskID][EXPO.random.nextInt(length)].id;
      }
    }

    // initialize the priority
    SFPriority = new int[numberOfScenarios][numberOfFlows];
    for (int i = 0; i < numberOfScenarios; i++) {
      scenID = ((SPSSpecification)EXPO.specification).Scenarios[i].id;
      permute.clear();
      for (int j = 0; j < numberOfFlows; j++) {
        flowID = ((SPSSpecification)EXPO.specification).Flows[j].id;
        permute.add(flowID,new Integer(flowID));
      }
      for (int j = 0; j < numberOfFlows; j++) {
        flowID = ((SPSSpecification)EXPO.specification).Flows[j].id;
        length = permute.size();
        SFPriority[scenID][flowID] = ((Integer) permute.remove(EXPO.random.nextInt(length))).intValue();
      }
    }

    // initialize SScale
    SScale = new double[numberOfScenarios];
  }


public SPSGene(SPSGene parent){

  this.hasFitnessValues = false;
  this.RAllocation = (int[]) parent.RAllocation.clone();
  this.SFPriority = (int[][]) parent.SFPriority.clone();
  this.SScale = (double[]) parent.SScale.clone();
  this.STBinding= (int[][]) parent.STBinding.clone();
  this.totalCost = parent.totalCost;
}

/**
 * The private method <code>repairAlloc</code> repairs the allocation
 * <code>RAllocation</code> such that there exists at least one feasible
 * binding. To this end, it is checked for all tasks, whether there exists
 * a possible resource type in the allocation. If not, from the possible
 * resource types, one is selected randomly.
 *
 * @return <code>SetElement[][]</code> such that <code>return[task.id]</code>
 * yields an array of ALLOCATED resource types that can implement a task
 * with <code>task.id</code>.
 */

  private SetElement[][] repairAlloc() {

    ArrayList tmp_list = new ArrayList();
    SetElement[][] TAllocated = new SetElement[numberOfTasks][];
    int length, resourceID, newRes, taskID;

    for (int i = 0; i < numberOfTasks; i++) {
      taskID = ((SPSSpecification)EXPO.specification).Tasks[i].id;
      length = ((SPSSpecification)EXPO.specification).TResources[i].length;
      if (length == 0) {
        System.err.println("There seems to be some error in the system specification. Some task does not have any associated resource type.");
        System.exit(0);
      }
      tmp_list.clear();
      for (int j = 0; j < length; j++) { //look for feasible resources one after the other
        resourceID = ((SPSSpecification)EXPO.specification).TResources[taskID][j].id;
        if (RAllocation[resourceID] != 0) { // the resource is allocated
          tmp_list.add(((SPSSpecification)EXPO.specification).TResources[taskID][j]);
        }
      }
      if (tmp_list.size() == 0) { // repair
        newRes = EXPO.random.nextInt(length);
        tmp_list.add(((SPSSpecification)EXPO.specification).TResources[taskID][newRes]);
        RAllocation[((SPSSpecification)EXPO.specification).TResources[taskID][newRes].id] = 1;
      }
       Object[] tmp_array = tmp_list.toArray();
      TAllocated[taskID] = new SetElement[tmp_array.length];
      for (int j = 0; j < tmp_array.length; j++) {
        TAllocated[taskID][j] = (SetElement) tmp_array[j];
      }
    }

    return TAllocated;
  }

  public String getFullDescription(){
    String tmp_strg = "";
    tmp_strg += "Binding \r\n";
    for (int i=0; i< numberOfScenarios;i++){
      for (int j=0;j< numberOfTasks;j++){
        tmp_strg += ((SPSSpecification)EXPO.specification).SName[i] + "\t\t" +
            ((SPSSpecification)EXPO.specification).TName[j] +"\t\t" +
            ((SPSSpecification)EXPO.specification).RName[STBinding[i][j]]+"\r\n";
      }
    }
    tmp_strg += "\r\n\r\n";
    tmp_strg += "Priorities \r\n";
    for (int i=0; i< numberOfScenarios;i++){
      for (int j=0;j<numberOfFlows;j++){
        tmp_strg += ((SPSSpecification)EXPO.specification).SName[i] + "\t\t" +
            ((SPSSpecification)EXPO.specification).FName[j]+ "\t\t"+
            SFPriority[i][j]+ " \r\n";
      }
    }
    tmp_strg += "\r\n\r\n";
    tmp_strg += "Allocated Resources \r\n";
    for (int i=0;i<numberOfResources;i++){
      tmp_strg += ((SPSSpecification)EXPO.specification).RName[i] +"\t\t" +
            RAllocation[i]+"\r\n";
    }
    return tmp_strg;
  }


  public Gene[] crossOverGene(Gene geneToCross){

    SPSGene[] newCrossed = new SPSGene[2];
    SPSGene[] oldCrossed = new SPSGene[2];
    oldCrossed[0] = this;
    oldCrossed[1] = (SPSGene) geneToCross;
    int scenarioID, resourceID, taskID, flowID;
    int tmp_int, length;
    SetElement[][] TAllocated;
    ArrayList priority0 = new ArrayList();
    ArrayList priority1 = new ArrayList();

    // copy old genes to new genes; gene pairs are stored
    // in arrays newCrossed and oldCrossed
    for (int k = 0; k < 2; k++) {
      newCrossed[k] = new SPSGene();
      for (int i = 0; i < numberOfResources; i++) {
        newCrossed[k].RAllocation[i] = oldCrossed[k].RAllocation[i];
      }
      for (int i = 0; i < numberOfScenarios; i++) {
        for (int j = 0; j < numberOfFlows; j++) {
          newCrossed[k].SFPriority[i][j] = oldCrossed[k].SFPriority[i][j];
        }
      }
      for (int i = 0; i < numberOfScenarios; i++) {
        for (int j = 0; j < numberOfTasks; j++) {
          newCrossed[k].STBinding[i][j] = oldCrossed[k].STBinding[i][j];
        }
      }
    }

    // determine where to do the crossover; perform the crossover and
    // eventually repair;
    scenarioID = EXPO.random.nextInt(numberOfScenarios);
    if (EXPO.random.nextDouble() < ((SPSSpecification)EXPO.specification).probCrossoverAllocation) {
      // crossover is in the allocation
      // exchange part of the allocation vector
      resourceID = EXPO.random.nextInt(numberOfResources);
      if (EXPO.random.nextBoolean()) { // exchange first or last part of allocation
        for (int i = 0; i <= resourceID; i++) {
          tmp_int = newCrossed[0].RAllocation[i];
          newCrossed[0].RAllocation[i] = newCrossed[1].RAllocation[i];
          newCrossed[1].RAllocation[i] = tmp_int;
        }
      } else {
        for (int i = resourceID; i < numberOfResources; i++) {
          tmp_int = newCrossed[0].RAllocation[i];
          newCrossed[0].RAllocation[i] = newCrossed[1].RAllocation[i];
          newCrossed[1].RAllocation[i] = tmp_int;
        }
      }
      // repair the allocation (one may do better here as only a
      // random repair is used, one may use the allocation of the
      // other gene as a prototype)
      for (int k = 0; k < 2; k++) {
        // repair the allocation and return array of possible resources
        TAllocated = newCrossed[k].repairAlloc();
        // repair the binding
        for (int i = 0; i < numberOfTasks; i++) {
          length = TAllocated[i].length;
          for (int j = 0; j < numberOfScenarios; j++) {
            if (newCrossed[k].RAllocation[newCrossed[k].STBinding[j][i]] == 0) {
              // repair
              // here, eventually change allocation instead of binding!
              newCrossed[k].RAllocation[newCrossed[k].STBinding[j][i]] = 1;
              // newCrossed[k].STBinding[j][i] = TAllocated[i][random.nextInt(length)].id;
            }
          }
        }
      }
    } else if (EXPO.random.nextDouble() < ((SPSSpecification)EXPO.specification).probCrossoverBinding) {
      // crossover is in scenario scenarioID of Binding
      // exchange part of the binding vector
      taskID = EXPO.random.nextInt(numberOfTasks);
      if (EXPO.random.nextBoolean()) { // exchange first or last part of binding
        for (int i = 0; i <= taskID; i++) {
          tmp_int = newCrossed[0].STBinding[scenarioID][i];
          newCrossed[0].STBinding[scenarioID][i] = newCrossed[1].STBinding[scenarioID][i];
          newCrossed[1].STBinding[scenarioID][i] = tmp_int;
        }
      } else {
        for (int i = taskID; i < numberOfTasks; i++) {
          tmp_int = newCrossed[0].STBinding[scenarioID][i];
          newCrossed[0].STBinding[scenarioID][i] = newCrossed[1].STBinding[scenarioID][i];
          newCrossed[1].STBinding[scenarioID][i] = tmp_int;
        }
      }
      // repair the binding (one may do better here as only a
      // random repair is used, one may use the binding of the
      // other gene as a prototype)
      for (int k = 0; k < 2; k++) {
        // return array of possible resources
        TAllocated = newCrossed[k].repairAlloc();
        // repair the binding
        for (int i = 0; i < numberOfTasks; i++) {
          length = TAllocated[i].length;
          if (newCrossed[k].RAllocation[newCrossed[k].STBinding[scenarioID][i]] == 0) {
            // repair
            newCrossed[k].STBinding[scenarioID][i] = TAllocated[i][EXPO.random.nextInt(length)].id;
          }
        }
      }
    } else {
      // crossover is in scenario scenarioID of Priority
      // exchange part of the priority vector
      // determine crossover point
      flowID = EXPO.random.nextInt(numberOfFlows);
      // determine lists which store the old priority vectors
      for (int i = 0; i < numberOfFlows; i ++ ) {
        priority0.add(i, new Integer(newCrossed[0].SFPriority[scenarioID][i]));
        priority1.add(i, new Integer(newCrossed[1].SFPriority[scenarioID][i]));
      }
      if (EXPO.random.nextBoolean()) { // exchange first part of priority
        for (int i = 0; i <= flowID; i++) {
          tmp_int = newCrossed[0].SFPriority[scenarioID][i];
          newCrossed[0].SFPriority[scenarioID][i] = newCrossed[1].SFPriority[scenarioID][i];
          newCrossed[1].SFPriority[scenarioID][i] = tmp_int;
          // remove already used parts from the old priority vectors
          priority0.remove(new Integer(newCrossed[0].SFPriority[scenarioID][i]));
          priority1.remove(new Integer(newCrossed[1].SFPriority[scenarioID][i]));
        }
        for (int i = flowID + 1; i < numberOfFlows; i++) {
          // fill remaining parts of priority vector with old parts
          newCrossed[0].SFPriority[scenarioID][i] = ((Integer) priority0.remove(0)).intValue();
          newCrossed[1].SFPriority[scenarioID][i] = ((Integer) priority1.remove(0)).intValue();
        }
      } else {  // exchange last part of priority
        for (int i = flowID; i < numberOfFlows; i++) {
          tmp_int = newCrossed[0].SFPriority[scenarioID][i];
          newCrossed[0].SFPriority[scenarioID][i] = newCrossed[1].SFPriority[scenarioID][i];
          newCrossed[1].SFPriority[scenarioID][i] = tmp_int;
          // remove already used parts from the old priority vectors
          priority0.remove(new Integer(newCrossed[0].SFPriority[scenarioID][i]));
          priority1.remove(new Integer(newCrossed[1].SFPriority[scenarioID][i]));
        }
        for (int i = 0; i < flowID; i++) {
          // fill remaining parts of priority vector with old parts
          newCrossed[0].SFPriority[scenarioID][i] = ((Integer) priority0.remove(0)).intValue();
          newCrossed[1].SFPriority[scenarioID][i] = ((Integer) priority1.remove(0)).intValue();
        }
      }
    }

    return newCrossed;
  }


  public Gene mutateGene(){
    SPSGene newGene = new SPSGene();
    //SPSGene oldGene = (SPSGene) this.clone();
    int scenarioID, resourceID, taskID, flowID1, flowID2;
    int length, tmp_int, newID;
    SetElement[][] TAllocated;

    // copy oldGene to newGene
    for (int i = 0; i < numberOfResources; i++) {
      newGene.RAllocation[i] = this.RAllocation[i];
    }
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfFlows; j++) {
        newGene.SFPriority[i][j] = this.SFPriority[i][j];
      }
    }
    for (int i = 0; i < numberOfScenarios; i++) {
      for (int j = 0; j < numberOfTasks; j++) {
        newGene.STBinding[i][j] = this.STBinding[i][j];
      }
    }

    // determine where to do the mutation; perform the mutation and
    // eventually repair;
    scenarioID = EXPO.random.nextInt(numberOfScenarios);
    if (EXPO.random.nextDouble() < ((SPSSpecification)EXPO.specification).probMutationAllocation) {
      // mutation is in the allocation
      // perform the mutation and repair the allocation
      resourceID = EXPO.random.nextInt(numberOfResources);
      if (EXPO.random.nextDouble() <= ((SPSSpecification)EXPO.specification).probZeroAllocation) {
        newGene.RAllocation[resourceID] = 0;
      } else {
        newGene.RAllocation[resourceID] = EXPO.random.nextInt(((SPSSpecification)EXPO.specification).RUnit[resourceID]) + 1;
      }
      // repair the allocation and return array of possible resources
      TAllocated = newGene.repairAlloc();
      // repair the binding
      for (int i = 0; i < numberOfTasks; i++) {
        length = TAllocated[i].length;
        for (int j = 0; j < numberOfScenarios; j++) {
          if (newGene.RAllocation[newGene.STBinding[j][i]] == 0) {
            // repair
            newGene.STBinding[j][i] = TAllocated[i][EXPO.random.nextInt(length)].id;
          }
        }
      }
    } else if (EXPO.random.nextDouble() < ((SPSSpecification)EXPO.specification).probMutationBinding) {
      // mutation is in scenario scenarioID of Binding
      // determine task whose binding will be mutated
      taskID = EXPO.random.nextInt(numberOfTasks);
      // mutate the binding
      length = ((SPSSpecification)EXPO.specification).TResources[taskID].length;
      newID = ((SPSSpecification)EXPO.specification).TResources[taskID][EXPO.random.nextInt(length)].id;
      newGene.STBinding[scenarioID][taskID] = newID;
      // repair allocation if necessary
      // here, one may also repair the binding to a feasible one ....
      if (newGene.RAllocation[newID] == 0) {
        newGene.RAllocation[newID] = 1;
      }
    } else {
      // mutation is in scenario scenarioID of Priority
      // determine flows whose priorities will be exchanged
      flowID1 = EXPO.random.nextInt(numberOfFlows);
      flowID2 = EXPO.random.nextInt(numberOfFlows);
      tmp_int = newGene.SFPriority[scenarioID][flowID1];
      newGene.SFPriority[scenarioID][flowID1]= newGene.SFPriority[scenarioID][flowID2];
      newGene.SFPriority[scenarioID][flowID2]= tmp_int;
    }
    return newGene;
   }


  public ArrayList getFitnessValues(){
    if (hasFitnessValues){
      return fitnessValues;
    }
    else{
      try{
        Analyzer an = (Analyzer) Class.forName(ParameterSet.analyzer).newInstance();
        fitnessValues = an.analyze(this);
        hasFitnessValues = true;
        return fitnessValues;
      }
      catch (Exception e){
        e.printStackTrace();
        System.err.println("SPSGene: There is a problem finding class "+ParameterSet.analyzer);
      }
    }
    return fitnessValues;
  }



  public String getFitnessString(){

    String tmp_strg = "";
    if (!hasFitnessValues){
      getFitnessValues();
    }
    for (Iterator iter = fitnessValues.iterator();iter.hasNext();){
      tmp_strg += iter.next().toString() + " ";
    }
    return tmp_strg;
  }

  public Object clone(){
    return new SPSGene(this);
  }


  public String getShortDescription(){
    //maybe even with performance values.

    String tmp_strg = "";
   tmp_strg += "\n Allocated Resources \r\n\n";
   for (int i=0;i<numberOfResources;i++){
     if (RAllocation[i] >0){
       tmp_strg += ( (SPSSpecification) EXPO.specification).RName[i] + "  " +
           RAllocation[i] + "\r\n";
     }
   }

    return tmp_strg;
  }


}
