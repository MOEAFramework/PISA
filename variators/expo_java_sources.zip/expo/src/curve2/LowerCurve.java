/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package curve2;


/**
 *
 * The class extends <code>Curve</code> for lower service or
 * arrival curves.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class LowerCurve extends Curve {

/**
 * Creates a new lower upper curve.
 * @param q Offset.
 * @param r Initial slope.
 * @param s Final slope.
 */
  public LowerCurve(double q, double r, double s) {
    super(q, r, s);
  }

/**
 * Creates a new piecewise linear curve.
 * @param curve Curve to be cloned.
 */
  public LowerCurve(Curve curve) {
    super(curve);
  }

/**
 * The method is called if a curve is changed. It prints an error
 * message if the curve is not feasible.
 */
  public void alert() {
    if (q > 0 || r < 0 || s < 0 || r > s || (q == 0 && r != s) || (r == s && q != 0)) {
      System.err.println("Lower curve has got an inconsistent update: q = " + q + ", r = " + r + ", s = " + s);
    }
  }

/**
 * This method returns a new curve which is a multiple of the current instance.
 */
  public LowerCurve multiply(double value) {
    LowerCurve newCurve = new LowerCurve(this.q * value, this.r * value, this.s * value);
    return newCurve;
  }

  /**
   * overridden <code>toString</code> method. It prints out the  lower curve
   * in the form "q= -1 , r= 2, s= 6"
   * @return String containing the string representation of LowerCurve.
   */
  public String toString(){
      return " q= "+this.q+",  r= "+this.r+",  s="+this.s;
    }

}