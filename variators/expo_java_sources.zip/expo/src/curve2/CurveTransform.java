/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package curve2;



/**
 * The class provides several operations on curves such as
 * transformations by resource units, delay, backlog and max-plus.
 * The class should not be instantiated, it has only class methods.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public class CurveTransform {

/**
 * The class method performs a max-plus convolution on lower
 * curves. It does not work correctly for upper curves. It is called
 * <code>lowerArrival</code> as the result is also the lower arrival
 * curve of a processed event stream, i.e. after processing the
 * lower arrival curve <code>alpha</code>
 * with a lower service curve <code>beta</code>.
 * @param alpha Lower arrival curve of input.
 * @param beta Lower service curve of the resource.
 * @return A new lower curve that represents the max-plus convolution of
 * <code>alpha</code> and <code>beta</code>, or equivalently, the lower
 * arrival curve of the processed event stream.
 */
  public static LowerCurve lowerArrival(LowerCurve alpha, LowerCurve beta) {
    double q;
    double r;
    double s;

    r = Math.min(alpha.getR(), beta.getR());
    s = Math.min(alpha.getS(), beta.getS());
    if (alpha.getS() <= beta.getR()) {
      q = alpha.getQ();
    } else if (beta.getS() <= alpha.getR()) {
      q = beta.getQ();
    } else {
      q = alpha.getR()*alpha.getP() + beta.getR()*beta.getP() - s * (alpha.getP() + beta.getP());
    }
    return new LowerCurve(q,r,s);
  }

/**
 * The class method determines the maximal horizontal distance
 * between an upper curve <code>alpha</code> and a lower curve <code>beta</code>.
 * This value equals the maximal delay.
 * @param alpha Upper arrival curve.
 * @param beta Lower service curve.
 * @return Maximal horizontal distance of curves
 *    <code>alpha</code> and <code>beta</code>.
 */
  public static double maxDelay(UpperCurve alpha, LowerCurve beta) {
    double d;

    if (beta.getS() < alpha.getS()) {
      d = Double.POSITIVE_INFINITY;
    } else if (beta.getR() >= alpha.getR()) {
      d = 0.0;
    } else if (beta.getP()*beta.getR() <= alpha.getP()*alpha.getR()) {
      d = Math.max(beta.getP() * (1 - beta.getR()/alpha.getR()), alpha.getP() * (alpha.getR()/beta.getS() - 1) - beta.getQ()/beta.getS());
    } else if (alpha.getS() > 0){
      d = Math.max(alpha.getP() * (alpha.getR()/beta.getR() - 1), beta.getP() * (1 - beta.getR()/alpha.getS()) + alpha.getQ()/alpha.getS());
    } else {
      d = alpha.getP() * (alpha.getR()/beta.getR() - 1);
    }

    return d;
  }

/**
 * The class method determines the maximal vertical distance
 * between an upper curve <code>alpha</code> and a lower curve <code>beta</code>.
 * This value equals the maximal backlog.
 * @param alpha Upper arrival curve.
 * @param beta Lower service curve.
 * @return Maximal vertical distance of curves
 *    <code>alpha</code> and <code>beta</code>.
 */
  public static double maxBacklog(UpperCurve alpha, LowerCurve beta) {
    double d;

    if (beta.getS() < alpha.getS()) {
      d = Double.POSITIVE_INFINITY;
    } else if (beta.getR() >= alpha.getR()) {
      d = 0.0;
    } else if (beta.getP() <= alpha.getP()) {
      d = Math.max(alpha.getP() * (alpha.getR() - beta.getS()) - beta.getQ(), beta.getP() * (alpha.getR() - beta.getR()));
    } else {
      d = Math.max(beta.getP() * (alpha.getS() - beta.getR()) + alpha.getQ(), alpha.getP() * (alpha.getR() - beta.getR()));
    }

    return d;
  }

/**
 * The class method determines the remaining lower service curve
 * after processing an upper arrival curve <code>alpha</code>
 * with a lower service curve <code>beta</code>.
 * @param alpha Upper arrival curve.
 * @param beta Lower service curve.
 * @return Resulting lower service curve after processing
 * <code>alpha</code> with <code>beta</code>.
 */
  public static LowerCurve lowerService(UpperCurve alpha, LowerCurve beta) {
    double q;
    double r;
    double s;

    if (alpha.getS() < beta.getS()) {
      q = beta.getQ() - alpha.getQ();
    } else {
      q = 0.0;
    }
    if (alpha.getR() < beta.getR()) {
      r = beta.getR() - alpha.getR();
    } else {
      r = 0.0;
    }
    s = Math.max(0.0, beta.getS() - alpha.getS());

    return new LowerCurve(q,r,s);
  }

/**
 * The class method determines the remaining upper service curve
 * after processing a lower arrival curve <code>alpha</code>
 * with a ln upper service curve <code>beta</code>.
 * @param alpha Lower arrival curve.
 * @param beta Upper service curve.
 * @return Resulting upper service curve after processing
 * <code>alpha</code> with <code>beta</code>.
 */
  public static UpperCurve upperService(LowerCurve alpha, UpperCurve beta) {
    double q;
    double r;
    double s;

    if (alpha.getS() < beta.getS()) {
      q = beta.getQ() - alpha.getQ();
    } else {
      q = maxBacklog(beta,alpha);
    }
    if (alpha.getR() < beta.getR()) {
      r = beta.getR() - alpha.getR();
    } else {
      r = 0.0;
    }
    s = Math.max(0.0, beta.getS() - alpha.getS());

    return new UpperCurve(q,r,s);
  }

/**
 * The class method determines the upper arrival curve of a processed
 * event stream. The input stream is described by the upper arrival curve
 * <code>alpha</code>, the resource is described by the lower service
 * curve <code>betaL</code> and upper service curve <code>betaU</code>.
 * @param alpha Upper arrival curve.
 * @param betaU Upper service curve.
 * @param betaL Lower service curve.
 * @return Resulting upper arrival curve after processing
 * <code>alpha</code> with <code>betaU</code> and <code>betaL</code>.
 */
  public static UpperCurve upperArrival(UpperCurve alpha, LowerCurve betaL, UpperCurve betaU) {
    double q, qP;
    double r;
    double s;

    if (alpha.getS() <= betaL.getR()) {
      qP = alpha.getQ();
    } else {
      qP = alpha.getQ() + betaL.getP()*(alpha.getS() - betaL.getR());
    }
    if (alpha.getS() > betaL.getS()) {
      q = betaU.getQ();
    } else if (alpha.getS() == betaU.getS()){
      q = Math.min(qP, betaU.getQ());
    } else {
      q = qP;
    }
    if (alpha.getR() <= betaL.getR()) {
      r = alpha.getR();
    } else {
      r = betaU.getR();
    }
    if (alpha.getS() <= betaL.getS()) {
      s = alpha.getS();
    } else {
      s = betaU.getS();
    }

    return new UpperCurve(q,r,s);
  }
}