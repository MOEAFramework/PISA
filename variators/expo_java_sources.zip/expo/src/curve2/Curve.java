/*
 Copyright (c) 2002 Computer Engineering and Communication Networks Lab (TIK)
 Swiss Federal Institute of Technology (ETH) Zurich, Switzerland

 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE TIK OR THE ETH ZURICH BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE TIK OR THE ETH ZURICH HAVE BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE TIK AND THE ETH ZURICH SPECIFICALLY DISCLAIM ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND TIK AND THE ETH ZURICH
 HAVE NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 Title: EXPO
 Description: Design Space Exploration for Packet Processors
 Copyright: Copyright (c) 2001
 Company: ETH Zurich

 */
package curve2;

/**
 * The class provides the representation of piecewise linear
 * curves.
 *
 * @author Lothar Thiele
 * @version 1.0
 */
public abstract class Curve {

/**
 * Holds the offset.
 */
  public double q;

/**
 * Holds the initial slope.
 */
  public double r;

/**
 * Holds the final slope.
 */
  public double s;

/**
 * Holds the cross point.
 */
  public double p = 0;

/**
 * Creates a new piecewise linear curve.
 * @param q Offset.
 * @param r Initial slope.
 * @param s Final Slope.
 */
  public Curve(double q, double r, double s) {
    this.q = q; this.r = r; this.s = s;
    if (r - s != 0) p = q/(r -s);
    alert();
  }

/**
 * Creates a new piecewise linear curve.
 * @param curve Curve to be cloned.
 */
  public Curve(Curve curve) {
    this.q = curve.getQ(); this.r = curve.getR(); this.s = curve.getS();
    if (r - s != 0) p = q/(r -s);
    alert();
  }

/**
 * Sets the instance variables describing the curve and
 * checks the feasibility using method <code>alert()</code>.
 * @param q Offset.
 * @param r Initial slope.
 * @param s Final Slope.
 */
  public void set(double q, double r, double s) {
    this.q = q; this.r = r; this.s = s;
    if (r - s != 0) p = q/(r -s);
    alert();
  }
/**
 * Returns offset.
 * @return Offset.
 */
  public double getQ() {
    return this.q;
  }

/**
 * Returns initial slope.
 * @return Initial slope.
 */
  public double getR() {
    return this.r;
  }

/**
 * Returns final slope.
 * @return Final slope.
 */
  public double getS() {
    return this.s;
  }

/**
 * Returns cross point.
 * @return Cross point.
 */
  public double getP() {
    return this.p;
  }

/**
 * Abstract method for checking the feasibility.
 */
  abstract void alert();
}