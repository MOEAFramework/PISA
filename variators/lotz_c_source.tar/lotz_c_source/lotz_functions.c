/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  LOTZ - Leading Ones Trailing Zeros 

  Example implementation in C for the variation side.

  Implements most functions.
  
  file: lotz_functions.c
  author: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>

#include "lotz.h"


/* common parameters */

int alpha;  /* number of individuals in initial population */
int mu;     /* number of individuals selected as parents */
int lambda; /* number of offspring individuals */
int dim;    /* number of objectives */


/* local parameters from paramfile*/

int seed;   /* seed for random number generator */
int length; /* length of the binary string */
int maxgen; /* maximum number of generations (stop criterion) */
char outfile[FILE_NAME_LENGTH]; /* output file for last population */

/* other variables */

char cfgfile[FILE_NAME_LENGTH];  /* 'cfg' file (common parameters) */
char inifile[FILE_NAME_LENGTH];  /* 'ini' file (initial population) */
char selfile[FILE_NAME_LENGTH];  /* 'sel' file (parents) */
char arcfile[FILE_NAME_LENGTH];  /* 'arc' file (archive) */
char varfile[FILE_NAME_LENGTH];  /* 'var' file (offspring) */

int gen;            /* current generation */
pop *pp;            /* population storing all individuals */
int old_ind;        /* index of parent individual */
int new_ind;        /* index of offspring individual */
int first_free = 0; /* index of the first free space in pp->ind_array */


/*-----------------------| initialization |------------------------------*/

void initialize(char *paramfile, char *filenamebase)
/* Performs the necessary initialization to start in state 0. */
{
     FILE *fp;
     int result, i, index;
     char str[CFG_ENTRY_LENGTH];
     
     /* reading parameter file with parameters for selection */
     fp = fopen(paramfile, "r");
     assert(fp != NULL);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "seed") == 0);
     fscanf(fp, "%d", &seed);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "length") == 0);
     fscanf(fp, "%d", &length);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "maxgen") == 0);
     fscanf(fp, "%d", &maxgen);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "outputfile") == 0);
     result = fscanf(fp, "%s", outfile); /* fscanf() returns EOF if
                                             reading failed. */

     assert(result != EOF); /* no EOF, outfile correctly read */
     fclose(fp);
     
     srand(seed); /* seeding random number generator */
     
     sprintf(varfile, "%svar", filenamebase);
     sprintf(selfile, "%ssel", filenamebase);
     sprintf(cfgfile, "%scfg", filenamebase);
     sprintf(inifile, "%sini", filenamebase);
     sprintf(arcfile, "%sarc", filenamebase);

     /* reading cfg file with common configurations for both parts */
     fp = fopen(cfgfile, "r");
     assert(fp != NULL);
     
 
     fscanf(fp, "%s", str);
     assert(strcmp(str, "alpha") == 0);
     fscanf(fp, "%d", &alpha);
     assert(alpha > 0);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "mu") == 0);
     fscanf(fp, "%d", &mu);
     assert(mu > 0);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "lambda") == 0);
     fscanf(fp, "%d", &lambda);
     assert(lambda > 0);

     result = fscanf(fp, "%s", str);
     assert(strcmp(str, "dim") == 0);
     result = fscanf(fp, "%d", &dim);
     assert(result != EOF); /* no EOF, dim correctly read */
     assert(dim > 0);
     
     fclose(fp);
     
     /* check ability to handle 'alpha', 'mu', 'lambda' and 'dim' */
     if (alpha != 1)
          PISA_ERROR("Lotz can't handle alpha != 1.");
     if (mu != 1)
          PISA_ERROR("Lotz can't handle mu != 1.");
     if (lambda != 1)
          PISA_ERROR("Lotz can't handle lambda != 1.");
     if (dim != 2)
          PISA_ERROR("Lotz can't handle dim != 2.");
     
     /* create population */
     pp = create_pop(MAX_ARCHIVE, dim);
     
     /* create first individual */
     index = 0;
     pp->ind_array[index] = create_ind(length);
     first_free++;
     
     for (i = 0; i < length; i++)
          pp->ind_array[index]->bit_string[i] = irand(2);

     /* evaluating two objective functions */
     pp->ind_array[index]->lo = eval_lo(pp->ind_array[index]);
     pp->ind_array[index]->tz = eval_tz(pp->ind_array[index]);

     /* writing a var file so we don't get stuck in state 2 when
        checking if the var file was correctly read and therefore
        file contains only a "0" */
     fp = fopen(varfile, "w");
     assert(fp != NULL);
     fprintf(fp, "0");
     fclose(fp);
}

/*-------------------| memory allocation functions |---------------------*/

void* chk_malloc(size_t size)
/* Wrapper function for malloc(). Checks for failed allocations. */
{
     void *result = malloc(size);
     if(result == NULL)
          PISA_ERROR("Lotz: Out of memory.");
     return result;
}


pop* create_pop(int size, int dim)
/* Allocate memory for a population. */
{
     int i;
     pop *pp;

     assert(size >= 0);
     
     pp = (pop*) chk_malloc(sizeof(pop));
     pp->ind_array = (ind**) chk_malloc(size * sizeof(ind*));

     /* initializations */
     for (i = 0; i < size; i++)
          pp->ind_array[i] = NULL;

     pp->size = size;
     pp->dim = dim;
     
     return (pp);
}


ind* create_ind(int length)
/* Allocates memory for one individual. */
{
     ind *p_ind;

     p_ind = (ind*) chk_malloc(sizeof(ind));
     p_ind->bit_string = (int*) chk_malloc(length * sizeof(int));
     p_ind->length = length;

     /* initialize */
     p_ind->lo = -1;
     p_ind->tz = -1;

     return (p_ind);
}


void free_memory()
/* Frees all memory allocated in optimization run. */
{
     free_pop(pp);
     pp = NULL;
}


void free_pop(pop *pp)
/* Frees memory for given population. */
{
     int i;

     assert(pp != NULL);

     if (NULL != pp)
     {
        for (i = 0; i < pp->size; i++)
        {
           if (pp->ind_array[i] != NULL)
           {
              free_ind(pp->ind_array[i]);
              pp->ind_array[i] = NULL;
           }
        }
        free(pp->ind_array);
        free(pp);
     }
}


void free_ind(ind *p_ind)
/* Frees memory for given individual. */
{
   if (NULL != p_ind)
   {
      free(p_ind->bit_string);
      free(p_ind);
   }
}

/*----------------| functions implementing the variation |---------------*/

void variate()
/* Performs variation. */
{
     mutate(pp, old_ind, first_free);
     new_ind = first_free;
     first_free++;
     
     gen++;
}

void mutate(pop *pp, int old_index, int new_index)
/* Generates a mutated version of an ind. */
{
     assert(0 <= old_index <= pp->size - 1);
     assert(0 <= new_index <= pp->size - 1);
     
     pp->ind_array[new_index] = bit_mutate(pp->ind_array[old_index]);

     pp->ind_array[new_index]->lo = eval_lo(pp->ind_array[new_index]);
     pp->ind_array[new_index]->tz = eval_tz(pp->ind_array[new_index]);
}


ind* bit_mutate(ind *p_ind)
/* Toggles one bit. */
{
     ind *p_new_ind;
     int mut_bit;
     
     p_new_ind = copy_ind(p_ind); /* creates the ind */
     mut_bit = irand(p_ind->length); /* irand returns maximally arg-1 */
     p_new_ind->bit_string[mut_bit] = !(p_ind->bit_string[mut_bit]);

     return (p_new_ind);
}


ind* copy_ind(ind *p_ind)
/* Copies an individual. */
{
     int i;
     ind *p_new_ind;

     assert(p_ind != NULL);
     
     p_new_ind = create_ind(p_ind->length); /* length is set in create */
     p_new_ind->lo = p_ind->lo;
     p_new_ind->tz = p_ind->tz;
     for(i = 0; i < p_new_ind->length; i++)
          p_new_ind->bit_string[i] = p_ind->bit_string[i];
     return (p_new_ind);
}


int is_finished()
/* Determines if termination criterion is met.*/
{
     return (gen >= maxgen);
}


int irand(int range)
/* Generate a random integer. */
{
     int j;
     j=(int) ((double) range * (double) rand() / (RAND_MAX + 1.0));
     return (j);
}



int eval_lo(ind *p_ind)
/* Determines the objective value based on Leading Ones.
   In order to maximize Leading Ones this function is minimized.
   PISA always minimizes. */
{
     int i = 0;
     
     assert(p_ind != NULL);

     while (i < p_ind->length && p_ind->bit_string[i] == 1)
          i++;     
     return (length - i);
}


int eval_tz(ind *p_ind)
/* Determines the objective value based on Trailing Zeros.
   In order to maximize Trailing Zeros this function is minimized.
   PISA always minimizes. */
{
     int tz;
     int i = p_ind->length-1;

     assert(p_ind != NULL);
     
     while (i > -1 && p_ind->bit_string[i] == 0)
          i--;
     tz = p_ind->length - i - 1;
     return (length - tz);
}


/*--------------------| data exchange functions |------------------------*/

void write_ini()
{
     write_ind(inifile, pp, 0);
}

void write_var()
{
     write_ind(varfile, pp, new_ind);
}

int read_sel()
{
     return (read_ind(selfile, &old_ind));
}

int check_var()
{
     return (check_file(varfile));
}

void clean_arc()
{
     clean_file(arcfile);
}


/*-------------------------| output functions |--------------------------*/

void write_output()
{
     write_output_file(outfile, arcfile, pp);
}
