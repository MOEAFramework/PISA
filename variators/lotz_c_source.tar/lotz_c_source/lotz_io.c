/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  LOTZ - Leading Ones Trailing Zeros 

  Example implementation in C for the variation side.

  Implements data exchange through files.
  
  file: lotz_io.c
  author: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>

#include "lotz.h"


void write_ind(char* filename, pop *pp, int index)
/* Write one individual ('pp->ind_array[index]') to file. */
{
     FILE *fp;

     assert(0 <= index <= pp->size);
     assert(pp->ind_array[index] != NULL);
     
     fp = fopen(filename, "w");
     assert(fp != NULL);

     fprintf(fp, "%d\n", 3);
     fprintf(fp, "%d ", index); /* prints also a space */
     fprintf(fp, "%E ", (double) pp->ind_array[index]->lo);
     fprintf(fp, "%E\n", (double) pp->ind_array[index]->tz);
     fprintf(fp, "END");
     fclose(fp);
}


int read_ind(char *filename, int *p_index)
/* Reads one individual from file and saves index in 'p_index'. */
{
     int size, result;
     FILE *fp;
     char tag[4];
     

     fp = fopen(filename, "r");
     assert(fp != NULL);
     
     fscanf(fp, "%d", &size);
     assert(size == 1);
     result = fscanf(fp, "%d", p_index);
     
     if (result == EOF) /* fscanf() returns EOF if reading failed */
     {
          fclose(fp);
          return (1);
     }
     else /* "END" expected */
     {
          fscanf(fp, "%s", tag);
          if (strcmp(tag, "END") != 0) /* no "END" here */
          {
               fclose(fp);
               return (1);
          }
          else /* "END" ok */
          {
               fclose(fp);

               /* delete file content if reading successful */
               fp = fopen(filename, "w");
               assert(fp != NULL);
               fprintf(fp, "0");
               fclose(fp);
               
               return (0); /* signalling that reading successful */
          }
     }
}


void write_output_file(char *out_filename, char *arc_filename, pop *pp)
/* Writes the individuals (index, objective values and bit string) of
   all individuals in the 'arc_filename' file to 'out_filename' */
{
     int i, j, arc_size, index;
     FILE *fp_out, *fp_arc;

     fp_arc = fopen(arc_filename, "r");
     assert(fp_arc != NULL);

     fscanf(fp_arc, "%d", &arc_size);

     fp_out = fopen(out_filename, "w");
     assert(fp_out != NULL);

     if(0 == arc_size)
     {
        fprintf(fp_out, "No individual information could be written because the arc file has already been emptied.");
     }
     else
     {
        for (i = 0; i < arc_size; i++)
        {
           fscanf(fp_arc, "%d", &index); /* 'arc_filename' contains only
                                            indices */
           fprintf(fp_out, "%d ", index); /* write index */
           fprintf(fp_out, "%.1f ", pp->ind_array[index]->length -
                   pp->ind_array[index]->lo); /* number of leading ones */
           fprintf(fp_out, "%.1f ",  pp->ind_array[index]->length -
                   pp->ind_array[index]->tz); /* number of trailing zeros */
           for (j = 0; j < pp->ind_array[index]->length; j++)
           {
              fprintf(fp_out, "%d", pp->ind_array[index]->bit_string[j]);
           }
           fprintf(fp_out, "\n");
        }
     }
     
     fclose(fp_arc);
     fclose(fp_out);
}


int check_file(char *filename)
/* Checks whether 'filename' has been read by the selector. */
{
     int control_element = 1;

     FILE *fp;

     fp = fopen(filename, "r");
     assert(fp != NULL);
     fscanf(fp, "%d", &control_element);

     if(0 == control_element)
          return (0); /* file is ready for writing */
     else
          return (1); /* file is not ready for writing */
     fclose(fp);
}

void clean_file(char *filename)
/* Deletes the content and writes '0' in a given file. */
{
     FILE *fp;

     fp = fopen(filename, "w");
     assert(fp != NULL);
     fprintf(fp, "0");
     fclose(fp);
}
