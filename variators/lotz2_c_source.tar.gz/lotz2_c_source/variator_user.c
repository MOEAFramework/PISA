/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
 
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
 
  ========================================================================
  PISALIB 
  
  Functions the user must implement
  
  C file.
  
  file: variator_user.c
  author: Fabian Landis, flandis@ee.ethz.ch

  revision by: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$

  ========================================================================
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>

#include "variator.h"
#include "variator_user.h"


/*--------------------| global variable definitions |-------------------*/

/*==== declared in variator_user.h used in other files as well ====*/

char *log_file = "lotz2_error.log"; /**** changed for LOTZ2 */

char paramfile[FILE_NAME_LENGTH]; /* file with local parameters */


/*==== only used in this file ====*/

/* local parameters from paramfile*/
unsigned int seed;   /* seed for random number generator */

int length; /* length of the binary string */

int maxgen; /* maximum number of generations (stop criterion) */

int gen;

char outfile[FILE_NAME_LENGTH]; /* output file for last population */

int mutation_type; /* 0 = no mutation
		      1 = one bit mutation
		      2 = independent bit mutation */

int recombination_type; /* 0 = no recombination
			   1 = one point crossover
			   2 = uniform crossover */

double mutat_prob; /* probability that individual is mutated */

double recom_prob;  /* probability that 2 individual are recombined */

double bit_turn_prob;
/* probability that bit is turned when mutation occurs, only used for
 * independent bit mutation. */


/*-------------------------| individual |-------------------------------*/

void free_individual(individual *ind) 
/* Frees the memory for one indiviual.

   post: memory for ind is freed
*/
{
     /**********| added for LOTZ2 |*****************/

     if (ind == NULL)
          return;

     free(ind->bit_string);

     /**********| addition for LOTZ2 end |**********/

     free(ind);
}

double get_objective_value(int identity, int i)
/* Gets objective value of an individual.

   pre: 0 <= i <= dimension - 1 (dimension is the number of objectives)

   post: Return value == the objective value number 'i' in individual '*ind'.
         If no individual with ID 'identity' return value == -1. 
*/   
{
     /**********| added for LOTZ2 |*****************/
     individual *temp_ind;
     /**********| addition for LOTZ2 end |**********/

     double objective_value = -1.0;
     
     assert(0 <= i && i < dimension); /* asserting the pre-condition */
     
     /**********| added for LOTZ2 |*****************/
     if(i < 0 || i > (dimension - 1))
          return (-1);
     
     temp_ind = get_individual(identity);
     if(temp_ind == NULL)
          return (-1);
     
     if(i == 0)
          objective_value = temp_ind->lo;
     else
          objective_value = temp_ind->tz;
     
     /**********| addition for LOTZ2 end |**********/
     
     return (objective_value);
}

/*-------------------------| statemachine functions |-------------------*/

int state0() 
/* Do what needs to be done in state 0.

   pre: The global variable 'paramfile' contains the name of the
        parameter file specified on the commandline.
        The global variable 'alpha' contains the number of indiviuals
        you need to generate for the initial population.
                
   post: Optionally read parameter specific for the module.
         Optionally do some initialization.
         Initial population created.
         Information about initial population written to the ini file
         using write_ini().
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     /**********| added for LOTZ2 |*****************/
     int i;
     /**********| addition for LOTZ2 end |**********/
     
     int result; /* stores return values of called functions */
     int *initial_population; /* storing the IDs of the individuals */
     initial_population = (int *) malloc(alpha * sizeof(int)); 
     if (initial_population == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (1);
     }
     
     /**********| added for LOTZ2 |*****************/
     result = read_local_parameters();  
     if (result != 0)
     { 
          log_to_file(log_file, __FILE__, __LINE__,
                      "couldn't read local parameters");
          return (1);
     }
     
     /* create first alpha individuals */
     for(i = 0; i < alpha; i++)
     {
          initial_population[i] = add_individual(new_individual());
          if(initial_population[i] == -1)
               return (1);
     } 

     gen = 1;

     /**********| addition for LOTZ2 end |**********/

     result = write_ini(initial_population);
     if (result != 0)
     { 
          log_to_file(log_file, __FILE__, __LINE__,
                      "couldn't write ini");
          free(initial_population);
          return (1);
     }

     free(initial_population);
     return (0);
}



int state2()
/* Do what needs to be done in state 2.

   pre: The global variable 'mu' contains the number of indiviuals
        you need to read using 'read_sel()'.
        The global variable 'lambda' contains the number of individuals
        you need to create by variation of the individuals specified the
        'sel' file.
        
   post: Optionally call read_arc() in order to delete old uncessary
         individuals from the global population.
         read_sel() called
         'lambda' children generated from the 'mu' parents
         Children added to the global population using add_individual().
         Information about children written to the 'var' file using
         write_var().
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     int *parent_identities, *offspring_identities; /* array of identities */
     int result; /* stores return values of called functions */

     parent_identities = (int *) malloc(mu * sizeof(int)); 
     if (parent_identities == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (1);
     }

     offspring_identities = (int *) malloc(lambda * sizeof(int)); 
     if (offspring_identities == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (1);
     }
     
     result = read_sel(parent_identities);
     if (result != 0) /* if some file reading error occurs, return 2 */
          return (2);

     result = read_arc(); 
     if (result != 0) /* if some file reading error occurs, return 2 */
          return (2);
     
     /**********| added for LOTZ2 |*****************/
     
     result = variate(parent_identities, offspring_identities);
     if (result != 0)
          return (1);
          
     gen++;

     /**********| addition for LOTZ2 end |**********/

     result = write_var(offspring_identities);
     if (result != 0)
     { 
          log_to_file(log_file, __FILE__, __LINE__,
                      "couldn't write var");
          free(offspring_identities);
          free(parent_identities);
          return (1);
     }

     free(offspring_identities);
     free(parent_identities);
     return (0);
}
 

int state4() 
/* Do what needs to be done in state 4.

   pre: State 4 means the variator has to terminate.

   post: Free all memory.
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     /**********| added for LOTZ2 |*****************/
     
     int result;
     result = read_arc();

     if (0 == result) /* arc file correctly read
                         this means it was not read before,
                         e.g., in a reset. */
     {
        write_output_file();
     }

     /**********| addition for LOTZ2 end |**********/
     
     return (0);
}


int state7()
/* Do what needs to be done in state 7.

   pre: State 7 means that the selector has just terminated.

   post: You probably don't need to do anything, just return 0.
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     return(0);  
}


int state8()
/* Do what needs to be done in state 8.

   pre: State 8 means that the variator needs to reset and get ready to
        start again in state 0.

   post: Get ready to start again in state 0. 
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     /**********| added for LOTZ2 |*****************/

   int result;
   
   gen = 1;
     
   result = read_arc();

   if (0 == result) /* arc file correctly read
                       this means it was not read before */
   {
      write_output_file();
   }

     
     /**********| addition for LOTZ2 end |**********/
     
     return (0);
}


int state11()
/* Do what needs to be done in state 11.

   pre: State 11 means that the selector has just reset and is ready
        to start again in state 1.

   post: You probably don't need to do anything, just return 0.
         Return value == 0 if successful,
                      == 1 if unspecified errors happened,
                      == 2 if file reading failed.
*/
{
     return (0);  
}


int is_finished()
/* Tests if ending criterion of your algorithm applies.

   post: return value == 1 if optimization should stop
         return value == 0 if optimization should continue
*/
{
     /**********| added for LOTZ2 |*****************/
     return (gen >= maxgen);
     /**********| addition for LOTZ2 end |**********/
}

/**********| added for LOTZ2 |*****************/

int read_local_parameters()
{
     FILE *fp;
     int result;
     char str[CFG_NAME_LENGTH];
     
     /* reading parameter file with parameters for selection */
     fp = fopen(paramfile, "r"); 
     assert(fp != NULL);

     if(dimension > 2 || dimension < 0)
     {
          log_to_file(log_file, __FILE__, 
                      __LINE__, "can't handle that dimension");
          return(1);
     } 

     if(mu != lambda)
     {
          log_to_file(log_file, __FILE__, 
                      __LINE__, "can't handle mu != lambda");
          return(1);
     }


     fscanf(fp, "%s", str);
     assert(strcmp(str, "seed") == 0);
     fscanf(fp, "%u", &seed); /* %u because seed is unsigned */
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "length") == 0);
     fscanf(fp, "%d", &length);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "maxgen") == 0);
     fscanf(fp, "%d", &maxgen);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "outputfile") == 0);
     fscanf(fp, "%s", outfile); /* fscanf() returns EOF if
                                   reading failed. */
     fscanf(fp, "%s", str);
     assert(strcmp(str, "mutation_type") == 0);
     fscanf(fp, "%d", &mutation_type);
    
     fscanf(fp, "%s", str);
     assert(strcmp(str, "recombination_type") == 0);
     fscanf(fp, "%d", &recombination_type);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "mutation_probability") == 0);
     fscanf(fp, "%le", &mutat_prob);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "recombination_probability") == 0);
     fscanf(fp, "%le", &recom_prob);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "bit_turn_probability") == 0);
     result = fscanf(fp, "%le", &bit_turn_prob);


     assert(result != EOF); /* no EOF, outfile correctly read */
     
     srand(seed); /* seeding random number generator */

     fclose(fp);
     
     return (0);
}


int variate(int *parents, int *offspring)
/* Performs variation (= recombination and mutation) according to
   settings in the parameter file.
   Returns 0 if successful and 1 otherwise.*/
{
     int result, i, k;

     result = 1;

     /* copying all individuals from parents */
     for(i = 0; i < mu; i++)
     {
          offspring[i] = 
               add_individual(copy_individual(get_individual(parents[i])));
          if(offspring[i] == -1)
          {
               log_to_file(log_file, __FILE__, __LINE__,
                           "copying + adding failed");
               return (1);
          }
     }
 
     /* if odd number of individuals, last one is
        left as is */
     if((((double)mu/2) - (int)(mu/2)) != 0)
          k = mu - 1; 
     else
          k = mu;

     /* do recombination */
     for(i = 0; i < k; i+= 2)
     {  
          result = 1;
          if (drand(1) <= recom_prob)
          {
               result = 1;
               if (recombination_type == 1)
               {
                    result = one_point_crossover(get_individual(offspring[i]),get_individual(offspring[i + 1]));
               }
               else if (recombination_type == 2)
               {
                    result = uniform_crossover(get_individual(offspring[i]), get_individual(offspring[i + 1]));
               }
               else if (recombination_type == 0)
                    result = 0;

               if (result != 0)
               {
                    log_to_file(log_file, __FILE__, 
                                __LINE__, "recombination failed!");
                    return (1);
               }
          }
     }

     /* do mutation */
     for(i = 0; i < mu; i++)
     {
          result = 1;
          if (drand(1) <= mutat_prob) /* only mutate with mut.probability */
          { 
               if(mutation_type == 1)
               {
                    result = one_bit_mutation(get_individual(offspring[i]));
               }
               else if(mutation_type == 2)
               {
                    result = indep_bit_mutation(get_individual(offspring[i]));
               }
               else if(mutation_type == 0)
               {
                    result = 0;
               }
    
               if(offspring[0] == -1)
               {
                    log_to_file(log_file, __FILE__, __LINE__,
                                "mutation failed!");
                    return (1);
               }
          }
     }
     
     return (0);
}



int one_bit_mutation(individual *ind)
/* Toggles exactly one bit in 'ind'. */
{
     int position;

     if(ind == NULL)
          return (1);
     /* flip bit at position */
     position = irand(ind->length);
     
     if(ind->bit_string[position] == 0)
          ind->bit_string[position] = 1;
     else
          ind->bit_string[position] = 0;

     /* evaluate new ind */
     ind->lo = eval_lo(ind);
     ind->tz = eval_tz(ind);
  
     return (0);
}


int indep_bit_mutation(individual *ind)
/* Toggles each bit with probability bit_turn_prob */
{
     int i;
     double probability;
     /* absolute probability */
     probability = bit_turn_prob;
     if(ind == NULL)
          return (1);

     for(i = 0; i < ind->length; i++)
     {
          if(drand(1) < probability)
          {
               /* flip bit at position i*/
               if(ind->bit_string[i] == 0)
                    ind->bit_string[i] = 1;
               else
                    ind->bit_string[i] = 0;
          }
     }

     /* evaluate new ind */
     ind->lo = eval_lo(ind);
     ind->tz = eval_tz(ind);

     return (0);
}


int one_point_crossover(individual *ind1, individual *ind2)
/* Performs "one point crossover".
   Takes pointers to two individuals as arguments and replaces them by the
   children (i.e. the children are stored in ind1 and ind2). */
{
     int position, i;
     int *bit_string_ind2;
     bit_string_ind2 = (int *) malloc(sizeof(int) * ind2->length);
     if (bit_string_ind2 == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (1);  
     }
     
     
     for(i = 0; i < ind2->length; i++)
     {
          bit_string_ind2[i] = ind2->bit_string[i];
     }

     position = irand(ind2->length);

     for(i = 0; i < position; i++) {
          ind2->bit_string[i] = ind1->bit_string[i];
          ind1->bit_string[i] = bit_string_ind2[i];   
     }  

     free(bit_string_ind2);

     /* evaluate new inds */
     ind1->lo = eval_lo(ind1);
     ind1->tz = eval_tz(ind1);

     ind2->lo = eval_lo(ind2);
     ind2->tz = eval_tz(ind2);

     return(0);
}


int uniform_crossover(individual *ind1, individual *ind2)
/* Performs a "uniform crossover".
   Takes pointers to two individuals as arguments and replaces them by the
   children (i.e. the children are stored in ind1 and ind2). */
{

     int choose, i;
     int *bit_string_ind2;
     bit_string_ind2 = (int *) malloc(sizeof(int) * ind2->length);
     if (bit_string_ind2 == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (1);  
     }
     
     for(i = 0; i < ind2->length; i++)
     {
          bit_string_ind2[i] = ind2->bit_string[i];
     }



     for(i = 0; i < ind2->length; i++)
     {
          choose = irand(2);
          if(choose == 1) /* switch around bits */
          { 
               ind2->bit_string[i] = ind1->bit_string[i];
               ind1->bit_string[i] = bit_string_ind2[i];
          } /* else leave bit as it is */   
     }  

     free(bit_string_ind2);

     /* evaluate new inds */
     ind1->lo = eval_lo(ind1);
     ind1->tz = eval_tz(ind1);

     ind2->lo = eval_lo(ind2);
     ind2->tz = eval_tz(ind2);

     return (0);
}


int irand(int range)
/* Generate a random integer. */
{
     int j;
     j=(int) ((double) range * (double) rand() / (RAND_MAX + 1.0));
     return (j);
}


double drand(double range)
/* Generate a random double. */
{
     double j;
     j=(range * (double) rand() / (RAND_MAX + 1.0));
     return (j);
}


int eval_lo(individual *ind)
/* Returns the objective value of 'ind' based on Leading Ones.
   In order to maximize Leading Ones this function is minimized.
   PISA always minimizes. */
{
     int i = 0;
 
     assert(ind != NULL);

     while (i < ind->length && ind->bit_string[i] == 1)
          i++;     
     return (length - i);
}



int eval_tz(individual *ind)
/* Returns the objective value of 'ind' based on Trailing Zeros.
   In order to maximize Trailing Zeros this function is minimized.
   PISA always minimizes. */
{
     int tz;
     int i = ind->length-1;

     assert(ind != NULL);
     
     while (i > -1 && ind->bit_string[i] == 0)
          i--;
     tz = ind->length - i - 1;
     return (length - tz);
}



individual *new_individual()
/* Creates a random new individual and allocates memory for it.
   Returns a pointer to the new individual.
   Returns NULL if allocation failed.*/
{
     individual *return_ind;
     int i;

     return_ind = (individual *) malloc(sizeof(individual));
     return_ind->bit_string = (int *) malloc(sizeof(int) * length);

     if (return_ind == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (NULL);  
     }
     
     if (return_ind->bit_string == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (NULL);  
     }
     
     for (i = 0; i < length; i++)
          return_ind->bit_string[i] = irand(2);

     return_ind->length = length;

     /* evaluating two objective functions */
     return_ind->lo = eval_lo(return_ind);
     return_ind->tz = eval_tz(return_ind);  

     return (return_ind);
}


individual *copy_individual(individual *ind)
/* Allocates memory for a new individual and copies 'ind' to this place.
   Returns the pointer to new individual.
   Returns NULL if allocation failed. */
{
     individual *return_ind;
     int i;

     return_ind = (individual *) malloc(sizeof(individual));
     return_ind->bit_string = (int *) malloc(sizeof(int) * length);

     if (return_ind == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (NULL);  
     }
     
     if (return_ind->bit_string == NULL)
     {
          log_to_file(log_file, __FILE__, __LINE__, "variator out of memory");
          return (NULL);  
     }
     
     for (i = 0; i < length; i++)
          return_ind->bit_string[i] = ind->bit_string[i];

     return_ind->lo = ind->lo;
     return_ind->tz = ind->tz;  

     return_ind->length = ind->length;

     return (return_ind);
}



void write_output_file()
/* Writes the index, objective values and bit string of
   all individuals in global_population to 'out_filename'. */
{
     int j, current_id;
     FILE *fp_out;
     individual *temp;
     
     fp_out = fopen(outfile, "w");
     assert(fp_out != NULL);

     current_id = get_first();

     while (current_id != -1)
     {       
	  temp = get_individual(current_id);
          fprintf(fp_out, "%d ", current_id); /* write index */
          fprintf(fp_out, "%.1f ", temp->length - 
		  get_objective_value(current_id, 0));
	  /* number of leading ones */
          
	  fprintf(fp_out, "%.1f ", temp->length -
                  get_objective_value(current_id, 1));
	  /* number of trailing zeros */
          
	  for (j = 0; j < temp->length; j++)
          {
               fprintf(fp_out, "%d", temp->bit_string[j]);
          }
          fprintf(fp_out, "\n");
	  current_id = get_next(current_id);
     }

     fclose(fp_out);
}


/**********| addition for LOTZ2 end |**********/
