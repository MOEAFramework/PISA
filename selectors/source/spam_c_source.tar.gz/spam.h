/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */


#ifndef SPAM_H
#define SPAM_H

/*-----------------------| specify Operating System |------------------*/
/* necessary for wait() */

//#define PISA_WIN
#define PISA_UNIX

/*----------------------------| macro |----------------------------------*/

/*---------------------------| constants |-------------------------------*/
#define FILE_NAME_LENGTH 128 /* maximal length of filenames */
#define CFG_ENTRY_LENGTH 128 /* maximal length of entries in cfg file */
#define PISA_MAXDOUBLE 1E99  /* Internal maximal value for double */

#include "population.h"

/*----------------------------| structs |--------------------------------*/

/*-------------| functions for control flow (in spam.c) |------------*/

void write_flag(char *filename, int flag);
int read_flag(char *filename);
void wait(double sec);

/*---------| initialization function (in spam_functions.c) |---------*/

void initialize(char *paramfile, char *filenamebase);

/*--------| memory allocation functions (in spam_functions.c) |------*/


void free_memory(void);

/*-----| functions implementing the selection (spam_functions.c) |---*/

void matingSelection();
void select_initial();
void select_normal();


/*--------------------| data exchange functions |------------------------*/

/* in spam_functions.c */

int read_ini(void);
int read_var(void);
void write_sel(void);
void write_arc(void);
int check_sel(void);
int check_arc(void);

/* in spam_io.c */

int read_pop(char *filename, pop *pp, int size, int dim);
void write_pop(char *filename, pop *pp, int size);
int check_file(char *filename);

#endif /* SPAM_H */
