/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include <limits.h>

#include "spam.h"
#include "spam_functions_local.h"
#include "spam_functions.h"
#include "reduction.h"
#include "population.h"
#include "prefrel.h"
#include "utils.h"

#define HERE printf("\n %d", __LINE__); fflush(stdout);


/* other variables */
char cfgfile[FILE_NAME_LENGTH];  /* 'cfg' file (common parameters) */
char inifile[FILE_NAME_LENGTH];  /* 'ini' file (initial population) */
char selfile[FILE_NAME_LENGTH];  /* 'sel' file (parents) */
char arcfile[FILE_NAME_LENGTH];  /* 'arc' file (archive) */
char varfile[FILE_NAME_LENGTH];  /* 'var' file (offspring) */

/* SPAM internal global variables */
fpart curr_part;  /* front partitioning of previous population */
fpart repl_part;  /* front partitioning after simple replacement */
fpart redu_part;  /* front partitioning after (heuristic) reduction */

/*-----------------------| initialization |------------------------------*/

void initialize(char *paramfile, char *filenamebase)
/* Performs the necessary initialization to start in state 0. */
{
	FILE *fp;
	int result;
	char str[CFG_ENTRY_LENGTH];

	/* reading parameter file with parameters for selection */
	fp = fopen(paramfile, "r");
	assert(fp != NULL);

	fscanf(fp, "%s", str);
	assert(strcmp(str, "seed") == 0);
	result = fscanf(fp, "%d", &seed);

	greedy = 1;
	ranking = 1;
	scaling = 0;
	sorting = 1;

	fscanf(fp, "%s", str);
	assert(strcmp(str, "bound") == 0);
	result = fscanf(fp, "%lf", &bound);

	scaling = 0;

	fscanf(fp, "%s", str);
	assert(strcmp(str, "prefreltype") == 0);
	result = fscanf(fp, "%d", &prefrelType);

	assert(result != EOF); /* no EOF, parameters correctly read */

	fclose(fp);

	srand(seed); /* seeding random number generator */

	sprintf(varfile, "%svar", filenamebase);
	sprintf(selfile, "%ssel", filenamebase);
	sprintf(cfgfile, "%scfg", filenamebase);
	sprintf(inifile, "%sini", filenamebase);
	sprintf(arcfile, "%sarc", filenamebase);

	/* reading cfg file with common configurations for both parts */
	fp = fopen(cfgfile, "r");
	assert(fp != NULL);

	fscanf(fp, "%s", str);
	assert(strcmp(str, "alpha") == 0);
	fscanf(fp, "%d", &alpha);
	assert(alpha > 0);

	fscanf(fp, "%s", str);
	assert(strcmp(str, "mu") == 0);
	fscanf(fp, "%d", &mu);
	assert(mu > 0);

	fscanf(fp, "%s", str);
	assert(strcmp(str, "lambda") == 0);
	fscanf(fp, "%d", &lambda);
	assert(lambda > 0);

	fscanf(fp, "%s", str);
	assert(strcmp(str, "dim") == 0);
	result = fscanf(fp, "%d", &dim);
	assert(result != EOF); /* no EOF, 'dim' correctly read */
	assert(dim > 0);
	setPopSizes( alpha, lambda, mu, dim );

	fclose(fp);

	/* create individual and archive pop */
	create_population();

	/* create temporary populations (indices only) */
	create_front_part(&curr_part, alpha + lambda);
	create_front_part(&repl_part, alpha + lambda);
	create_front_part(&redu_part, alpha + lambda);

}


/*-------------------| memory allocation functions |---------------------*/

void free_memory()
/* Frees all memory. */
{
	free_front_part(&curr_part);
	free_front_part(&repl_part);
	free_front_part(&redu_part);

	free_populations();
}

/*-----------------------| selection functions|--------------------------*/

void assignFitness(front* fp, int fitnessType)
/* fitness is to be maximized */
{
	int i, j;
	int dum1PrefToDum2, dum2PrefToDum1;
	front* fpTemp1;
	front* fpTemp2;
	fpart dum1_part;  /* temporary storage */
	fpart dum2_part;  /* temporary storage */
	create_front_part(&dum1_part, alpha + lambda);
	create_front_part(&dum2_part, alpha + lambda);

	double indicatorValue;

	fpTemp1 = &(dum1_part.front_array[0]);
	for (i = 0; i < fp->size; i++)
		fpTemp1->members[i] = fp->members[i];
	dum1_part.size = fp->size;
	dum1_part.fronts = 1;
	dum1_part.front_array[0].size = fp->size;



	if ( fitnessType >= 0 && fitnessType < 50 )
	{
		fpTemp1->size--;
		for (i = fpTemp1->size; i >= 0; i--)
		{
			int temp = fpTemp1->members[i];
			fpTemp1->members[i] = fpTemp1->members[fpTemp1->size];
			indicatorValue = unaryIndicator(fitnessType, fpTemp1->members,
					fpTemp1->size, bound, scaling );
			setFitness(temp, -indicatorValue);
			fpTemp1->members[fpTemp1->size] = temp;
		}
	}
	else if( fitnessType >= 50)
	{
		copyPart(&dum1_part, &dum2_part);
		fpTemp2 = &(dum2_part.front_array[0]);
		for (i = fpTemp1->size - 1; i >= 0; i--)
			setFitness( fpTemp1->members[i], 0.0 );
		dum1_part.size--;
		dum2_part.size--;
		for (i = fpTemp1->size - 1; i >= 0; i--)
		{
			int temp1 = fpTemp1->members[i];
			fpTemp1->size--;
			fpTemp1->members[i] = fpTemp1->members[fpTemp1->size];
			for (j = i - 1; j >= 0; j--)
			{
				int temp2 = fpTemp2->members[j];
				fpTemp2->size--;
				fpTemp2->members[j] = fpTemp2->members[fpTemp2->size];
				dum1PrefToDum2 = prefrel(&dum1_part, &dum2_part, -fitnessType, sorting,
						ranking, bound, scaling );
				dum2PrefToDum1 = prefrel(&dum2_part, &dum1_part, -fitnessType, sorting,
						ranking, bound, scaling );
				if (!dum1PrefToDum2 && dum2PrefToDum1)
					increaseFitness( temp1, 1.0 );
				if (dum1PrefToDum2 && !dum2PrefToDum1)
					increaseFitness( temp2, 1.0 );
				fpTemp2->members[fpTemp2->size] = fpTemp2->members[j];
				fpTemp2->members[j] = temp2;
				fpTemp2->size++;

			}
			fpTemp1->members[fpTemp1->size] = fpTemp1->members[i];
			fpTemp1->members[i] = temp1;
			fpTemp1->size++;
		}
	}
	else {
		fprintf(stderr,"Undefinend fitness type\n");
		exit(1);
	}
	free_front_part(&dum1_part);
	free_front_part(&dum2_part);
}


void matingSelection()
/* Fills mating pool 'pp_sel' using binary tournament selection with replacement */
{
	int i;
	int winner, winnerFront;

	for( i = 0; i < getPopulationSize(); i++ )
		setFitness(i,0.0);

	for (i = 0; i < mu; i++)
	{
		determineIndexAndFront(&curr_part, irand( getPopulationSize() ),
				&winner, &winnerFront, sorting );
		addToSelection( i, winner );
	}
}

void select_initial()
/* Performs initial selection. */
{
	copyExPopToArcPop(sorting, ranking, &curr_part);
	doScaling(scaling);
	matingSelection();
}

void select_normal()
/* Performs normal selection.*/
{
	generatePartitions( sorting, ranking, &curr_part, &redu_part, &repl_part );
	updatePopulation( sorting, &curr_part, &redu_part, &repl_part, ranking );
	doScaling(scaling);

	fpart* new_partp;
	new_partp = environmentalSelection(&redu_part, &repl_part, &curr_part,
			alpha, sorting, varfile);
	copyPart(new_partp, &curr_part);

	cleanUpArchive(&curr_part);
	matingSelection();
}

/*--------------------| data exchange functions |------------------------*/

int read_ini()
{
	pop* pp_tmp = createExPop(alpha, dim);

	return (read_pop(inifile, pp_tmp, alpha, dim));
}

int read_var()
{
	pop* pp_tmp = createExPop(lambda,dim);
	return (read_pop(varfile, pp_tmp, lambda, dim));
}

void write_sel()
{
	write_pop(selfile, getSelPop(), mu);
}

void write_arc()
{
	write_pop(arcfile, getArcPop(), getArcSize() );
}

int check_sel()
{
	return (check_file(selfile));
}

int check_arc()
{
	return (check_file(arcfile));
}
