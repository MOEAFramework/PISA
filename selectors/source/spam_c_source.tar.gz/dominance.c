/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#include "dominance.h"
#include "utils.h"
#include "population.h"

comp dominanceCheckInd(int a, int b)
/* objectives are to be minimized */
{
	int i;
	int aWorse = 0;
	int bWorse = 0;

	for (i = 0; i < getNrOfObjectives() && !(aWorse && bWorse); i++)
	{
		aWorse = (aWorse || (getObjectiveValueDifferenceUnscaled(a,b,i) > 0 ) );
		bWorse = (bWorse || (getObjectiveValueDifferenceUnscaled(a,b,i) < 0 ) );
	}
	if (aWorse && bWorse)
		return incomparable;
	else if (aWorse)
		return b_better_a;
	else if (bWorse)
		return a_better_b;
	return indifferent;
}

comp dominanceCheckPop(int *A, int sizea, int *B, int sizeb)
{
	int i, j;
	int covered;
	int aWorse = 0;
	int bWorse = 0;

	for (i = sizea - 1; i >= 0 && !bWorse; i--)
	{
		covered = 0;
		for (j = sizeb - 1; j >= 0 && !covered; j--)
		{
			switch (dominanceCheckInd(A[i], B[j]))
			{
				case a_better_b:
				case incomparable:
					break;
				default:
					covered = 1;
					break;
			}
		}
		if (!covered)
			bWorse = 1;
	}
	for (i = sizeb - 1; i >= 0 && !aWorse; i--)
	{
		covered = 0;
		for (j = sizea - 1; j >= 0 && !covered; j--)
		{
			switch (dominanceCheckInd(B[i], A[j]))
			{
			case a_better_b:
			case incomparable:
				break;
			default:
				covered = 1;
				break;
			}
		}
		if (!covered)
			aWorse = 1;
	}
	if (aWorse && bWorse)
		return incomparable;
	else if (aWorse)
		return b_better_a;
	else if (bWorse)
		return a_better_b;
	return indifferent;
}

int weaklyDominatesMin( double *point1, double *point2, int no_objectives )
{
	int better;
	better = 1;
	int i = 0;

	while( i < no_objectives && better )
	{
		better = point1[i] <= point2[i];
		i++;
	}
	return better;
}

int dominates(double  *point1, double  *point2, int  no_objectives)
/* returns true if 'point1' dominates 'point2' with respect
   to the first transformed! 'no_objectives' objectives

   point1 and point2 don't represent the objective values and are to be
   maximized rather than minimized
*/
{
	int  i;
	int  better_in_any_objective, worse_in_any_objective;

	better_in_any_objective = 0;
	worse_in_any_objective = 0;
	for (i = 0; i < no_objectives && !worse_in_any_objective; i++)
		if (point1[i] > point2[i])
			better_in_any_objective = 1;
		else if (point1[i] < point2[i])
			worse_in_any_objective = 1;
	return (!worse_in_any_objective && better_in_any_objective);
}

int weakly_dominates(double  *point1, double  *point2, int  no_objectives)
/* returns true if 'point1' weakly dominates 'points2' with respect to the
   to the first 'no_objectives' objectives
*/
{
	int  i;
	int  worse_in_any_objective;

	worse_in_any_objective = 0;
	for (i = 0; i < no_objectives &&  !worse_in_any_objective; i++)
		if (point1[i] < point2[i])
			worse_in_any_objective = 1;
	return (!worse_in_any_objective);
}
