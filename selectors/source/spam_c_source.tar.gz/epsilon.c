/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#include "epsilon.h"
#include "float.h"
#include "population.h"
#include "assert.h"
#include "dominance.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void generateRandomWeightOnSphere( double* w, int dim ) {
	int i;
	double length;
	do
	{
		length = 0.0;
		for( i = 0; i < dim; i++ ) {
			w[i] = drand( 0, 1 );
			length += w[i]*w[i];
		}
		length = sqrt(length);
	} while( length > 1 );
	for( i = 0; i < dim; i++ ) {
		w[i] = w[i] / length;
	}
}

double unaryWeightedEpsilonReferencePoint(int* A,int sizea, int type)
{
	/* The smaller eps, the better A */
	int dim = getNrOfObjectives();
	int nrOfReferencePoints;
	double g[100][dim];   /* reference point(s) */
	double w[dim];
	int i; int m; int l; int k;

	if( type == 1 ) {
		nrOfReferencePoints = 2;
		g[0][0] = 0.3;
		for( i = 1; i < dim; i++ )
			g[0][i] = 0.9;
		g[1][0] = 0.8;
		for( i = 1; i < dim; i++ )
			g[1][i] = 0.5;
	}
	else if( type == 0 ) {
		nrOfReferencePoints = 1;
		for( i = 0; i < dim; i++ ) {
			g[0][0] = 0.0;
			g[0][1] = 0.0;
		}
	}
	else {
		fprintf(stderr,"Unknown unaryWeightedEpsilonReferencePoint-type %d ", type);
		exit(1);
	}

	double scaling[] = {0.333, 0.666};

	double eps = 0.0;
	double eps_max = 0.0;
	double eps_min = 0.0;
	double eps_tmp = 0.0;


	for( m = 0; m < nrOfReferencePoints; m++ ) {   /* Iterate over all reference points */
		for( l = 0; l < 1000; l++) {				   /* Iterate over all weights */

			generateRandomWeightOnSphere( w, dim );

			eps_min = -1;
			for( i = 0; i < sizea; i++ ) {         /* Iterate over all A */
				eps_max = -1;
				for( k = 0; k < dim; k++ ) {       /* Iterate over all objectives */
					eps_tmp = (getObjectiveValue(A[i],k) - g[m][k]) / w[k];
					if( k == 0 )
						eps_max = eps_tmp;
					else if (eps_max < eps_tmp)
						eps_max = eps_tmp;
				}
				if( i == 0 )
					eps_min = eps_max;
				else if( eps_max < eps_min ) {
					eps_min = eps_max;
				}
			}
			eps += scaling[m]*eps_min;
		}
	}
	return eps;
}


double unaryEpsilonFrontRef(int *A, int sizea)
/* The smaller eps, the better A */
/* Reference line from (0,0.8) to (0.4,0.6) */
{
	int i, k;
	double j;
	double  eps, eps_j, eps_k, eps_temp;
	eps_j = 0;
	eps_k = 0;
	eps = DBL_MIN;

	//double x;
	//double y;
	for( j = 0.0; j <= 10.0; j=j+0.1 )
	{
		//x = j/100.0 + 0.6;
		//y = 7.5 - x*7.0;
		for (i = 0; i < sizea; i++)
		{
			/* eps_k: I( A[i], j ) */
			for (k = 0; k < getNrOfObjectives(); k++)
			{
				if( k == 0 ){
					//eps_temp = getObjectiveValue(A[i], k) - x;
					eps_temp = getObjectiveValue(A[i], k) - (j/10.0*0.4) ;
				}
				else{
					//eps_temp = getObjectiveValue(A[i], k) - y;
					eps_temp = getObjectiveValue(A[i], k) - (0.8 - (j/10.0)*0.2 );
				}
				if (k == 0)
					eps_k = eps_temp;
				else if (eps_k < eps_temp)
					eps_k = eps_temp;
			}
			/* eps_j: I(A,j ) */
			if (i == 0 || eps_k < eps_j)
				eps_j = eps_k;
		}
		/* eps: I(A,J) */
		if( j == 0 || eps_j > eps )
			eps = eps_j;
	}

	return eps;
}
