/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#ifndef DOMINANCE_H
#define DOMINANCE_H

#include "utils.h"

comp dominanceCheckInd(int a, int b);
comp dominanceCheckPop(int *A, int sizea, int *B, int sizeb);
int dominates(double  *point1, double  *point2, int  no_objectives);
int weaklyDominatesMin( double *point1, double *point2, int no_objectives );

#endif
