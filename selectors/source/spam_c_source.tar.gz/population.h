/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#ifndef POPULATION_H
#define POPULATION_H

typedef struct ind_st  /** an individual */
{
    int index;
    double *f_u; /** objective vector */
    double *f_s;
    double fitness;
    double dummy; /** used for various internal purposes */
}
ind;

typedef struct obj_st /** status of objetive values */
{
	int*	enabled;
	int* 	mapping;
	int		nr_of_enabled_obj;
}
obj;

typedef struct pop_st  /* a population */
{
    int size;
    int dim;
    int maxsize;
    ind **ind_array;
    obj *obj;
    double *upperbounds;
    double *lowerbounds;
}
pop;

typedef struct front_st
{ /* a single nondominated set */
    int     size;
    int*    members;
}
front;

typedef struct fp_st
{ /* a hierarchy of multiple nondominated sets */
    int     max_fronts;
    int     fronts;
    int     size;
    front*  front_array;
}
fpart;
void resetPPAll();
void scaleObjectiveValues( int scaling );
void performDominanceSorting(int ranking, fpart* partp);
void undoDominanceSorting(fpart* partp, int ranking);
void cleanPart(fpart* partp);
void copyPart(fpart* sourcep, fpart* destp);
void compute_bounds();
void free_pop(pop *pp);
void free_populations();
void cleanUpArchive(fpart* partp);
void determineIndexAndFront(fpart* partp, int n, int* index, int* front, int sorting);
void free_front_part(fpart*  partp);
void complete_free_pop(pop *pp);
int getPopulationSize();
void addToSelection(int i, int c );
void copyExPopToArcPop( int sorting, int ranking, fpart* curr_part );
pop* getSelPop();
pop* getArcPop();
int getArcSize();
void setPopSizes( int alpha, int lambda, int mu, int dim);
void setAllPopSize( int size );
void doScaling(int scaling);
void getObjectiveArray( int* A, int sizea, double* );
void getObjectiveVector( int* A, int sizea, int k, double* );
void setFitness(int index, double value );
void increaseFitness( int index, double value );
double getFitness(int index);
int getNrOfObjectives();
double getObjectiveValueDifference(int a, int b, int k );
double getObjectiveValueDifferenceUnscaled(int a, int b, int k);
void create_front_part(fpart*  partp, int  max_pop_size);
double getObjectiveValue(int a, int k );
double getReversedObjectiveValue(int a, int k, int scaling, double bound );
pop* create_pop(int maxsize, int dim);
void generatePartitions( int sorting, int ranking, fpart* curr_part,
		fpart* redu_part, fpart *repl_part );
void updatePopulation( int sorting, fpart* curr_part, fpart* redu_part,
		fpart* repl_part, int ranking );
void create_population();
pop* createExPop(int ind_to_create, int dim );
void deleteExPop(void);
void removeIndividual( int sel, fpart* partp, front *fp );
void removeTheWorstIndividual(fpart* partp, front* fp);
int removeTheWorstIndividualUnique(fpart* partp, front* fp, int indices[] );
void removeTheWorstIndividualFromSet(fpart* partp, front* fp, int indices[],
		int indicesLength );
void setObjectiveVector( int index,  double* objectiveValues, int dim );

#endif
