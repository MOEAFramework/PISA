/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#ifndef UTILS_H
#define UTILS_H

#include <stdlib.h>

#define PISA_ERROR(x) fprintf(stderr, "\nError: " x "\n"), fflush(stderr), exit(EXIT_FAILURE)

int irand(int range);
double drand( double from, double to );
void* chk_malloc(size_t size);
void chk_free( void* handle );
void quick_sort(double numbers[], int left, int right, int multiply );
void quick_sort_indices(double values[], int indices[], int left, int right );
void getReductionTypes( int reduction, int* procedure, int* paretoFrontType,
		int* remainingType );

typedef enum
{
    a_better_b, b_better_a, incomparable, indifferent
} comp;

#endif
