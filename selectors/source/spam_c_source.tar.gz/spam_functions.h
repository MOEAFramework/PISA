/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */


#include "population.h"


/* common parameters */
int alpha;  /* number of individuals in initial population */
int mu;     /* number of individuals selected as parents */
int lambda; /* number of offspring individuals */
int dim;    /* number of objectives */

/* local parameters from paramfile*/
int seed;   /* seed for random number generator */
int prefrelType;  /* determines type of preference relation to use */

int ranking; /* determines type of presorting: dominance depth (0) or rank (1), here
				only (1) is used */
int greedy;  /* flag indicating whether (greedy) reduction method is applied */

int sorting;

double bound; /* upper bound for all objectives; needed for hypervolume calculation */
int scaling; /* determines whether population is scaled to [0,1]^dim in each
						generation or not
						0: no scaling, objective values stay uneffected
						1: adaptive scaling of population bounds * 1.1 to [0,1]^dim
						2: scaling of population (including
							minimal objective values) times 1.1 to [0,1]^dim
						3: as 1, but with additional stress of extreme points
							by adding additional kernel weights on axis

						 */

void assignFitness(front* fp, int type);
