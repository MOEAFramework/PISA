/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPAM - Set Preference Algorithm for Multiobjective Optimization

  authors: Johannes Bader, johannes.bader@tik.ee.ethz.ch
           Eckart Zitzler, eckart.zitzler@tik.ee.ethz.ch
           Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, stefan.bleuler@tik.ee.ethz.ch
			   Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch

  last change: 01.12.2008
  ========================================================================
 */

#include <stdlib.h>
#include <stdio.h>
#include "utils.h"

void getReductionTypes( int reduction, int* procedure, int* paretoFrontType,
		int* remainingType  )
{
	switch( reduction )
	{
	case 1: /* minPart + HV */
		*remainingType = 4;
		*paretoFrontType = 4;
		*procedure = 1;
		break;
	case 2: /* minPart + P1 + HV */
		*remainingType = 4;
		*paretoFrontType = 56;
		*procedure = 1;
		break;
	case 3: /* minPart + R2 + HV */
		*remainingType = 4;
		*paretoFrontType = 3;
		*procedure = 2;
		break;
	case 4: /* minPart + eps1 + HV */
		*remainingType = 4;
		*paretoFrontType = 11;
		*procedure = 1;
		break;
	case 5: /* minPart + P0 + HV */
		*remainingType = 4;
		*paretoFrontType = 30;
		*procedure = 1;
		break;
	case 6: /* minPart + D + HV */
		*remainingType = 14;
		*paretoFrontType = 14;
		*procedure = 3;
		break;	
	default:
		fprintf(stderr,"Unknown reduction type %d!\n", reduction);
		exit(1);
	}
}

int irand(int range)
/* generates a random integer */
{
	int j;

	j=(int) ((double)range * (double) rand() / (RAND_MAX+1.0));
	return (j);
}

double drand( double from, double to )
{
	double j;
	j = from + (double)( (to-from)*rand() / ( RAND_MAX + 1.0) );
	return (j);
}

void* chk_malloc(size_t size)
/* Wrapper function for malloc(). Checks for failed allocations. */
{
	void *return_value = malloc(size);
	if (return_value == NULL) {
		PISA_ERROR("Selector: Out of memory.");
	}
	return (return_value);
}

void chk_free( void* handle )
{
	if( handle != NULL ) {
		free( handle );
	}
}
