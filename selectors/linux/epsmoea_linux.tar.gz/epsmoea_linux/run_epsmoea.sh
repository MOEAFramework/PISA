#!/bin/sh
./epsmoea epsmoea_param.txt ../PISA_ 0.1
