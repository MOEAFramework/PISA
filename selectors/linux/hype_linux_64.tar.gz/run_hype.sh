#!/bin/sh
./hype hype_param.txt ../PISA_ 0.1
