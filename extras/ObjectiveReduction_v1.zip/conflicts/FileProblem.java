/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileProblem extends Problem {		
	/* number of objectives is os_dim */
	private int n; 		        // number of points
	private double[][] points;  // objective values of the n points
	
	public FileProblem(String filename) {
		this.points = this.getPointsFromFile(filename);		
	}
	
	/**
	 *  returns the objective values for the genotype
	 */
	public double[] getFitness(Object genotype) {
		int id = ((Individual)genotype).getID();
		for (int i=0; i<points.length; i++) {
			if (points[i][0] == id) {
				double[] p = new double[points[i].length-1];
				for (int j=0; j<points[i].length-1; j++) {
					p[j] = points[i][j+1];
				}
				return p;
			}
		}		
		return null;
	}
	
	/**
	 *  return the matrix with id's in first column and the objective values for the
	 * points in the other columns
	 */
	public double[][] getPoints() {
		return this.points;
	}
	
	public int getNumberOfDifferentPoints() {
		return this.n;
	}
	
	/**
	 * Reads points from file filename.
	 */
	private double[][] getPointsFromFile(String filename) {
		double[][] p = new double[2][2];
		try {
			String line;
	
			File inputFile = new File(filename);
			FileReader inputStream = new FileReader(inputFile);
			BufferedReader input = new BufferedReader(inputStream);
			
			for (int i=0; i<2; i++) {
				line = input.readLine();
				String[] lineSegment = line.split(" ");
				if (line.contains("k=")) {
					this.os_dim = new Integer(lineSegment[1]).intValue();
				} else if (line.contains("n=")) {
					this.n = new Integer(lineSegment[1]).intValue();
				}
			}
			p = new double[this.n][this.os_dim+1];
			int i=0; // number of points read
			
			while ((line = input.readLine()) != null) {
				String[] lineSegment = line.split(" ");
				if (lineSegment.length == (this.os_dim+1)){
					for (int j=0; j<this.os_dim+1; j++) {
						p[i][j] = Double.valueOf(lineSegment[j]).doubleValue();
					}
					i++;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return p;
	}

}
