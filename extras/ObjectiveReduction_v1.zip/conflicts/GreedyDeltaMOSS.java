/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import conflicts.sets.ObjectiveSet;

public class GreedyDeltaMOSS {

	private FileProblem problem;
	private Population pop;
	private Controller con;
	
	public void start(String filename, double delta) {		
		init(filename);
		/* new Controller(this.problem, searchSpace={0,1}^n, this.population,
		                   weak dominance relation, epsilon=0): */
		this.con = new Controller(this.problem, 1, this.pop, 1, 0);
		
		ObjectiveSet output = con.greedyAlgorithmForGivenDelta(delta);
		boolean[] elements = output.getElements();
		System.out.println("objectiveSetSize " + output.size());
		for (int i=0; i<elements.length; i++) {
			if (elements[i]) {
				System.out.println(i);
			}
		}
	}

	
	private void init(String filename){
		this.problem = new FileProblem(filename);
		this.pop = new FilePopulation(problem);
	}

	/**
	 * Performs the greedy algorithm for delta-MOSS and writes the objectives contained
	 *    in the computed set line-by-line to stdout together with the first line
	 *    "objectiveSetSize XX".
	 *
	 * @param args
	 * 			args[0]: name of file, with information about the individuals
	 * 						data format: "id objectivevalue1 objectivevalue2 ..."
	 * 			args[1]: given delta 
	 * 
	 */
	public static void main(String[] args) {
		if (args == null || args.length !=2) {
			System.out.println("Wrong usage.");
			System.out.println();
			System.out.println("Usage:");
			System.out.println("   GreedyDeltaMOSS filename delta");
		} else {
			GreedyDeltaMOSS gdeltamoss = new GreedyDeltaMOSS();
			String filename = args[0];
			System.out.println(filename);
			System.out.println(args[1]);
			System.out.println(new Double(args[1]).doubleValue());
			gdeltamoss.start(filename, (new Double(args[1])).doubleValue());
		}
	}

}
