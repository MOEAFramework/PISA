/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts.sets;

public class TreeSet extends ObjectiveSet {
	int chosenObjective = 0;
	
	public TreeSet() {
		super(0);
		this.delta = 0;
		this.chosenObjective = 0;
		this.numOfElements = 0;
		this.set = null;
	}
	
	public TreeSet(int[] elements, int size, double delta) {
		super(elements, size, delta);
		if (elements.length >= 1) {
			this.chosenObjective = elements[0];
		}
	}
	
	/**
	 * Creates a new TreeSet with all elements from both os1 and os2, delta value
	 * delta and chosen objective chosenObjective
	 */
	public TreeSet(ObjectiveSet os1, ObjectiveSet os2, double delta, int chosenObjective) {
		super(os1.getElements(), delta);
		this.chosenObjective = chosenObjective;
		this.addAll(os2);
	}
	
	public int getChosenObjective() {
		return this.chosenObjective;
	}
	
	public void setChosenObjective(int i) {
		this.chosenObjective = i;
	}
	
	public void setDelta(double d) {
		this.delta = d;
	}

	public String toString() {
		String str = "{";		
		for (int i=0;i<this.set.length;i++) {
			if (this.set[i]) {
				str = str + " " + i;
			}
		}
		str += "} with failure ";
		str += this.delta;
		str += " and chosen objective ";
		str += this.chosenObjective; 
		return str;
	}
	
}
