/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import conflicts.sets.IntSet;
import conflicts.sets.ObjectiveSet;

public class ConflictCalculator {

	private FileProblem problem;
	private Population pop;
	private Controller con;

	public void start(String filename) {		
		init(filename);
		this.con = new Controller(this.problem, 1, this.pop, 1, 0);
		java.util.Calendar calendar = new java.util.GregorianCalendar();
		long milliseconds = calendar.getTimeInMillis();
		IntSet output = con.exactAlgorithm();
		System.out.println("One possible minimum objective set: " + output.toString());
		int size = output.size();
		System.out.println(size + " objectives needed for " + filename + " and weak dominance");
		java.util.Calendar calendar2 = new java.util.GregorianCalendar();
		long millis = calendar2.getTimeInMillis();
		System.out.println("Elapsed time during computation: " + (millis-milliseconds) + " milliseconds");
	}

	public void start(String filename, int type, double value, boolean greedy) {		
		init(filename);
		// Controller:
		this.con = new Controller(this.problem, 1, this.pop, 1, 0);
		
		java.util.Calendar calendar = new java.util.GregorianCalendar();
		long milliseconds = calendar.getTimeInMillis();
		if (type == 1) {
			if (greedy) {
				ObjectiveSet output = con.greedyAlgorithmForGivenDelta(value);
				System.out.println("delta-MOSS problem with given delta= " + value);
				System.out.println("greedy algorithm");
				System.out.println("------------------------------------------------------");
				System.out.println("One possible minimal objective set: " + output.toString());
				System.out.println(output.size() + " objectives needed for " + filename + " with failure " + output.getDelta());
			} else {
				ObjectiveSet output = con.exactAlgorithmForGivenDelta(value);
				System.out.println("delta-MOSS problem with given delta= " + value);
				System.out.println("exact algorithm");
				System.out.println("------------------------------------------------------");
				System.out.println("One possible minimal objective set: " + output.toString());
				System.out.println(output.size() + " objectives needed for " + filename + " with failure " + output.getDelta());
			}
		} else {
			int intvalue = (new Double(value)).intValue();
			if (greedy) {
				ObjectiveSet output = con.greedyAlgorithmForGivenK(intvalue);
				System.out.println("delta-MOSS problem with given k= " + intvalue);
				System.out.println("greedy algorithm");
				System.out.println("------------------------------------------------------");
				System.out.println("One possible objective set with minimal delta: " + output.toString());
				System.out.println(output.size() + " objectives needed for " + filename + " with failure " + output.getDelta());
			} else {				
				ObjectiveSet output = con.exactAlgorithmForGivenK(intvalue);
				System.out.println("delta-MOSS problem with given k= " + intvalue);
				System.out.println("exact algorithm");
				System.out.println("------------------------------------------------------");
				System.out.println("One possible objective set with minimal delta: " + output.toString());
				System.out.println(output.size() + " objectives needed for " + filename + " with failure " + output.getDelta());
			}
		}
		java.util.Calendar calendar2 = new java.util.GregorianCalendar();
		long millis = calendar2.getTimeInMillis();
		System.out.println("Elapsed time during computation: " + (millis-milliseconds) + " milliseconds");
	}

	
	private void init(String filename){
		this.problem = new FileProblem(filename);
		this.pop = new FilePopulation(problem);
	}


	/**
	 * Computes the size of the minimum non-redundant set for a given
	 * set of individuals in a file named data.
	 *
	 * @param args
	 * 			args[0]: name of file, with information about the individuals
	 * 						data format: "id objectivevalue1 objectivevalue2 ..."
	 * 			args[1]/
	 * 			args[2]: type/value for the two different delta-MOSS problems:
	 * 						a) the case of given delta value (type = 1, value = delta) and
	 *						b) the case of given k (type = 2, value = k).
	 * 			if only one argument is given, the exact algorithm for MOSS is performed
	 * 			args[3]: if == 'g' then the greedy algorithm is performed
	 * 					 if != 'g' or omitted, the exact algorithm is used 
	 * 
	 */
	public static void main(String[] args) {
		ConflictCalculator cc = new ConflictCalculator();
		
		if (args == null || args.length == 2 || args.length < 1 || args.length > 4) {
			System.out.println("Computes the size of a minimum non-redundant set for a given");
			System.out.println("  set of individuals in a file named data.");
			System.out.println();
			System.out.println("usage of ConflictCalculator: ");
			System.out.println("   ConflictCalculator filename type value [g]");
			System.out.println();
			System.out.println("   where type = 1:  delta-MOSS");
			System.out.println("   and   type = 2:  k-EMOSS");
			System.out.println("   and value=delta, resp. value=k ");
			System.out.println("   If the single character g is used as optional forth");
			System.out.println("     argument, the greedy heuristic is used.");
			System.out.println("   If only one argument is given (filename), the exact");
			System.out.println("     algorithm for MOSS is performed");	
		} else {
			String filename = args[0];
			if (args.length == 1) {
				cc.start(filename);
			} else if (args.length == 3) {
				int type = new Integer(args[1]).intValue();
				double value = new Double(args[2]).doubleValue();
				cc.start(filename, type, value, false);
			} else if (args.length == 4) {
				int type = new Integer(args[1]).intValue();
				double value = new Double(args[2]).doubleValue();
				char c = args[3].charAt(0); 
				if (c == 'g') {
					cc.start(filename, type, value, true);
				} else {
					cc.start(filename, type, value, false);
				}
			}
		}
	}

}
