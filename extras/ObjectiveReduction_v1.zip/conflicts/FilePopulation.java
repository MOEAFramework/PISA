/*=============================================================================
   Objective Reduction Algorithms for Evolutionary Multiobjective Optimization

  =============================================================================
  copyright             Systems Optimization Group
                        Computer Engineering and Networks Laboratory (TIK)
                        ETH Zurich
                        8092 Zurich
                        Switzerland
  author                Dimo Brockhoff, dimo.brockhoff@tik.ee.ethz.ch
  version               October 22, 2007
  =============================================================================
  related papers:
  [bz2007d] D. Brockhoff and E. Zitzler: Dimensionality Reduction in
            Multiobjective Optimization: The Minimum Objective Subset Problem.
            In K. H. Waldmann and U. M. Stocker, editors, Operations Research
            Proceedings 2006, pages 423�429. Springer, 2007.
            
  [bz2007a] D. Brockhoff and E. Zitzler. Offline and Online Objective Reduction
            in Evolutionary Multiobjective Optimization Based on Objective
            Conflicts. TIK Report 269, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2007.            
            
  [bz2006d] D. Brockhoff and E. Zitzler. Are All Objectives Necessary? On
            Dimensionality Reduction in Evolutionary Multiobjective
            Optimization. In T. P. Runarsson et al., editors, Conference on
            Parallel Problem Solving from Nature (PPSN IX), volume 4193 of
            LNCS, pages 533�542, Berlin, Germany, 2006. Springer.
            
  [bz2006c] D. Brockhoff and E. Zitzler. Dimensionality Reduction in
            Multiobjective Optimization with (Partial) Dominance Structure
            Preservation: Generalized Minimum Objective Subset Problems. TIK
            Report 247, Institut f�r Technische Informatik und
            Kommunikationsnetze, ETH Z�rich, April 2006.
            
  [bz2006a] D. Brockhoff and E. Zitzler. On Objective Conflicts and Objective
            Reduction in Multiple Criteria Optimization. TIK Report 243,
            Institut f�r Technische Informatik und Kommunikationsnetze, ETH
            Z�rich, February 2006.            
  =============================================================================
*/

package conflicts;

import java.util.LinkedList;

public class FilePopulation extends Population {	

	public FilePopulation(FileProblem prob) {
		this.problem = prob;
		
		this.ds_dim = 32;
		this.ind = new LinkedList<Individual>();
		this.mu = prob.getNumberOfDifferentPoints();
		
		double[][] p = prob.getPoints();
		/* Inserting all Individuals from prob into the LinkedList ind*/
		for (int i=0; i<p.length; i++) {
			int id = new Double(p[i][0]).intValue();
			double[] obj_vector = new double[p[i].length-1];
			for (int j=0; j<p[i].length-1; j++) {
				obj_vector[j] = p[i][j+1];
			}
			/* Computing the individual's decision vector as binary representation of its id: */
			boolean[] dec_vector = new boolean[32];
			int b = id;
			for (int c=0; c<32; c++) {
				dec_vector[c] = ((b % 2)==0);
				b %= 2;
			}
			
			ind.add((Individual)(new Individual_BS(id, 32, prob.os_dim, dec_vector, obj_vector)));
		}

		this.seed = null;
		
	}
	
}
