#!/bin/sh
./spea2 spea2_param.txt ../PISA_ 0.1
