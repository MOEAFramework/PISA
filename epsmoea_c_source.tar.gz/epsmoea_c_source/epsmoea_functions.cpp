/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  Epsilon MOEA
  
  Implements most functions.
  
  file: epsmoea_functions.c
  author: K. Deb, M. Laumanns und T. Wagner

  revision by: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/


#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cassert>
#include <cmath>
#include <algorithm>

#include "epsmoea.h"

/* common parameters */
int alpha;  /* number of individuals in initial population */
int mu;     /* number of individuals selected as parents */
int lambda; /* number of offspring individuals */
int dim;    /* number of objectives */
int gen;


/* local parameters from paramfile*/
int seed;   /* seed for random number generator */
int tournament;  /* parameter for tournament selection */
double* epsilon; /* vector of epsilon per objective */
int outgen; /* rate of output */


/* other variables */
char cfgfile[FILE_NAME_LENGTH];  /* 'cfg' file (common parameters) */
char inifile[FILE_NAME_LENGTH];  /* 'ini' file (initial population) */
char selfile[FILE_NAME_LENGTH];  /* 'sel' file (parents) */
char arcfile[FILE_NAME_LENGTH];  /* 'arc' file (archive) */
char varfile[FILE_NAME_LENGTH];  /* 'var' file (offspring) */


/* population containers */

pop *pp_all = NULL;
pop *pp_new = NULL;
pop *pp_sel = NULL;
vector<ind*> archive;

/*-----------------------| initialization |------------------------------*/

void initialize(char *paramfile, char *filenamebase)
/* Performs the necessary initialization to start in state 0. */
{
    FILE *fp;
    int result;
    char str[CFG_ENTRY_LENGTH];
    
    sprintf(varfile, "%svar", filenamebase);
    sprintf(selfile, "%ssel", filenamebase);
    sprintf(cfgfile, "%scfg", filenamebase);
    sprintf(inifile, "%sini", filenamebase);
    sprintf(arcfile, "%sarc", filenamebase);
    
    /* reading cfg file with common configurations for both parts */
    fp = fopen(cfgfile, "r");
    assert(fp != NULL);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "alpha") == 0);
    fscanf(fp, "%d", &alpha);
    assert(alpha > 0);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "mu") == 0);
    fscanf(fp, "%d", &mu);
    assert(mu > 0);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "lambda") == 0);
    fscanf(fp, "%d", &lambda);
    if (mu != 2)
    {
        PISA_ERROR("Epsilon MOEA always selects two parent individuals!\n");
    }
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "dim") == 0);
    result = fscanf(fp, "%d", &dim);
    assert(result != EOF); /* no EOF, 'dim' correctly read */
    assert(dim > 0);
    
    fclose(fp);
    
    /* reading parameter file with parameters for selection */
    fp = fopen(paramfile, "r");
    assert(fp != NULL);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "epsilon") == 0);
    epsilon = (double *)malloc(dim*sizeof(double));
    for(int i = 0; i < dim; i++)
    {
    	result = fscanf(fp, "%lf", &epsilon[i]);
    	if (epsilon[i]<=0.0)
        {
            PISA_ERROR("Entered value of epsilon is non-positive, hence exiting\n");
        }
    }
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "seed") == 0);
    result = fscanf(fp, "%d", &seed);
    assert(result != EOF); /* no EOF, parameters correctly read */

    fscanf(fp, "%s", str);
    assert(strcmp(str, "tournament") == 0);
    result = fscanf(fp, "%d", &tournament);
    assert(result != EOF); /* no EOF, parameters correctly read */
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "outgen") == 0);
    result = fscanf(fp, "%d", &outgen);
    assert(result != EOF); /* no EOF, parameters correctly read */
    
    fclose(fp);
    
    srand(seed); /* seeding random number generator */
    
    gen = 0;
    /* create individual and archive pop */
    pp_all = create_pop(alpha, dim);
    pp_sel = create_pop(mu, dim);   
    archive.clear(); 
}


/*-------------------| memory allocation functions |---------------------*/

void* chk_malloc(size_t size)
/* Wrapper function for malloc(). Checks for failed allocations. */
{
    void *return_value = malloc(size);
    if(return_value == NULL)
	PISA_ERROR("Selector: Out of memory.");
    return (return_value);
}


pop* create_pop(int maxsize, int dim)
/* Allocates memory for a population. */
{
    int i;
    pop *pp;
    
    assert(dim >= 0);
    assert(maxsize >= 0);
    
    pp = (pop*) chk_malloc(sizeof(pop));
    pp->size = 0;
    pp->maxsize = maxsize;
    pp->ind_array = (ind**) chk_malloc(maxsize * sizeof(ind*));
    
    for (i = 0; i < maxsize; i++)
	pp->ind_array[i] = NULL;
    
    return (pp);
}


ind* create_ind(int dim)
/* Allocates memory for one individual. */
{
    ind *p_ind;
    
    assert(dim >= 0);
    
    p_ind = (ind*) chk_malloc(sizeof(ind));
    
    p_ind->index = -1;
    p_ind->f = (double*) chk_malloc(dim * sizeof(double));
    p_ind->box = (double*) chk_malloc(dim * sizeof(double));
    return (p_ind);
}

ind* copy_ind(ind* source)
/* Copies individual */
{
	ind* p_ind = create_ind(dim);
	
	p_ind->index = source->index;
	for(int i = 0; i < dim; i++)
	{
		p_ind->box[i] = source->box[i];
		p_ind->f[i] = source->f[i];
	}
	return p_ind;
}


void free_memory()
/* Frees all memory. */
{
   free_pop(pp_sel);
   complete_free_pop(pp_all);
   free_pop(pp_new);
   pp_sel = NULL;
   pp_all = NULL;
   pp_new = NULL;
}


void free_pop(pop *pp)
/* Frees memory for given population. */
{
   if(pp != NULL)
   {
      free(pp->ind_array);
      free(pp);
   }
}


void complete_free_pop(pop *pp)
/* Frees memory for given population and for all individuals in the
   population. */
{
   int i = 0;
   if (pp != NULL)
   {
      if(pp->ind_array != NULL)
      {
         for (i = 0; i < pp->size; i++)
         {
            if (pp->ind_array[i] != NULL)
            {
               free_ind(pp->ind_array[i]);
               pp->ind_array[i] = NULL;
            }
         }
         
         free(pp->ind_array);
      }
   
      free(pp);
   }
}


void free_ind(ind *p_ind)
/* Frees memory for given individual. */
{
    assert(p_ind != NULL);
     
    free(p_ind->f);
    free(p_ind->box);
    free(p_ind);
}



/*-----------------------| selection functions|--------------------------*/
void matingSelection()
/* Fills mating pool 'pp_sel' */
{
    int j;
	ind* winner = pp_all->ind_array[irand(pp_all->size)];
    for (j = 1; j < tournament; j++)
	{
	    ind* opponent = pp_all->ind_array[irand(pp_all->size)];
	    winner = binary_tournament(winner, opponent);
	}  
	pp_sel->ind_array[0] = winner;
	pp_sel->ind_array[1] = archive.at( irand(archive.size()) );
	pp_sel->size = mu;
}

/* Routine for binary tournament */
ind* binary_tournament(ind *solution1, ind *solution2)
{
    int flag;
    flag = check_dominance (solution1, solution2);
    if (flag==1)
    {
        return (solution1);
    }
    if (flag==-1)
    {
        return (solution2);
    }
    if (irand(2) == 0)
    {
        return(solution1);
    }
    else
    {
        return(solution2);
    }
}

void select_initial()
/* Performs initial selection. */
{
	int i;
	gen++;
	for(i = 0; i < pp_new->size; i++)
	{
		findBox(pp_new->ind_array[i]);
		pp_all->ind_array[i] = copy_ind(pp_new->ind_array[i]);
		update_elite(pp_new->ind_array[i]);
	}
	pp_all->size = pp_new->size;
	matingSelection();
	free_pop(pp_new);
	pp_new = NULL;
}


void select_normal()
/* Performs normal selection.*/
{
	int i;
	gen++;
	for(i = 0; i < pp_new->size; i++)
	{
		findBox(pp_new->ind_array[i]);
		update_pop(pp_new->ind_array[i]);
		update_elite(pp_new->ind_array[i]);
	}
	
	matingSelection();
	free_pop(pp_new);
	pp_new = NULL;
	if(gen % outgen == 0)
	{
		 write_archive();
		 write_population();
	}
}

/* Routine to update archive */
void update_elite(ind *solution)
{
	vector<ind*>::iterator archive_iterator = archive.begin();
    int end = 0;
    int flag = 0;
    while( archive_iterator != archive.end() && end != 1 )
    {
        flag = check_box_dominance (solution, *archive_iterator);
        switch (flag)
        {
        case 1: /* solution epsilon-dominates archive member */
            {
            	// delete archive member
            	free_ind(*archive_iterator);
                archive_iterator = archive.erase(archive_iterator);
                break;
            }
        case 2: /* archive member epsilon-dominates solution */
            {	// reject solution
                return;
            }
        case 3: /* both are non-dominated and are in different boxes */
            {
            	// fetch next archive member and go on
            	archive_iterator++;
                break;
            }
        case 4: /* both are non-dominated and are in same hyper-box */
            {
            	// stop and check both solutions more precisely 
                end = 1;
                break;
            }
        }
    }
    if (end==0)
    {
    	// solution is in unoccupied box
        archive.push_back(solution);
    }
    else
    {
        if (flag==4)        /* in same hyperbox */
        {
            flag = check_dominance (solution, *archive_iterator);
            switch (flag)
            {
            case 1: /* solution dominates archive member in same box */
           			// delete member and add solution to the archive
           			free_ind(*archive_iterator);
                    archive_iterator = archive.erase(archive_iterator);
                    archive.push_back(solution);
                    break;  
            case -1: /* archive member in same box dominates solution */
               		// reject solution
                    return;
            case 0:
                    double d1 = 0.0;
                    double d2 = 0.0;
                    // determine distance to the min corner of the box
                    for (int i = 0; i < dim; i++)
                    {
                        d1 += solution->f[i] - solution->box[i];
                        d2 += (*archive_iterator)->f[i] - (*archive_iterator)->box[i];
                    }
                    if (d1<=d2) /* distance of solution is smaller or equal */ 
                    {
                    	// delete member and add solution to the archive
                    	free_ind(*archive_iterator);
                        archive_iterator = archive.erase(archive_iterator);
                    	archive.push_back(solution);
                    }
                    break;
            }
        }
    }
    return;
}

/* Routine to update population */
void update_pop (ind *solution)
{
	int i;
	int flag;
	vector<int> dominated_inds;
	dominated_inds.clear();
	for ( i = 0; i < alpha; i++)
	{
		flag = check_dominance (solution, pp_all->ind_array[i]);
		switch (flag)
		{
			case 1: /* solution dominates member with index i */
				// save i
				dominated_inds.push_back(i);
				break;
			case -1: /* solution is dominated */
				// reject solution
				return;
			case 0: /* solution and member are incomparable */
				break;
		}
	}
	if (dominated_inds.size() > 0)
	{	/* overwrite a dominated individual */
		i = irand( dominated_inds.size() );
		free_ind(pp_all->ind_array[i]);
		pp_all->ind_array[i] = copy_ind(solution);
	}
	else
	{
		/* solution and all members are incomparable. Overwrite random individual */
		i = irand( alpha );
		free_ind(pp_all->ind_array[i]);
		pp_all->ind_array[i] = copy_ind(solution);
	}
	return;
}

int check_box_dominance (ind *a, ind *b)
{
    int i;
    int flag1;
    int flag2;
    flag1 = 0;
    flag2 = 0;
 	for (i=0; i<dim; i++)
    {
        if (a->box[i] < b->box[i])
        {
            flag1 = 1;

        }
        else
        {
            if (a->box[i] > b->box[i])
            {
                flag2 = 1;
            }
        }
    }
    if (flag1==1 && flag2==0)
    {
        return (1);
    }
    else
    {
        if (flag1==0 && flag2==1)
        {
            return (2);
        }
        else
        {
            if (flag1==1 && flag2==1)
            {
                return(3);
            }
            else
            {
                return(4);
            }
        }
    }
}

/* Routine for usual non-domination checking
   It will return the following values
   1 if a dominates b
   -1 if b dominates a
   0 if both a and b are non-dominated */
int check_dominance (ind *a, ind *b)
{
    int i;
    int flag1;
    int flag2;
    flag1 = 0;
    flag2 = 0;
   	for (i = 0; i < dim; i++)
    {
        if (a->f[i] < b->f[i])
        {
            flag1 = 1;

        }
        else
        {
            if (a->f[i] > b->f[i])
            {
                flag2 = 1;
            }
        }
    }
    if (flag1==1 && flag2==0)
    {
        return (1);
    }
    else
    {
        if (flag1==0 && flag2==1)
        {
            return (-1);
        }
        else
        {
            return (0);
        }
    }            
}

void findBox(ind *solution)
{
	for (int i = 0; i < dim; i++)
    {
        solution->box[i] = floor( solution->f[i] * (1.0 / epsilon[i]) );
    }
}

int irand(int range)
/* Generate a random integer. */
{
    int j;
    j=(int) ((double)range * (double) rand() / (RAND_MAX+1.0));
    return (j);
}


/*--------------------| data exchange functions |------------------------*/

int read_ini()
{
    int i;
    pp_new = create_pop(alpha, dim);
    
    for (i = 0; i < alpha; i++)
	pp_new->ind_array[i] = create_ind(dim);
    pp_new->size = alpha;
    
    return (read_pop(inifile, pp_new, alpha, dim));                    
}


int read_var()
{
    int i;

    pp_new = create_pop(lambda, dim);
    
    for (i = 0; i < lambda; i++)
	pp_new->ind_array[i] = create_ind(dim);
    
    pp_new->size = lambda;
    return (read_pop(varfile, pp_new, lambda, dim));
}


void write_sel()
{
    write_pop(selfile, pp_sel, mu);
}


void write_arc()
{
     int i;
     FILE *fp = fopen(arcfile, "w");
     assert(fp != NULL);
     vector<int> indices;
     indices.clear();
     int size = 1;
     for(i = 0; i < (int) archive.size(); i++)
     {
     	indices.push_back(archive.at(i)->index);
     }
     for(i = 0; i < pp_all->size; i++)
     {
     	indices.push_back(pp_all->ind_array[i]->index);
     }
     sort(indices.begin(), indices.end());
     
     // determine number of different indices
     for (i = 1; i < (int) indices.size(); i++)
     {
     	if( indices.at(i) != indices.at(i-1) ) /* filter same elements */
     	{
     		size++;
     	}
     }
     
     fprintf(fp, "%d\n", size); /* number of elements */
     
     fprintf(fp, "%d\n", indices.at(0)); /* first index */ 
     for (i = 1; i < (int) indices.size(); i++)
     {
     	if( indices.at(i) != indices.at(i-1) ) /* filter same elements */
     	{
     		fprintf(fp, "%d\n", indices.at(i));
     	}
     }
     fprintf(fp, "END");
     fclose(fp);
}

void write_archive()
{
	int i, j;
	char outfile[FILE_NAME_LENGTH];
	sprintf(outfile, "sel_archive_%d.%d", seed, gen);
	FILE *fp = fopen(outfile, "w");
	assert(fp != NULL);
	for(i = 0; i < (int) archive.size(); i++)
	{
		fprintf(fp, "%d ", archive.at(i)->index);
		for(j = 0; j < dim; j++)
		{
			fprintf(fp, "%.15lf ", archive.at(i)->f[j]);
		}
		for(j = 0; j < dim; j++)
		{
			fprintf(fp, "%.15lf ", archive.at(i)->box[j]);
		}
		fprintf(fp, "\n");	
	}
	fclose(fp);
}

void write_population()
{
	int i, j;
	char outfile[FILE_NAME_LENGTH];
	sprintf(outfile, "sel_population_%d.%d", seed, gen);
	FILE *fp = fopen(outfile, "w");
	assert(fp != NULL);
	for(i = 0; i < pp_all->size; i++)
	{
		fprintf(fp, "%d ", pp_all->ind_array[i]->index);
		for(j = 0; j < dim; j++)
		{
			fprintf(fp, "%lf ", pp_all->ind_array[i]->f[j]);
		}
		for(j = 0; j < dim; j++)
		{
			fprintf(fp, "%.15lf ", pp_all->ind_array[i]->box[j]);
		}
		fprintf(fp, "\n");	
	}
	fclose(fp);
}

int check_sel()
{
     return (check_file(selfile));
}


int check_arc()
{
     return (check_file(arcfile));
}
