/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SEMO - Simple Evolutionary Multi-objective Optimizer

  Example implementation in C for the selection side.
  
  Implements data exchange trough files.
  
  file: semo_io.c
  author: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "semo.h"


int read_ind(char *filename, ind *p_var_ind, int dim)
/* Reads one individual from file into 'p_var_ind'. */
{
     int i, size;
     char tag[4];
     FILE *fp;
     int result;

     assert(dim >= 0);
     assert(p_var_ind != NULL);
      
     fp = fopen(filename, "r");
     assert(fp != NULL);
     
     fscanf(fp, "%d", &size);
     assert(size == dim + 1);

     /* reading index of individual */
     result = fscanf(fp, "%d", &(p_var_ind->index)); /* fscanf() returns EOF
                                                        if reading fails.*/
          
     for (i = 0; i < dim; i++)
     {
          /* reading fitness values of ind */
          result = fscanf(fp, "%le", &(p_var_ind->fit[i]));
          assert(p_var_ind->fit[i] >= 0);
     }
     
     if (result == EOF) /* file not completely written */
     {
          fclose(fp);
          return (1); /* signalling that reading failed */
     }
     
     else /* after size data elements "END" expected */
     {
          fscanf(fp, "%s", tag);
          if (strcmp(tag, "END") != 0)
          {
               fclose(fp);
               return (1);  /* signalling that reading failed */
          }
          else /* "END" ok */
          {
               fclose(fp);

               /* delete file content if reading successful */
               fp = fopen(filename, "w");
               assert(fp != NULL);
               fprintf(fp, "0");
               fclose(fp);
               
               return (0);  /* signalling that reading was successful */
          }
     }
}


void write_ind(char* filename, pop *pp, int ind)
/* Write one individual ('pp->ind_array[ind]) to file. */
{
     FILE *fp;

     assert(pp->ind_array[ind] != NULL);
     
     fp = fopen(filename, "w");
     assert(fp != NULL);

     fprintf(fp, "%d\n", 1);
     fprintf(fp, "%d\n", pp->ind_array[ind]->index);
     fprintf(fp, "END");

     fclose(fp);
}


void write_pop(char* filename, pop* pp, int size)
/* Writes a pop or PISA_to a given filename. */
{
     int i;
     FILE *fp;

     assert(0 <= size <= pp->size);
     
     fp = fopen(filename, "w");
     assert(fp != NULL);
     
     fprintf(fp, "%d\n", size); /* number of elements */
     
     for (i=0; i<size; i++)
     {
          fprintf(fp, "%d\n", pp->ind_array[i]->index);
     }
     
     fprintf(fp, "END");
     fclose(fp);
}


int check_file(char* filename)
/* Checks whether 'filename' has been read by the variator. */
{
     int control_element = 1;

     FILE *fp;

     fp = fopen(filename, "r");
     assert(fp != NULL);
     fscanf(fp, "%d", &control_element);

     fclose(fp);
     
     if(0 == control_element)
          return (0); /* file is ready for writing */
     else
          return (1); /* file is not ready for writing */
}
