/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SEMO - Simple Evolutionary Multi-objective Optimizer

  Example implementation in C for the selection side.
  
  Header file.
  
  file: semo.h
  author: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/

#ifndef SEMO_H
#define SEMO_H

/*-----------------------| specify Operating System |------------------*/
/* necessary for wait() */

/* #define PISA_WIN */
#define PISA_UNIX

/*----------------------------| macro |----------------------------------*/

#define PISA_ERROR(x) fprintf(stderr, "\nError: " x "\n"), fflush(stderr), exit(EXIT_FAILURE)

/*---------------------------| constants |-------------------------------*/
#define FILE_NAME_LENGTH 128 /* maximal length of filenames */
#define CFG_ENTRY_LENGTH 128 /* maximal length of entries in cfg file */
#define MAX_ARCHIVE 100000   /* maximal size of the archive */

/*----------------------------| structs |--------------------------------*/

typedef struct ind_st  /* an individual */
{
     int index;
     double *fit; /* objective vector */
} ind;

typedef struct pop_st  /* a population */
{
     int size;
     ind **ind_array;
} pop;


/*-------------| functions for control flow (in semo.c) |------------*/

void write_flag(char *filename, int flag);
int read_flag(char *filename);
void wait(double sec);

/*---------| initialization function (in semo_functions.c) |---------*/

void initialize(char *paramfile, char *filenamebase);

/*--------| memory allocation functions (in semo_functions.c) |------*/

void* chk_malloc(size_t size);
pop* create_pop(int size, int dim);
ind* create_ind(int dim);

void free_memory(void);
void free_pop(pop *pp);
void free_ind(ind *p_ind);

/*-----| functions implementing the selection (semo_functions.c) |---*/

void select_initial();
void select_normal();
int select_ind(ind *p_new_ind, pop *pp_all, int* p_no_ind, int dim);
int dominates(ind *p_ind_a, ind *p_ind_b, int dim);
int is_equal(ind *p_ind_a, ind *p_ind_b, int dim);
void copy_ind(ind *p_ind_a, ind *p_ind_b, int dim);
int irand(int range);

/*--------------------| data exchange functions |------------------------*/

/* in semo_functions.c */

int read_ini(void);
int read_var(void);
void write_sel(void);
void write_arc(void);
int check_sel(void);
int check_arc(void);

/* in semo_io.c */

int read_ind(char *filename, ind *p_var_ind, int dim);
void write_ind(char *filename, pop *pp, int ind);
void write_pop(char *filename, pop *pp, int size);
int check_file(char *filename);

#endif /* SEMO_H */


