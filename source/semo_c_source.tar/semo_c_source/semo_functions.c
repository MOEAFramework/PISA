/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SEMO - Simple Evolutionary Multi-objective Optimizer

  Example implementation in C for the selection side.
  
  Implements most functions.
  
  file: semo_functions.c
  author: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "semo.h"

/* common parameters */
int alpha;  /* number of individuals in initial population */
int mu;     /* number of individuals selected as parents */
int lambda; /* number of offspring individuals */
int dim;    /* number of objectives */


/* local parameters from paramfile*/
int seed;   /* seed for random number generator */


/* other variables */
char cfgfile[FILE_NAME_LENGTH];  /* 'cfg' file (common parameters) */
char inifile[FILE_NAME_LENGTH];  /* 'ini' file (initial population) */
char selfile[FILE_NAME_LENGTH];  /* 'sel' file (parents) */
char arcfile[FILE_NAME_LENGTH];  /* 'arc' file (archive) */
char varfile[FILE_NAME_LENGTH];  /* 'var' file (offspring) */

pop *pp_all = NULL;    /* Stores all individuals that could ever be
                          used again. Created in select_ind() */
int fill_level = 0;    /* number of individuals in archive = pp_all */
ind *p_var_ind = NULL; /* Individual that was just variated */
int sel_ind;           /* Index of selected individual in 'pp_all' */

/*-----------------------| initialization |------------------------------*/

void initialize(char *paramfile, char *filenamebase)
/* Performs the necessary initialization to start in state 0. */
{
     FILE *fp;
     int result;
     char str[CFG_ENTRY_LENGTH];
     
     /* reading parameter file with parameters for selection */
     fp = fopen(paramfile, "r");
     assert(fp != NULL);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "seed") == 0);
     result = fscanf(fp, "%d", &seed); /* fscanf() returns EOF if
                                          reading fails. */
     assert(result != EOF); /* no EOF, 'seed' correctly read */

     fclose(fp);
     
     srand(seed); /* seeding random number generator */
     
     sprintf(varfile, "%svar", filenamebase);
     sprintf(selfile, "%ssel", filenamebase);
     sprintf(cfgfile, "%scfg", filenamebase);
     sprintf(inifile, "%sini", filenamebase);
     sprintf(arcfile, "%sarc", filenamebase);

     /* reading cfg file with common configurations for both parts */
     fp = fopen(cfgfile, "r");
     assert(fp != NULL);
 
     fscanf(fp, "%s", str);
     assert(strcmp(str, "alpha") == 0);
     fscanf(fp, "%d", &alpha);
     assert(alpha > 0);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "mu") == 0);
     fscanf(fp, "%d", &mu);
     assert(mu > 0);
     
     fscanf(fp, "%s", str);
     assert(strcmp(str, "lambda") == 0);
     fscanf(fp, "%d", &lambda);
     assert(lambda > 0);

     fscanf(fp, "%s", str);
     assert(strcmp(str, "dim") == 0);
     result = fscanf(fp, "%d", &dim);
     assert(result != EOF); /* no EOF, 'dim' correctly read */
     assert(dim > 0);
     
     fclose(fp);
     
     /* check ability to handle 'alpha', 'mu', 'lambda' and 'dim' */
     if (alpha != 1)
          PISA_ERROR("Semo can't handle alpha != 1.");
     if (mu != 1)
          PISA_ERROR("Semo can't handle mu != 1.");
     if (lambda != 1)
          PISA_ERROR("Semo can't handle lambda != 1.");
     if (dim != 2)
          PISA_ERROR("Semo can't handle dim != 2.");

     /* create individual and archive pop */
     p_var_ind = create_ind(dim);
     pp_all = create_pop(MAX_ARCHIVE, dim); /* inds are created in
                                               select_ind() */

     fill_level = 0;
}


/*-------------------| memory allocation functions |---------------------*/

void* chk_malloc(size_t size)
/* Wrapper function for malloc(). Checks for failed allocations. */
{
     void *return_value = malloc(size);
     if(return_value == NULL)
          PISA_ERROR("Semo: Out of memory.");
     return (return_value);
}


pop* create_pop(int size, int dim)
/* Allocates memory for a population. */
{
     int i;
     pop *pp;

     assert(dim >= 0);
     assert(size >= 0);
     
     pp = (pop*) chk_malloc(sizeof(pop));
     pp->size = size;
     pp->ind_array = (ind**) chk_malloc(size * sizeof(ind*));

     for (i = 0; i < size; i++)
          pp->ind_array[i] = NULL;
     
     return (pp);
}


ind* create_ind(int dim)
/* Allocates memory for one individual. */
{
     ind *p_ind;

     assert(dim >= 0);
     
     p_ind = (ind*) chk_malloc(sizeof(ind));
     
     p_ind->fit = (double*) chk_malloc(dim * sizeof(double));

     /* initialization */
     p_ind->index = -1;

     return (p_ind);
}


void free_memory()
/* Frees all memory. */
{
   if (NULL != p_var_ind)
   {
      free_ind(p_var_ind);
      p_var_ind = NULL;
   }
   if(NULL != pp_all)
   {
      free_pop(pp_all);
      pp_all = NULL;
   }
}


void free_pop(pop *pp)
/* Frees memory for given population. */
{
     int i;

     if (NULL != pp)
     {
        for (i = 0; i < pp->size; i++)
           if (pp->ind_array[i] != NULL)
           {
              free_ind(pp->ind_array[i]);
              pp->ind_array[i] = NULL;
           }
        free(pp->ind_array);
        free(pp);
     }
}

void free_ind(ind *p_ind)
/* Frees memory for given individual. */
{
     assert(p_ind != NULL);
     
     free(p_ind->fit);
     free(p_ind);
}


/*-----------------------| selection functions|--------------------------*/

void select_initial()
/* Performs initial selection. */
{
     sel_ind = select_ind(p_var_ind, pp_all, &fill_level, dim);
}


void select_normal()
/* Performs normal selection.*/
{
     sel_ind = select_ind(p_var_ind, pp_all, &fill_level, dim);
}


int select_ind(ind *p_new_ind, pop *pp_all, int* p_no_ind, int dim)
/* Implements SEMO. Takes one individual from variation, updates archive
   and selects a new individual for variation. */
{
     int i, pos;
     int dominated = 0;
     int equal = 0;
     ind *p_ind;
     
     assert(dim >= 0);
     
     /* deleting all ind in pp_all which are dominated by p_new_ind */
     for (i = 0; i < *p_no_ind; i++)
     {
          p_ind = pp_all->ind_array[i];
          if (dominates(p_new_ind, p_ind, dim))
          {
               if (i != *p_no_ind - 1) /* anti aliasing */
               {
                    free_ind(p_ind);
                    pp_all->ind_array[i] = pp_all->ind_array[*p_no_ind - 1];
                    pp_all->ind_array[*p_no_ind - 1] = NULL;
                    i--; /* otherwise we forget the ind just moved */
               }
               else /* ind_array[i] is the last individual in ind_array[] */
               {
                    free_ind(pp_all->ind_array[i]); 
                    pp_all->ind_array[i] = NULL;
               }
               
               (*p_no_ind)--;
          }
     }
     
     /* Checking if p_new_ind is dominated by any archive member in pp_all
        or if is is equal to an archive member in all objective values.*/
     for (i = 0; i < *p_no_ind && !dominated && !equal; i++)
     {
          p_ind = pp_all->ind_array[i];
          
          if (dominates(p_ind, p_new_ind, dim))
               dominated = 1;
          if (is_equal(p_ind, p_new_ind, dim))
               equal = 1;
     }
     
     if (!dominated && !equal) /* put p_new_ind in pp_all */
     {
          assert(*p_no_ind < pp_all->size); /* 'pp_all' can store new ind */
          p_ind = create_ind(dim);
          copy_ind(p_new_ind, p_ind, dim);
          pp_all->ind_array[*p_no_ind] = p_ind;
          (*p_no_ind)++;
     }/* else leave pp_all the way it is */
     
     /* uniformly choose one individual from pp_all for variation */
     pos = irand(*p_no_ind);
     
     return (pos);
}


int dominates(ind *p_ind_a, ind *p_ind_b, int dim)
/* Determines if one individual dominates another.
   Minimizing fitness values. */
{
     int i;
     int a_is_worse = 0;
     int equal = 1;
     
     for (i = 0; i < dim && !a_is_worse; i++)
     {
          a_is_worse = p_ind_a->fit[i] > p_ind_b->fit[i];
          equal = (p_ind_a->fit[i] == p_ind_b->fit[i]) && equal;
     }

     return (!equal && !a_is_worse);
}


int is_equal(ind *p_ind_a, ind *p_ind_b, int dim)
/* Determines if two individuals are equal in all objective values.*/
{
     int i;
     int equal = 1;
     
     for (i = 0; i < dim; i++)
          equal = (p_ind_a->fit[i] == p_ind_b->fit[i]) && equal;
     
     return (equal);
}


void copy_ind(ind *p_ind_a, ind *p_ind_b, int dim)
/* Copies the content of one existing individual to another existin
   individual. */
{
     int i;
     p_ind_b->index = p_ind_a->index;

     for (i = 0; i < dim; i++)
          p_ind_b->fit[i] = p_ind_a->fit[i];
}



int irand(int range)
/* Generate a random integer. */
{
     int j;
     j=(int) ((double)range * (double) rand() / (RAND_MAX+1.0));
     return (j);
}


/*--------------------| data exchange functions |------------------------*/

int read_ini()

{
     return (read_ind(inifile, p_var_ind, dim));                    
}


int read_var()

{
     return (read_ind(varfile, p_var_ind, dim));
}


void write_sel()

{
     write_ind(selfile, pp_all, sel_ind);
}


void write_arc()

{
     write_pop(arcfile, pp_all, fill_level);
}


int check_sel()
/* Checks whether sel file has been read. */
{
     return (check_file(selfile));
}


int check_arc()
/* Checks whether sel file has been read. */
{
     return (check_file(arcfile));
}
