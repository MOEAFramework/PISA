/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  MSOPS
  
  Implements most functions.
  
  file: msops_functions.c
  author: Tobias Wagner, tobias.wagner@udo.edu

  revision by: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/


#include "msops.h"
#include <cassert>
#include <algorithm>
#include <cmath>
using namespace std;

/* common parameters */
/* number of individuals in initial population */
int mu;     /* number of individuals selected as parents */
int lambda; /* number of offspring individuals */
int dim;    /* number of objectives */


/* local parameters from paramfile*/
int seed;   /* seed for random number generator */
int tournament;  /* parameter for tournament selection */
int targets; /* number of target vectors to use */
int q;		 /* constant factor in VADS */
short int dual;	 /* dual optimization switch (+ VADS) */
vector< vector<double> > target_vectors;


/* other variables */
char cfgfile[FILE_NAME_LENGTH];  /* 'cfg' file (common parameters) */
int alpha;  
char inifile[FILE_NAME_LENGTH];  /* 'ini' file (initial population) */
char selfile[FILE_NAME_LENGTH];  /* 'sel' file (parents) */
char arcfile[FILE_NAME_LENGTH];  /* 'arc' file (archive) */
char varfile[FILE_NAME_LENGTH];  /* 'var' file (offspring) */
char desfile[FILE_NAME_LENGTH];  /* 'des' file (target design) */


/* population containers */
pop *pp_all = NULL;
pop *pp_new = NULL;
pop *pp_sel = NULL;

/*-----------------------| initialization |------------------------------*/

void initialize(char *paramfile, char *filenamebase)
/* Performs the necessary initialization to start in state 0. */
{
    FILE *fp;
    double result;
    vector<double> act_vec;
    int i;
    char str[CFG_ENTRY_LENGTH];
    
    /* reading parameter file with parameters for selection */
    fp = fopen(paramfile, "r");
    assert(fp != NULL);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "seed") == 0);
    result = fscanf(fp, "%d", &seed);
    assert(result != EOF); /* no EOF, parameters correctly read */

    fscanf(fp, "%s", str);
    assert(strcmp(str, "tournament") == 0);
    result = fscanf(fp, "%d", &tournament); /* fscanf() returns EOF
					       if reading fails. */
    assert(result != EOF); /* no EOF, parameters correctly read */
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "targets") == 0);
    result = fscanf(fp, "%d", &targets); /* fscanf() returns EOF
					       if reading fails. */
    assert(result != EOF); /* no EOF, parameters correctly read */
    if(targets < dim) PISA_ERROR("There have to be at least as much targets as dimensions");
    
     fscanf(fp, "%s", str);
    assert(strcmp(str, "dual") == 0);
    result = fscanf(fp, "%hd", &dual); /* fscanf() returns EOF
					       if reading fails. */
    assert(result != EOF); /* no EOF, parameters correctly read */
    if( (dual < 0) || (dual > 1) )  PISA_ERROR("dual is a switch 0 (No VADS) 1 (+VADS)");   
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "q") == 0);
    result = fscanf(fp, "%d", &q); /* fscanf() returns EOF
					       if reading fails. */
    if(q < 1) PISA_ERROR("q has to be greater than one");
    fclose(fp);
    
    srand(seed); /* seeding random number generator */
    
    sprintf(varfile, "%svar", filenamebase);
    sprintf(selfile, "%ssel", filenamebase);
    sprintf(cfgfile, "%scfg", filenamebase);
    sprintf(inifile, "%sini", filenamebase);
    sprintf(arcfile, "%sarc", filenamebase);
    
    /* reading cfg file with common configurations for both parts */
    fp = fopen(cfgfile, "r");
    assert(fp != NULL);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "alpha") == 0);
    fscanf(fp, "%d", &alpha);
    assert(alpha > 0);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "mu") == 0);
    fscanf(fp, "%d", &mu);
    assert(mu > 0);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "lambda") == 0);
    fscanf(fp, "%d", &lambda);
    assert(lambda > 0);
    
    fscanf(fp, "%s", str);
    assert(strcmp(str, "dim") == 0);
    result = fscanf(fp, "%d", &dim);
    assert(result != EOF); /* no EOF, 'dim' correctly read */
    assert(dim > 0);
    
    fclose(fp);
    
    /* create individual and archive pop */
    pp_all = create_pop(alpha + lambda, dim);
    pp_sel = create_pop(mu, dim);    
    
    /* Build target vectors */
    sprintf(desfile, "space-filling-%ddim.des", dim);
    int j;
    double value;
    assert(dim >= 2);
    fp = fopen(desfile, "r");
    if (fp == NULL) PISA_ERROR("No design file found");
    for (i = 0; i < targets; i++)
    {
    	act_vec.clear();
		for (j = 0; j < dim; j++)
		{
		    /* reading weight values from file*/
		    result = fscanf(fp, "%le", &value);
		    if (result == EOF) /* file not completely written */
		    {
				fclose(fp);
				PISA_ERROR("Design has not enough values to fill all targets");
		    }
		    else
		    {
				if(value > 0)
				{
		    		act_vec.push_back(value);
				}
				else
				{
					act_vec.push_back(0.000001);
				}
		    }
		}
		target_vectors.push_back(act_vec);
    }
    fclose(fp);     
}

/*-------------------| memory allocation functions |---------------------*/

void* chk_malloc(size_t size)
/* Wrapper function for malloc(). Checks for failed allocations. */
{
    void *return_value = malloc(size);
    if(return_value == NULL)
	PISA_ERROR("Selector: Out of memory.");
    return (return_value);
}


pop* create_pop(int maxsize, int dim)
/* Allocates memory for a population. */
{
    int i;
    pop *pp;
    
    assert(dim >= 0);
    assert(maxsize >= 0);
    
    pp = (pop*) chk_malloc(sizeof(pop));
    pp->size = 0;
    pp->maxsize = maxsize;
    pp->ind_array = (ind**) chk_malloc(maxsize * sizeof(ind*));
    
    for (i = 0; i < maxsize; i++)
	pp->ind_array[i] = NULL;
    
    return (pp);
}


ind* create_ind(int dim)
/* Allocates memory for one individual. */
{
    ind *p_ind;
    int size_f;
    if(dual)
    {
    	 size_f = 2* targets;
    }
    else
    {
    	size_f = targets;
    }
    
    assert(dim >= 0);
    
    p_ind = (ind*) chk_malloc(sizeof(ind));
    
    p_ind->index = -1;
    p_ind->f = (double*) chk_malloc(dim * sizeof(double));
    p_ind->fitness = (int*) chk_malloc(size_f * sizeof(int));
    for(int i = 0; i < size_f; i++)
    {
    	p_ind->fitness[i] = 1;
    }

    return (p_ind);
}


void free_memory()
/* Frees all memory. */
{
   free_pop(pp_sel);
   complete_free_pop(pp_all);
   free_pop(pp_new);
   pp_sel = NULL;
   pp_all = NULL;
   pp_new = NULL;
}


void free_pop(pop *pp)
/* Frees memory for given population. */
{
   if(pp != NULL)
   {
      free(pp->ind_array);
      free(pp);
   }
}


void complete_free_pop(pop *pp)
/* Frees memory for given population and for all individuals in the
   population. */
{
   int i = 0;
   if (pp != NULL)
   {
      if(pp->ind_array != NULL)
      {
         for (i = 0; i < pp->size; i++)
         {
            if (pp->ind_array[i] != NULL)
            {
               free_ind(pp->ind_array[i]);
               pp->ind_array[i] = NULL;
            }
         }
         
         free(pp->ind_array);
      }
   
      free(pp);
   }
}


void free_ind(ind *p_ind)
/* Frees memory for given individual. */
{
    assert(p_ind != NULL);
     
    free(p_ind->f);
    free(p_ind->fitness);
    free(p_ind);
}



/*-----------------------| selection functions|--------------------------*/

void selection()
{
    
    /* Join offspring individuals from variator to population */
    mergeOffspring();
    
    /* Calculates msops fitness values for all individuals */
    calcFitnesses();

    /* Performs environmental selection
       (truncates 'pp_all' to size 'alpha') */
    environmentalSelection();

    /* Performs mating selection
       (fills mating pool / offspring population pp_sel */
    matingSelection();
}


void mergeOffspring()
{
    int i;

    assert(pp_all->size + pp_new->size <= pp_all->maxsize);
    for (i = 0; i < pp_new->size; i++)
    {
		pp_all->ind_array[pp_all->size + i] = pp_new->ind_array[i];
    }
	pp_all->size += pp_new->size;
    free_pop(pp_new);
    pp_new = NULL;
}


void calcFitnesses()
{
	vector< vector<double> > scores_wminmax; // Score Matrix n x t of Weighted MinMax
	vector<double> act_score_wminmax;
	vector< vector<double> > scores_vads; // Score Matrix n x t of VADS
	vector<double> act_score_vads;
	vector< vector<int> > fitness; //Dual Optimization Matrix
	vector< int > act_fitness;
	int i, j, k;
	ind* act_ind_i;
	ind* act_ind_j;
	for(i = 0; i < pp_all->size; i++) // compute scores
	{ // for each individual
		act_score_wminmax.clear();
		if(dual) act_score_vads.clear();
		act_fitness.clear();
		act_ind_i = pp_all->ind_array[i];
		for(j = 0; j < targets; j++)
		{ // and each weight vector
			// compute scores
			act_score_wminmax.push_back(weighted_minmax(act_ind_i, target_vectors[j]));
			act_fitness.push_back(1);
			if(dual)
			{
				act_score_vads.push_back(vector_angle_distance_scaling(act_ind_i, target_vectors[j]));
				act_fitness.push_back(1);
			}
		} 
		scores_wminmax.push_back(act_score_wminmax);
		if(dual) scores_vads.push_back(act_score_vads);
		fitness.push_back(act_fitness);
	}
	int factor = dual + 1;
	for(i = 0; i < pp_all->size; i++)
	{ // take each individual
		act_ind_i = pp_all->ind_array[i]; 
		for(j = (i + 1); j < pp_all->size; j++)
		{	// compare it to every individual with heigher index
			for(k = 0; k < targets; k++)
			{ // for every weight vector
				
				if(scores_wminmax[i][k] > scores_wminmax[j][k]) 
				// check which score_wminmax is higher and increment rank
				{
					fitness[i][factor*k]++;
				}
				else if(scores_wminmax[i][k] < scores_wminmax[j][k])
				{
					fitness[j][factor*k]++;
				}
				if(dual)
				{
					if(scores_vads[i][k] > scores_vads[j][k]) 
					// check which score_vads is higher and increment rank
					{
						fitness[i][factor*k+1]++;
					}
					else if(scores_vads[i][k] < scores_vads[j][k])
					{
						fitness[j][factor*k+1]++;
					}
				}
			}
		}
		// finally sort ranks ascending
		sort( fitness[i].begin(), fitness[i].end() );
		// and write it into the fitness array
		int size_f;
		if(dual)
		{
			size_f = 2 * targets;
		}
		else
		{
			size_f = targets;
		}
		for(k = 0; k < size_f; k++)
		{
			act_ind_i->fitness[k] = fitness[i][k];
		}
	}
}

void environmentalSelection()
{
    int i, j;
    int size = pp_all->size;

    for (i = 0; i < alpha; i++)
    {
		ind *p_min;
		int min = i;
		for (j = i + 1; j < size; j++)
		{
		    if ( is_better(pp_all->ind_array[j], pp_all->ind_array[min]) )
			min = j;
		}
		p_min = pp_all->ind_array[min];
		pp_all->ind_array[min] = pp_all->ind_array[i];
		pp_all->ind_array[i] = p_min;
    }
    
    for (i = alpha; i < size; i++)
    {
       free_ind(pp_all->ind_array[i]);
       pp_all->ind_array[i] = NULL;
    }

    pp_all->size = alpha;
    
    return;
}


void matingSelection()
/* Fills mating pool 'pp_sel' */
{
    int i, j;
    pp_sel->ind_array[0] = pp_all->ind_array[0];
    for (i = 1; i < mu; i++)
    {
		int winner = irand(pp_all->size);
		for (j = 1; j < tournament; j++)
		{
		    int opponent = irand(pp_all->size);
		    if ( is_better(pp_all->ind_array[opponent], pp_all->ind_array[winner]) 
		    		|| winner == opponent)
		    {
				winner = opponent;
		    }
		}  
		pp_sel->ind_array[i] = pp_all->ind_array[winner];
    }
    pp_sel->size = mu;    
}

double weighted_minmax(ind* individual, vector<double> weights)
{
	int i;
	double maxValue = -1;
	double actValue;
	for(i = 0; i < dim; i++)
	{
		actValue = individual->f[i] * weights[i];
		if(actValue > maxValue)
		{
			maxValue = actValue;
		}
	}
	return maxValue;
}

double vector_angle_distance_scaling(ind* individual, vector<double> weights)
{
	double score = 0;
	
	double* unit_weight;
	unit_weight = (double*) chk_malloc(dim * sizeof(double));
	double weight_magnitude = 0;
	
	double* unit_objectives;
	unit_objectives = (double*) chk_malloc(dim * sizeof(double));
	double objectives_magnitude = 0;
	
	int i;
	
	// Calculate magnitude of vectors
	for(i = 0; i < dim; i++)
	{
		weight_magnitude = weight_magnitude  + pow(1/weights[i], 2);
		objectives_magnitude = objectives_magnitude + pow(individual->f[i],2);
	}
	weight_magnitude = sqrt(weight_magnitude);
	objectives_magnitude = sqrt(objectives_magnitude);
	
	//Normalize vectors and calculate dot product of weight- and objective-vector
	for(i = 0; i < dim; i++)
	{
		unit_weight[i] = (1/weights[i]) / weight_magnitude;
		unit_objectives[i] = individual->f[i] / objectives_magnitude;
		score = score + unit_weight[i] * unit_objectives[i];
	}
	
	//Finally calculate score
	score = objectives_magnitude / pow(score, q);
	
	free(unit_weight);
	free(unit_objectives);
 	return score;
}


bool is_better(ind* ind_a, ind* ind_b)
{
	int i;
	int target_size;
	if(dual) target_size = 2* targets;
	else target_size = targets;		
	for(i = 0; i < target_size; i++)
	{
		if(ind_a->fitness[i] > ind_b->fitness[i])
		{
			return false;
		}
		else if(ind_a->fitness[i] < ind_b->fitness[i])
		{
			return true;
		}
	}
	return false;
}


void select_initial()
/* Performs initial selection. */
{
    selection();
}


void select_normal()
/* Performs normal selection.*/
{
    selection();
}

int irand(int range)
/* Generate a random integer. */
{
    int j;
    j=(int) ((double)range * (double) rand() / (RAND_MAX+1.0));
    return (j);
}


/*--------------------| data exchange functions |------------------------*/

int read_ini()
{
    int i;
    pp_new = create_pop(alpha, dim);
    
    for (i = 0; i < alpha; i++)
	pp_new->ind_array[i] = create_ind(dim);
    pp_new->size = alpha;
    
    return (read_pop(inifile, pp_new, alpha, dim));                    
}


int read_var()
{
    int i;

    pp_new = create_pop(lambda, dim);
    
    for (i = 0; i < lambda; i++)
	pp_new->ind_array[i] = create_ind(dim);
    
    pp_new->size = lambda;
    return (read_pop(varfile, pp_new, lambda, dim));
}


void write_sel()
{
    write_pop(selfile, pp_sel, mu);
}


void write_arc()
{
     write_pop(arcfile, pp_all, pp_all->size);
}


int check_sel()
{
     return (check_file(selfile));
}


int check_arc()
{
     return (check_file(arcfile));
} 
