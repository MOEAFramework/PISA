#!/bin/sh
./nsga2 nsga2_param.txt ../PISA_ 0.1
