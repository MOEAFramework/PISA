#!/bin/sh
./spam spam_param.txt ../PISA_ 0.1
